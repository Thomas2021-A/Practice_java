    package com.deloitte.exception;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class GlobalExceptionHandler {

    // SLF4J Logger
    private static final Logger log = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    // 1. Handles Custom Application Exceptions (e.g. not enough seats, invalid flight)
    @ExceptionHandler(FlightAppException.class)
    public String handleFlightAppException(FlightAppException ex, Model model) {
        log.warn("Handled FlightAppException: {}", ex.getMessage());
        model.addAttribute("errorMessage", ex.getMessage());
        return "error";
    }

    // 2. Handles Database & SQL Exceptions gracefully without exposing stack trace
    @ExceptionHandler(DataAccessException.class)
    public String handleDatabaseException(DataAccessException ex, Model model) {
        log.error("Database access error occurred: {}", ex.getMessage(), ex);
        model.addAttribute("errorMessage", "A database error occurred. Please verify your database connection.");
        model.addAttribute("errorDetails", ex.getRootCause() != null ? ex.getRootCause().getMessage() : ex.getMessage());
        return "error";
    }

    // 3. Fallback for Any Unexpected Runtime Exceptions
    @ExceptionHandler(Exception.class)
    public String handleGeneralException(Exception ex, Model model) {
        log.error("Unexpected error caught by GlobalExceptionHandler: {}", ex.getMessage(), ex);
        model.addAttribute("errorMessage", "An unexpected error occurred. Please try again or contact support.");
        model.addAttribute("errorDetails", ex.getMessage());
        return "error";
    }
}




