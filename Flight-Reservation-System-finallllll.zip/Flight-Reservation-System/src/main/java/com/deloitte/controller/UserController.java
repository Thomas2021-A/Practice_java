 package com.deloitte.controller;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.deloitte.dto.LoginDto;
import com.deloitte.dto.SignUpDto;
import com.deloitte.model.User;
import com.deloitte.service.UserService;

@Controller
@RequestMapping("")
public class UserController {

    // 1. SLF4J Logger
    private static final Logger log = LoggerFactory.getLogger(UserController.class);

    private final UserService userService;

    @Autowired
    public UserController(UserService userService) {
        this.userService = userService;
    }

    // ==========================================
    // 1. SIGN UP (GET & POST)
    // ==========================================

    @GetMapping("/signup")
    public String showSignupPage(Model model) {
        if (!model.containsAttribute("signUpDto")) {
            model.addAttribute("signUpDto", new SignUpDto());
        }
        return "signup";
    }

    @PostMapping("/signup")
    public String processSignup(@ModelAttribute("signUpDto") SignUpDto signUpDto,
                                BindingResult bindingResult,
                                Model model) {
        log.info("Processing sign up request for email: {}", signUpDto.getEmail());

        // --- 2. Server-Side Form Validation using BindingResult ---
        if (signUpDto.getEmail() == null || signUpDto.getEmail().trim().isEmpty()) {
            bindingResult.rejectValue("email", "NotEmpty", "Email is required.");
        } else if (!signUpDto.getEmail().matches("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$")) {
            bindingResult.rejectValue("email", "Pattern", "Please enter a valid email address (e.g. user@example.com).");
        }

        if (signUpDto.getPassword() == null || signUpDto.getPassword().trim().isEmpty()) {
            bindingResult.rejectValue("password", "NotEmpty", "Password is required.");
        } else if (signUpDto.getPassword().trim().length() <= 8) {
            bindingResult.rejectValue("password", "Size", "Password must be more than 8 characters in length.");
        }

        if (signUpDto.getRole() == null || signUpDto.getRole().trim().isEmpty() ||
            (!signUpDto.getRole().equalsIgnoreCase("user") && !signUpDto.getRole().equalsIgnoreCase("admin"))) {
            bindingResult.rejectValue("role", "Invalid", "Please select a valid role (User or Admin).");
        }

        // Return back to signup if validation errors exist
        if (bindingResult.hasErrors()) {
            log.warn("Sign up form validation failed for email: {} with {} error(s)", 
                     signUpDto.getEmail(), bindingResult.getErrorCount());
            return "signup";
        }

        // Register user via Service Layer
        int result = userService.register(signUpDto);
        if (result == -3) {
            log.warn("Sign up rejected: Email already registered - {}", signUpDto.getEmail());
            bindingResult.rejectValue("email", "Duplicate", "Email already registered. Please log in.");
            return "signup";
        } else if (result <= 0) {
            log.error("Sign up failed in database for email: {}", signUpDto.getEmail());
            model.addAttribute("error", "Registration failed due to a system error. Please check your details.");
            return "signup";
        }

        log.info("User registered successfully: {} ({})", signUpDto.getEmail(), signUpDto.getRole());

        // FIX: Post-Redirect-Get pattern. Redirects to /login?registered=true
        // This ensures the browser calls GET /login, preventing the missing 'loginDto' crash!
        return "redirect:/login?registered=true";
    }

    // ==========================================
    // 2. LOGIN (GET & POST)
    // ==========================================

    @GetMapping("/login")
    public String showLoginPage(@RequestParam(value = "registered", required = false) String registered,
                                @RequestParam(value = "msg", required = false) String msg,
                                @RequestParam(value = "logout", required = false) String logout,
                                Model model) {
        // Guarantee loginDto is always in the model
        if (!model.containsAttribute("loginDto")) {
            model.addAttribute("loginDto", new LoginDto());
        }
        if ("true".equalsIgnoreCase(registered)) {
            model.addAttribute("successMsg", "Sign Up successful! Please log in with your credentials.");
        }
        if (msg != null && !msg.trim().isEmpty()) {
            model.addAttribute("infoMsg", msg);
        }
        if ("true".equalsIgnoreCase(logout)) {
            model.addAttribute("infoMsg", "You have been logged out successfully.");
        }
        return "login";
    }

    @PostMapping("/login")
    public String processLogin(@ModelAttribute("loginDto") LoginDto loginDto,
                               BindingResult bindingResult,
                               Model model, HttpSession session) {
        log.info("Processing login attempt for email: {}", loginDto.getEmail());

        // --- 2. Server-Side Form Validation ---
        if (loginDto.getEmail() == null || loginDto.getEmail().trim().isEmpty()) {
            bindingResult.rejectValue("email", "NotEmpty", "Email is required.");
        }
        if (loginDto.getPassword() == null || loginDto.getPassword().trim().isEmpty()) {
            bindingResult.rejectValue("password", "NotEmpty", "Password is required.");
        }

        if (bindingResult.hasErrors()) {
            log.warn("Login form validation failed for: {}", loginDto.getEmail());
            return "login";
        }

        User user = userService.login(loginDto);
        if (user == null) {
            log.warn("Authentication failed for email: {}", loginDto.getEmail());
            model.addAttribute("error", "Invalid email or password.");
            return "login";
        }

        log.info("User logged in successfully: {} (Role: {})", user.getEmail(), user.getRole());
        session.setAttribute("user", user);

        // Check if there was a pending flight booking redirection
        Long pendingFlightId = (Long) session.getAttribute("redirectFlightId");
        if (pendingFlightId != null) {
            session.removeAttribute("redirectFlightId");
            return "redirect:/booking/form?flightId=" + pendingFlightId;
        }

        // Role-based dashboard redirection
        if ("admin".equalsIgnoreCase(user.getRole())) {
            return "redirect:/admin/dashboard";
        } else {
            return "redirect:/user/dashboard";
        }
    }

    // ==========================================
    // 3. LOGOUT & USER DASHBOARD
    // ==========================================

    @GetMapping("/logout")
    public String logout(HttpSession session) {
        if (session != null) {
            User user = (User) session.getAttribute("user");
            if (user != null) {
                log.info("Logging out user: {}", user.getEmail());
            }
            session.invalidate();
        }
        return "redirect:/login?logout=true";
    }

    @GetMapping("/user/dashboard")
    public String userDashboard(HttpSession session, Model model) {
        User user = (User) session.getAttribute("user");
        if (user == null) {
            return "redirect:/login?msg=Please log in to access your dashboard.";
        }
        if ("admin".equalsIgnoreCase(user.getRole())) {
            return "redirect:/admin/dashboard";
        }
        model.addAttribute("user", user);
        return "user-dashboard";
    }

}