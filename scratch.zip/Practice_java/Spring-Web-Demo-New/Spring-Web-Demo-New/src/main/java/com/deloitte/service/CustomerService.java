package com.deloitte.service;

import java.util.List;

import com.deloitte.dto.LoginDto;
import com.deloitte.dto.SignUpDto;
import com.deloitte.model.Account;
import com.deloitte.model.Customer;

public interface CustomerService {
	public int signup(SignUpDto signupDto);
	public Customer login(LoginDto loginDto);
	public Customer updateProfile(Customer customer);
	public Account viewAccountDetails(long customerId);
	public List<Customer> getAllCustomers();
	boolean deleteCustomerById(long customerId);
		
}
