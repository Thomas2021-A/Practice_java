package com.deloitte.dao;


import java.util.List;
import com.deloitte.dto.SignUpDto;
import com.deloitte.model.Account;
import com.deloitte.model.Customer;

public interface CustomerDao {
	int insertCustomer(SignUpDto signUpDto);

	Customer getCustomerByEmailAndPassword(String customerEmail, String customerPassword);
	
	Customer updateProfile(Customer customer);
	
	Account getAccountDetailsByCustomerId(long customerId);
	
	List<Customer> getAllCustomers();
	
	boolean deleteCustomerById(long customerId);
}
