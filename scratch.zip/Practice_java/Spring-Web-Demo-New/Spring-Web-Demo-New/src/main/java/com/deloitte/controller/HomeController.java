package com.deloitte.controller;

import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Component
@RequestMapping("")
public class HomeController {
	
	// Request Handler Methods
	
	@GetMapping("")          //http://localhost:8080/spring-web-demo
	public String home() {
		System.out.println("HomeCOntrolledMethod() method called");
		return "home"; //View Name
	}

}
