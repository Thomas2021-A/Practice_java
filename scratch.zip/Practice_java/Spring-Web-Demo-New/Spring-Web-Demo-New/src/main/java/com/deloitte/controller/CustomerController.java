package com.deloitte.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.deloitte.dto.LoginDto;
import com.deloitte.dto.SignUpDto;
import com.deloitte.model.Account;
import com.deloitte.model.Customer;
import com.deloitte.service.CustomerService;

@Controller
@RequestMapping("/api/customers")
public class CustomerController {

	@Autowired
	CustomerService customerService;

	// get request handler to respond with signup page
	@GetMapping("/signup")
	public String signup() {
		return "signup"; // view name
	}

	@PostMapping("/signup")
	public String processSignup(SignUpDto signUpDto, Model model) {
		System.out.println(signUpDto.getCustomerName() + " " + signUpDto.getCustomerEmail() + " "
				+ signUpDto.getCustomerPassword() + " " + signUpDto.getCustomerPhone());
		int rec = customerService.signup(signUpDto);

		if (rec == 1) {
			model.addAttribute("msg", "SignUp Successfull");
		} else {
			model.addAttribute("msg", "SignUp fAiled");
		}
		return "signup";// "signup-success"; // view name
	}

	@GetMapping("/login")
	public String login() {
		return "login"; // view name
	}

	@PostMapping("/login")
	public String processLogin(LoginDto loginDto, Model model, HttpSession session) {
		Customer customer = customerService.login(loginDto);

		if (customer != null) {
			// model.addAttribute("msg", "Login Successfull");
			// model.addAttribute("customer", customer);
			session.setAttribute("customer", customer);
			return "dashboard";
		} else {
			model.addAttribute("msg", "Login Failed");
		}
		return "login";
	}

	@GetMapping("/logout")
	public String logout(HttpSession session) {
		session.invalidate();
		return "redirect:/api/customers/login"; // redirect to login page handler method
	}

	@GetMapping("/profile")
	public String profile(HttpSession session, Model model) {
		Customer customer = (Customer) session.getAttribute("customer");
		if (customer != null) {
			model.addAttribute("customer", customer);
			return "profile";
		} else {
			return "redirect:/api/customers/login";
		}
	}

	@PostMapping("/profile")
	public String updateProfile(Customer customer, Model model, HttpSession session) {

		Customer sessionCustomer = (Customer) session.getAttribute("customer");
		if (sessionCustomer != null) {
			customer.setCustomerId(sessionCustomer.getCustomerId());
			customer.setCustomerPassword(sessionCustomer.getCustomerPassword()); // Preserve the password)
		}
		Customer updatedCustomer = customerService.updateProfile(customer);
		if (updatedCustomer != null) {
			session.setAttribute("customer", updatedCustomer);
			model.addAttribute("msg", "Profile updated successfully");
		} else {
			model.addAttribute("msg", "Profile update failed");
		}
		return "profile";
		
	}
		@GetMapping("/account")
		public String account(HttpSession session, Model model) {
			Customer customer = (Customer) session.getAttribute("customer");
			if (customer != null) {
				// write code to fetch account details
				return "redirect:/api/customers/account/" + customer.getCustomerId();
			} else {
				return "redirect:/api/customers/login";
			}
		}
		
		@GetMapping("/account/{customerId}")
		public String accountDetails(@PathVariable long customerId, HttpSession session, Model model) {
			Customer customer = (Customer)session.getAttribute("customer");
			if (customer != null) {
				// write code to fetch account details
				Account account= customerService.viewAccountDetails(customerId);
				if (account != null) {
					model.addAttribute("account", account);
					return "view-account";
				}
				return "view-account";
				/*
				 * else { model.addAttribute("msg", "Account details not found"); } return null;
				 */
			//} 
			}	else {
				return "redirect:/api/customers/login";
			}
		}
		
		@GetMapping("")
		public String viewAllCustomers(Model model) {
			List<Customer> customers = customerService.getAllCustomers();
			if (customers != null) {
				model.addAttribute("customers", customers);
			}
			return "view-customers";
		}
		
		
		@GetMapping("/delete")
		public String deleteCustomer(@RequestParam long customerId, Model model) {
			//write code to delete customer
			customerService.deleteCustomerById(customerId);
			
			return "redirect:/api/customers";
		}
		
		

	}

