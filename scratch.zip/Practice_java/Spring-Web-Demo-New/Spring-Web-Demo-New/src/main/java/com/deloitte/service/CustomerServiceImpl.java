package com.deloitte.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.deloitte.dao.CustomerDao;
import com.deloitte.dto.LoginDto;
import com.deloitte.dto.SignUpDto;
import com.deloitte.model.Account;
import com.deloitte.model.Customer;


@Component
@Service
public class CustomerServiceImpl implements CustomerService{

	@Autowired
	CustomerDao customerDao;
	@Override
	public int signup(SignUpDto signupDto) {
		int rec= customerDao.insertCustomer(signupDto);
		return rec;
	}
	@Override
	public Customer login(LoginDto loginDto) {
		Customer customer = customerDao.getCustomerByEmailAndPassword(loginDto.getCustomerEmail(),loginDto.getCustomerPassword());
		return customer;
	}
	@Override
	public Customer updateProfile(Customer customer) {
		return customerDao.updateProfile(customer);
	}
	@Override
	public Account viewAccountDetails(long customerId) {
		return customerDao.getAccountDetailsByCustomerId(customerId);
	}
	@Override
	public List<Customer> getAllCustomers() {
		// TODO Auto-generated method stub
		return customerDao.getAllCustomers();
	}
	@Override
	public boolean deleteCustomerById(long customerId) {
		// TODO Auto-generated method stub
		return customerDao.deleteCustomerById(customerId);
	}
	
}
