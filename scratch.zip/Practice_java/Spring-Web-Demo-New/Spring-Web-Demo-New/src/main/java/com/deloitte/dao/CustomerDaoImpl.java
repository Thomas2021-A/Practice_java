package com.deloitte.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import com.deloitte.dto.SignUpDto;
import com.deloitte.model.Account;
import com.deloitte.model.Customer;

@Component
public class CustomerDaoImpl implements CustomerDao {

	@Autowired
	JdbcTemplate jdbcTemplate;

	RowMapper<Customer> customerRowMapper = (rs, rowNum) -> {
		Customer customer = new Customer();
		customer.setCustomerId(rs.getLong(1));
		customer.setCustomerName(rs.getString(2));
		customer.setCustomerEmail(rs.getString(3));
		customer.setCustomerPassword(rs.getString(4));
		customer.setCustomerPhone(rs.getString(5));
		return customer;
	};

	RowMapper<Account> accountRowMapper = (rs, rowNum) -> {
		Account account = new Account();
		account.setAccountNo(rs.getLong(1));
		account.setAccountType(rs.getString(2));
		account.setAccountBalance(rs.getDouble(3));
		account.setAccountPin(rs.getInt(4));
		account.setCustomerId(rs.getLong(5));
		return account;
	};
	
	@Autowired
	CustomerDaoImpl(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	@Override
	public int insertCustomer(SignUpDto signUpDto) {
		String sql = "insert into tbl_customers values(default,?,?,?,?)";
		int rec = jdbcTemplate.update(sql, signUpDto.getCustomerName(), signUpDto.getCustomerEmail(),
				signUpDto.getCustomerPassword(), signUpDto.getCustomerPhone());
		return rec;
	}

	@Override
	public Customer getCustomerByEmailAndPassword(String customerEmail, String customerPassword) {
		String sql = "Select * from tbl_customers where customer_email=? and customer_password = ?";
		try {
			Customer customer = jdbcTemplate.queryForObject(sql, customerRowMapper, customerEmail, customerPassword);
			return customer;
		} catch (Exception e) {
			return null;
		}
	}

	@Override
	public Customer updateProfile(Customer customer) {
		String sql = "update tbl_customers set customer_name=?,customer_email=?,customer_password=?,customer_phone=? where customer_id=?";
		int rec = jdbcTemplate.update(sql, customer.getCustomerName(), customer.getCustomerEmail(),customer.getCustomerPassword(), customer.getCustomerPhone(), customer.getCustomerId());
		if(rec == 1) {
			return customer;
		}
		return null;
	}

	@Override
	public Account getAccountDetailsByCustomerId(long customerId) {
		String sql = "select * from tbl_accounts where customer_id=?";
		try {
			Account account = jdbcTemplate.queryForObject(sql, accountRowMapper, customerId);
			return account;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public List<Customer> getAllCustomers() {
		String sql = "select * from tbl_customers";
		try {
			List<Customer> customers = jdbcTemplate.query(sql, customerRowMapper);
			return customers;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
		
	}

	@Override
	public boolean deleteCustomerById(long customerId) {
		String sql = "delete from tbl_customers where customer_id=?";
		int rec = jdbcTemplate.update(sql, customerId);
		return rec == 1? true : false;
	}

}