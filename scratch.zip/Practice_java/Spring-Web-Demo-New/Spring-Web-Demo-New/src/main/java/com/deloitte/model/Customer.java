package com.deloitte.model;

public class Customer implements Comparable<Customer> {
	
	
	private long customerId;
	private String customerName;
	private String customerEmail;
	private String customerPassword;
	private String customerPhone;
 
	private static String companyName="Deloitte";
	
	
	
	
 
	public static String getCompanyName() {
		return companyName;
	}
 
 
 
	public static void setCompanyName(String companyName) {
		Customer.companyName = companyName;
	}
 
 
 
	public Customer() {
		super();
	}
 
 
 
	public Customer(long customerId, String customerName, String customerEmail, String customerPassword,
			String customerPhone) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.customerEmail = customerEmail;
		this.customerPassword = customerPassword;
		this.customerPhone = customerPhone;
	}
	
	
 
	public Customer(String customerName, String customerEmail, String customerPassword, String customerPhone) {
		super();
		this.customerName = customerName;
		this.customerEmail = customerEmail;
		this.customerPassword = customerPassword;
		this.customerPhone = customerPhone;
	}
 
 
 
	public Customer(long customerId, String customerName, String customerPhone) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.customerPhone = customerPhone;
	}
 
	public long getCustomerId() {
		return customerId;
	}
 
	public void setCustomerId(long customerId) {
		this.customerId = customerId;
	}
 
	public String getCustomerName() {
		return customerName;
	}
 
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
 
	public String getCustomerEmail() {
		return customerEmail;
	}
 
	public void setCustomerEmail(String customerEmail) {
		this.customerEmail = customerEmail;
	}
 
	public String getCustomerPassword() {
		return customerPassword;
	}
 
	public void setCustomerPassword(String customerPassword) {
		this.customerPassword = customerPassword;
	}
 
	public String getCustomerPhone() {
		return customerPhone;
	}
 
	public void setCustomerPhone(String customerPhone) {
		this.customerPhone = customerPhone;
	}
 
 
 
	@Override
	public int compareTo(Customer o) {    // customer1.compareTo(customer2)
		if (this.customerId > o.customerId) {
			return 1;
		} else if (this.customerId < o.customerId) {
			return -1;
		}
		return 0;
	}
 
 
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!(obj instanceof Customer)) {
			return false;
		}
		
		Customer customer=(Customer)obj;
		if (this.customerId == customer.customerId && this.customerName.equals(customer.customerName)
				&& this.customerEmail.equals(customer.customerEmail)
				&& this.customerPassword.equals(customer.customerPassword)
				&& this.customerPhone.equals(customer.customerPhone)) {
			return true;
		}
		return false;
	}
	
	
	

}
