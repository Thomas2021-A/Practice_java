<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Customer Login</title>
  <style>
    :root {
      color-scheme: light;
      font-family: Arial, sans-serif;
      background: #f4f6f8;
      color: #1f2933;
    }
 
    * {
      box-sizing: border-box;
    }
 
    body {
      min-height: 100vh;
      margin: 0;
      display: grid;
      place-items: center;
      padding: 1.5rem;
    }
 
    main {
      width: 100%;
      max-width: 25rem;
    }
 
    form {
      background: #ffffff;
      padding: 2rem;
      border-radius: 0.75rem;
      box-shadow: 0 0.5rem 1.5rem rgba(31, 41, 51, 0.12);
    }
 
    h1 {
      margin: 0 0 0.5rem;
      font-size: 1.5rem;
    }
 
    .intro {
      margin: 0 0 1.5rem;
      color: #52606d;
    }
 
    .field {
      margin-bottom: 1rem;
    }
 
    label {
      display: block;
      margin-bottom: 0.4rem;
      font-weight: 600;
    }
 
    input {
      width: 100%;
      padding: 0.7rem 0.8rem;
      border: 1px solid #9aa5b1;
      border-radius: 0.375rem;
      font: inherit;
    }
 
    input:focus {
      outline: 3px solid rgba(37, 99, 235, 0.25);
      border-color: #2563eb;
    }
 
    button {
      width: 100%;
      padding: 0.75rem 1rem;
      border: 0;
      border-radius: 0.375rem;
      background: #2563eb;
      color: #ffffff;
      font: inherit;
      font-weight: 600;
      cursor: pointer;
    }
 
    button:hover,
    button:focus-visible {
      background: #1d4ed8;
    }
 
    button:focus-visible {
      outline: 3px solid rgba(37, 99, 235, 0.35);
      outline-offset: 2px;
    }
  </style>
</head>
<body>
  <main>
    <form action="${pageContext.request.contextPath}/api/customers/login " method="post">
      <h1>Customer Login</h1>
      <p class="intro">Sign in to access your account.</p>
      <div>
      	<p>${msg}</p>
      </div>
 
      <div class="field">
        <label for="customerEmail">Email address</label>
        <input type="email" id="customerEmail" name="customerEmail" autocomplete="email" required>
      </div>
 
      <div class="field">
        <label for="customerPassword">Password</label>
        <input type="password" id="customerPassword" name="customerPassword" autocomplete="current-password" required>
      </div>
 
      <button type="submit">Log in</button>
    </form>
  </main>
</body>
</html>