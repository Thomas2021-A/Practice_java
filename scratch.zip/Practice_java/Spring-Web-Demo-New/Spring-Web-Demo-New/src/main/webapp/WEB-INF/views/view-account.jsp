<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<%@taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
	<div>
		<p>${msg}</p>
	</div>
	<div>
		<p>
			<a href="${pageContext.request.contextPath}/api/customers/profile">Profile</a>
		</p>
		<p>
			<a href="${pageContext.request.contextPath}/api/customers/view-account">Account</a>
		</p>
		<p>
			<span>Welcome,${customer.customerName}</span>
		</p>
		<p>
			<a href="${pageContext.request.contextPath}/api/customers/logout">Logout</a>
		</p>
	</div>
	<c:if test="${not empty account }">
		<table>
			<tr>
				<td>Account Number</td>
				<td>${account.accountNo }</td>
			</tr>
			<tr>
				<td>Account Type</td>
				<td>${account.accountType }</td>
			</tr>
			<tr>
				<td>Balance</td>
				<td>${account.accountBalance }</td>
			</tr>

		</table>
	</c:if>
	<c:if test="${empty account }">
		<p>No account found for this customer</p>
	</c:if>
</body>
</html>