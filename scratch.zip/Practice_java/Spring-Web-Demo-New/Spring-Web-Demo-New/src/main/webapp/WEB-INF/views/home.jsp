<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
	<h2>Welcome to Customer Management web app</h2>
	<div>
		<a href="${pageContext.request.contextPath}/api/customers/signup ">Sign
			Up</a>
	</div>


	<div>
		<a href="${pageContext.request.contextPath}/api/customers/login ">Login</a>
	</div>

	<div>
		<a href="${pageContext.request.contextPath}/api/customers ">View All Customers</a>
	</div>


</body>
</html>
