<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
	<div>
		<p>
			<a href="${pageContext.request.contextPath}/api/customers/profile">Profile</a>
		</p>
		<p>
			<a href="${pageContext.request.contextPath}/api/customers/account">Account</a>
		</p>
		<p>
			<span>Welcome, ${customer.customerName} </span>
		</p>
		<p>
			<a href="${pageContext.request.contextPath}/api/customers/logout">Logout</a>
		</p>

	</div>
	<h2>Welcome to Dashboard!!</h2>
</body>
</html>