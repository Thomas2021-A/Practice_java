<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
 
<%@taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
<h2>Customer List</h2>
	<table border="1">
		<tr>
			<th>Customer ID</th>
			<th>Name</th>
			<th>Email</th>
			<th>Phone</th>
			<th>Action</th>
		</tr>
		<c:forEach var="customer" items="${customers}">
			<tr>
				<td>${customer.customerId }</td>
				<td>${customer.customerName }</td>
				<td>${customer.customerEmail }</td>
				<td>${customer.customerPhone }</td>
				<td><a
					href="${pageContext.request.contextPath}/api/customers/account/${customer.customerId }">View
						Account</a>
					<a href="${pageContext.request.contextPath}/api/customers/delete?customerId=${customer.customerId }">Delete</a>
				</td>
				
			</tr>
		</c:forEach>
	</table>
</body>
</html>