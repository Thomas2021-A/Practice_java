<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Customer Registration</title>
<style>
:root {
	color-scheme: light;
	--page-background: #f4f7fb;
	--card-background: #ffffff;
	--text-color: #1f2937;
	--muted-color: #5b6472;
	--border-color: #cbd5e1;
	--focus-color: #2563eb;
	--button-color: #1d4ed8;
	--button-hover: #1e40af;
}

* {
	box-sizing: border-box;
}

body {
	margin: 0;
	min-height: 100vh;
	display: grid;
	place-items: center;
	padding: 2rem 1rem;
	background: var(--page-background);
	color: var(--text-color);
	font-family: Arial, Helvetica, sans-serif;
	line-height: 1.5;
}

main {
	width: min(100%, 32rem);
}

.registration-card {
	padding: clamp(1.5rem, 5vw, 2.5rem);
	background: var(--card-background);
	border: 1px solid #e2e8f0;
	border-radius: 0.75rem;
	box-shadow: 0 12px 30px rgba(15, 23, 42, 0.1);
}

h1 {
	margin: 0;
	font-size: clamp(1.5rem, 4vw, 2rem);
	line-height: 1.2;
}

.intro {
	margin: 0.5rem 0 1.75rem;
	color: var(--muted-color);
}

.form-group {
	margin-bottom: 1.25rem;
}

label {
	display: block;
	margin-bottom: 0.4rem;
	font-weight: 700;
}

.required {
	color: #b91c1c;
}

input {
	width: 100%;
	min-height: 2.8rem;
	padding: 0.65rem 0.75rem;
	border: 1px solid var(--border-color);
	border-radius: 0.4rem;
	background: #ffffff;
	color: var(--text-color);
	font: inherit;
}

input:focus {
	outline: 3px solid rgba(37, 99, 235, 0.25);
	outline-offset: 1px;
	border-color: var(--focus-color);
}

input::placeholder {
	color: #7c8798;
}

button {
	width: 100%;
	min-height: 2.8rem;
	padding: 0.7rem 1rem;
	border: 0;
	border-radius: 0.4rem;
	background: var(--button-color);
	color: #ffffff;
	cursor: pointer;
	font: inherit;
	font-weight: 700;
}

button:hover {
	background: var(--button-hover);
}

button:focus-visible {
	outline: 3px solid rgba(37, 99, 235, 0.4);
	outline-offset: 3px;
}

.required-note {
	margin: 0 0 1.25rem;
	color: var(--muted-color);
	font-size: 0.9rem;
}
</style>
</head>
<body>
	<main>
		<section class="registration-card" aria-labelledby="form-heading">
			<h1 id="form-heading">Customer Registration</h1>
			<p class="intro">Create your customer account by completing the
				form below.</p>
			<form action="${pageContext.request.contextPath}/api/customers/signup" method="post">
				<div>
					<p>${msg}</p>
				</div>
				<p class="required-note">
					<span class="required" aria-hidden="true">*</span> Required fields
				</p>
				<div class="form-group">
					<label for="customerName">Full name <span class="required"
						aria-hidden="true">*</span></label><input id="customerName"
						name="customerName" type="text" autocomplete="name" required>
				</div>
				<div class="form-group">
					<label for="customerEmail">Email address <span
						class="required" aria-hidden="true">*</span></label><input
						id="customerEmail" name="customerEmail" type="email"
						autocomplete="email" required>
				</div>
				<div class="form-group">
					<label for="customerPassword">Password <span
						class="required" aria-hidden="true">*</span></label><input
						id="customerPassword" name="customerPassword" type="password"
						autocomplete="new-password" minlength="8" required>
				</div>
				<div class="form-group">
					<label for="customerPhone">Phone number <span
						class="required" aria-hidden="true">*</span></label><input
						id="customerPhone" name="customerPhone" type="tel"
						autocomplete="tel" inputmode="tel" required>
				</div>
				<button type="submit">Register</button>
			</form>
		</section>
	</main>
</body>
</html>