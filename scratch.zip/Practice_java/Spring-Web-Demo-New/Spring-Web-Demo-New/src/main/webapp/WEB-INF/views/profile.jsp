<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>My Profile</title>
<style>
:root {
	--accent: #86BC25;
	--accent-dark: #416800;
	--accent-soft: #eef7df;
	--ink: #202821;
	--muted: #627064;
	--line: #d9e0d8;
	--surface: #ffffff;
	--page: #f5f7f4;
}

* {
	box-sizing: border-box;
}

body {
	min-width: 320px;
	min-height: 100vh;
	min-height: 100svh;
	margin: 0;
	display: grid;
	place-items: center;
	padding: 32px 20px;
	background: var(--page);
	color: var(--ink);
	font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI",
		sans-serif;
}

main {
	width: min(100%, 640px);
}

.profile-card {
	position: relative;
	overflow: hidden;
	border: 1px solid var(--line);
	border-radius: 16px;
	background: var(--surface);
	box-shadow: 0 12px 30px rgba(31, 46, 32, 0.08);
}

.profile-card::before {
	position: absolute;
	inset: 0 0 auto;
	height: 6px;
	background: var(--accent);
	content: "";
}

.profile-header {
	display: flex;
	align-items: center;
	gap: 16px;
	padding: 36px 32px 24px;
	border-bottom: 1px solid var(--line);
}

.avatar {
	display: grid;
	width: 52px;
	height: 52px;
	flex: 0 0 auto;
	place-items: center;
	border-radius: 50%;
	background: var(--accent-soft);
	color: var(--accent-dark);
	font-size: 1.05rem;
	font-weight: 750;
}

.eyebrow {
	margin: 0 0 4px;
	color: var(--accent-dark);
	font-size: 0.78rem;
	font-weight: 750;
	letter-spacing: 0.08em;
	text-transform: uppercase;
}

h1 {
	margin: 0;
	font-size: clamp(1.65rem, 4vw, 2rem);
	line-height: 1.15;
}

.profile-body {
	padding: 28px 32px 32px;
}

.intro {
	margin: 0 0 24px;
	color: var(--muted);
	font-size: 0.95rem;
	line-height: 1.5;
}

.details {
	display: grid;
	gap: 18px;
	margin: 0;
}

.field {
	display: grid;
	gap: 7px;
}

label {
	color: #364037;
	font-size: 0.88rem;
	font-weight: 700;
}

input[readonly] {
	width: 100%;
	min-height: 48px;
	appearance: none;
	border: 1px solid var(--line);
	border-radius: 8px;
	outline: none;
	background: #fafcf9;
	color: var(--ink);
	font: inherit;
	padding: 12px 14px;
	cursor: default;
}

input[readonly]:focus-visible {
	border-color: var(--accent-dark);
	box-shadow: 0 0 0 3px rgba(134, 188, 37, 0.28);
}

.actions {
	display: flex;
	justify-content: flex-end;
	margin-top: 28px;
	padding-top: 24px;
	border-top: 1px solid var(--line);
}

button {
	min-height: 44px;
	border: 1px solid var(--accent-dark);
	border-radius: 8px;
	background: var(--accent);
	color: #1f3100;
	cursor: pointer;
	font: inherit;
	font-weight: 750;
	padding: 10px 18px;
}

button:hover {
	background: #96ca37;
}

button:focus-visible {
	outline: 3px solid rgba(65, 104, 0, 0.35);
	outline-offset: 3px;
}

@media ( max-width : 480px) {
	body {
		padding: 18px 14px;
	}
	.profile-header {
		padding: 30px 22px 20px;
	}
	.profile-body {
		padding: 24px 22px 26px;
	}
	.actions {
		justify-content: stretch;
	}
	button {
		width: 100%;
	}
}
</style>
</head>
<body>
	<main>
		<section class="profile-card" aria-labelledby="page-title">
			<header class="profile-header">
				<div class="avatar" aria-hidden="true">AM</div>
				<div>
					<p class="eyebrow">Customer account</p>
					<h1 id="page-title">My Profile</h1>
				</div>
			</header>

			<div class="profile-body">
				<p class="intro">Your account contact details are shown below.</p>

				<form
					action="${pageContext.request.contextPath}/api/customers/profile"
					method="post" class="details"
					aria-label="Read-only profile details">
					<div>
						<p>${msg}</p>
					</div>

					<div class="field">
						<label for="customerName">Customer name</label> <input
							id="customerName" name="customerName" type="text"
							value="${customer.customerName }" autocomplete="name"
							aria-readonly="true">
					</div>

					<div class="field">
						<label for="customerEmail">Customer email</label> <input
							id="customerEmail" name="customerEmail" type="email"
							value="${customer.customerEmail }" autocomplete="email"
							aria-readonly="true" spellcheck="false">
					</div>


					<div class="field">
						<label for="customerPhone">Customer phone</label> <input
							id="customerPhone" name="customerPhone" type="tel"
							value="${customer.customerPhone}" autocomplete="tel"
							aria-readonly="true">
					</div>
					
					<div class="actions">
					<button type="submit">Update profile</button>
				</div>
				
				</form>

				
			</div>
		</section>
	</main>
</body>
</html>