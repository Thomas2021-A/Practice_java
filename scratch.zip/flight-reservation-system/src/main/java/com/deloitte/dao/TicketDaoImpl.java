package com.deloitte.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.deloitte.model.Ticket;

@Repository
public class TicketDaoImpl implements TicketDao {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    private RowMapper<Ticket> ticketRowMapper = (rs, rowNum) -> {
        Ticket ticket = new Ticket();
        ticket.setPnrNo(rs.getLong("pnr_no"));
        ticket.setPassengerName(rs.getString("passenger_name"));
        ticket.setGender(rs.getString("gender"));
        ticket.setAge(rs.getInt("age"));
        ticket.setJourneyDate(rs.getDate("journey_date"));
        ticket.setSeatNo(rs.getString("seat_no"));
        ticket.setBookingId(rs.getLong("booking_id"));
        ticket.setStatus(rs.getString("status"));

        try {
            ticket.setFlightNumber(rs.getString("flight_number"));
            ticket.setSource(rs.getString("source"));
            ticket.setDestination(rs.getString("destination"));
            ticket.setDepartureTime(rs.getString("departure_time"));
        } catch (Exception e) {
            // Joined fields might not be present in basic queries
        }

        return ticket;
    };

    public TicketDaoImpl() {
    }

    public TicketDaoImpl(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    @Override
    public int insertTicket(Ticket ticket) {
        String sql = "INSERT INTO ticket (passenger_name, gender, age, journey_date, seat_no, booking_id, status) "
                   + "VALUES (?, ?, ?, ?, ?, ?, ?)";
        return jdbcTemplate.update(sql, ticket.getPassengerName(), ticket.getGender(), ticket.getAge(),
                ticket.getJourneyDate(), ticket.getSeatNo(), ticket.getBookingId(), ticket.getStatus());
    }

    @Override
    public List<Ticket> getTicketsByBookingId(long bookingId) {
        String sql = "SELECT t.*, f.flight_number, f.source, f.destination, f.departure_time "
                   + "FROM ticket t "
                   + "JOIN booking b ON t.booking_id = b.booking_id "
                   + "JOIN flight f ON b.flight_id = f.flight_id "
                   + "WHERE t.booking_id = ? "
                   + "ORDER BY t.pnr_no ASC";
        return jdbcTemplate.query(sql, ticketRowMapper, bookingId);
    }

    @Override
    public int updateTicketStatusByBookingId(long bookingId, String status) {
        String sql = "UPDATE ticket SET status = ? WHERE booking_id = ?";
        return jdbcTemplate.update(sql, status, bookingId);
    }
}
