package com.deloitte.dao;

import java.sql.Date;
import java.util.List;

import com.deloitte.dto.FlightSummaryDto;
import com.deloitte.model.Booking;

public interface BookingDao {
    long createBooking(Booking booking);
    Booking getBookingById(long bookingId);
    List<Booking> getBookingsByUserId(long userId);
    int updateBookingStatus(long bookingId, String status);
    int getBookedSeatsCount(long flightId, Date journeyDate);
    List<FlightSummaryDto> getFlightJourneySummaries();
}
