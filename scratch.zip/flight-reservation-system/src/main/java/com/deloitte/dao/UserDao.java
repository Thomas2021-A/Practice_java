package com.deloitte.dao;

import com.deloitte.model.User;

public interface UserDao {
    int insertUser(User user);
    User getUserByEmailAndPassword(String email, String password);
    User getUserByEmail(String email);
    User getUserById(long userId);
}
