package com.deloitte.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.deloitte.model.Flight;

@Repository
public class FlightDaoImpl implements FlightDao {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    private RowMapper<Flight> flightRowMapper = (rs, rowNum) -> {
        Flight flight = new Flight();
        flight.setFlightId(rs.getLong("flight_id"));
        flight.setFlightNumber(rs.getString("flight_number"));
        flight.setSource(rs.getString("source"));
        flight.setDestination(rs.getString("destination"));
        flight.setDepartureTime(rs.getString("departure_time"));
        flight.setArrivalTime(rs.getString("arrival_time"));
        flight.setCapacity(rs.getInt("capacity"));
        flight.setPricePerSeat(rs.getDouble("price_per_seat"));
        return flight;
    };

    public FlightDaoImpl() {
    }

    public FlightDaoImpl(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    @Override
    public int insertFlight(Flight flight) {
        String sql = "INSERT INTO flight (flight_number, source, destination, departure_time, arrival_time, capacity, price_per_seat) "
                   + "VALUES (?, ?, ?, ?, ?, ?, ?)";
        return jdbcTemplate.update(sql, flight.getFlightNumber(), flight.getSource(), flight.getDestination(),
                flight.getDepartureTime(), flight.getArrivalTime(), flight.getCapacity(), flight.getPricePerSeat());
    }

    @Override
    public Flight getFlightById(long flightId) {
        String sql = "SELECT * FROM flight WHERE flight_id = ?";
        try {
            return jdbcTemplate.queryForObject(sql, flightRowMapper, flightId);
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    public Flight getFlightByNumber(String flightNumber) {
        String sql = "SELECT * FROM flight WHERE flight_number = ?";
        try {
            return jdbcTemplate.queryForObject(sql, flightRowMapper, flightNumber);
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    public List<Flight> searchFlights(String source, String destination) {
        String sql = "SELECT * FROM flight WHERE LOWER(TRIM(source)) = LOWER(TRIM(?)) "
                   + "AND LOWER(TRIM(destination)) = LOWER(TRIM(?)) ORDER BY departure_time ASC";
        return jdbcTemplate.query(sql, flightRowMapper, source, destination);
    }

    @Override
    public List<Flight> getAllFlights() {
        String sql = "SELECT * FROM flight ORDER BY flight_id DESC";
        return jdbcTemplate.query(sql, flightRowMapper);
    }
}
