package com.deloitte.dao;

import java.util.List;
import com.deloitte.model.Ticket;

public interface TicketDao {
    int insertTicket(Ticket ticket);
    List<Ticket> getTicketsByBookingId(long bookingId);
    int updateTicketStatusByBookingId(long bookingId, String status);
}
