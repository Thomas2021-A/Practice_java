package com.deloitte.dao;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import com.deloitte.dto.FlightSummaryDto;
import com.deloitte.model.Booking;

@Repository
public class BookingDaoImpl implements BookingDao {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    private RowMapper<Booking> bookingRowMapper = (rs, rowNum) -> {
        Booking booking = new Booking();
        booking.setBookingId(rs.getLong("booking_id"));
        booking.setBookingDate(rs.getDate("booking_date"));
        booking.setJourneyDate(rs.getDate("journey_date"));
        booking.setSeats(rs.getInt("seats"));
        booking.setTotalPrice(rs.getDouble("total_price"));
        booking.setStatus(rs.getString("status"));
        booking.setFlightId(rs.getLong("flight_id"));
        booking.setUserId(rs.getLong("user_id"));

        // If joined with flight table
        try {
            booking.setFlightNumber(rs.getString("flight_number"));
            booking.setSource(rs.getString("source"));
            booking.setDestination(rs.getString("destination"));
        } catch (Exception e) {
            // Columns might not exist in plain query
        }
        return booking;
    };

    public BookingDaoImpl() {
    }

    public BookingDaoImpl(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    @Override
    public long createBooking(Booking booking) {
        String sql = "INSERT INTO booking (booking_date, journey_date, seats, total_price, status, flight_id, user_id) "
                   + "VALUES (?, ?, ?, ?, ?, ?, ?)";
        KeyHolder keyHolder = new GeneratedKeyHolder();

        jdbcTemplate.update(connection -> {
            PreparedStatement ps = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            ps.setDate(1, booking.getBookingDate());
            ps.setDate(2, booking.getJourneyDate());
            ps.setInt(3, booking.getSeats());
            ps.setDouble(4, booking.getTotalPrice());
            ps.setString(5, booking.getStatus());
            ps.setLong(6, booking.getFlightId());
            ps.setLong(7, booking.getUserId());
            return ps;
        }, keyHolder);

        Number key = keyHolder.getKey();
        return (key != null) ? key.longValue() : 0L;
    }

    @Override
    public Booking getBookingById(long bookingId) {
        String sql = "SELECT b.*, f.flight_number, f.source, f.destination FROM booking b "
                   + "JOIN flight f ON b.flight_id = f.flight_id WHERE b.booking_id = ?";
        try {
            return jdbcTemplate.queryForObject(sql, bookingRowMapper, bookingId);
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    public List<Booking> getBookingsByUserId(long userId) {
        String sql = "SELECT b.*, f.flight_number, f.source, f.destination FROM booking b "
                   + "JOIN flight f ON b.flight_id = f.flight_id WHERE b.user_id = ? "
                   + "ORDER BY b.booking_id DESC";
        return jdbcTemplate.query(sql, bookingRowMapper, userId);
    }

    @Override
    public int updateBookingStatus(long bookingId, String status) {
        String sql = "UPDATE booking SET status = ? WHERE booking_id = ?";
        return jdbcTemplate.update(sql, status, bookingId);
    }

    @Override
    public int getBookedSeatsCount(long flightId, Date journeyDate) {
        String sql = "SELECT COALESCE(SUM(seats), 0) FROM booking WHERE flight_id = ? AND journey_date = ? AND status = 'BOOKED'";
        Integer count = jdbcTemplate.queryForObject(sql, Integer.class, flightId, journeyDate);
        return (count != null) ? count : 0;
    }

    @Override
    public List<FlightSummaryDto> getFlightJourneySummaries() {
        String sql = "SELECT f.flight_number, b.journey_date, "
                   + "SUM(b.seats) AS total_passengers, "
                   + "COUNT(b.booking_id) AS total_bookings, "
                   + "SUM(b.total_price) AS total_revenue, "
                   + "DATEDIFF(b.journey_date, CURDATE()) AS days_diff "
                   + "FROM booking b "
                   + "JOIN flight f ON b.flight_id = f.flight_id "
                   + "WHERE b.status = 'BOOKED' "
                   + "GROUP BY f.flight_number, b.journey_date "
                   + "ORDER BY b.journey_date ASC";

        return jdbcTemplate.query(sql, (rs, rowNum) -> {
            FlightSummaryDto dto = new FlightSummaryDto();
            dto.setFlightNumber(rs.getString("flight_number"));
            dto.setJourneyDate(rs.getDate("journey_date"));
            dto.setTotalPassengers(rs.getInt("total_passengers"));
            dto.setTotalBookings(rs.getInt("total_bookings"));
            dto.setTotalRevenue(rs.getDouble("total_revenue"));

            int daysDiff = rs.getInt("days_diff");
            if (daysDiff < 0) {
                dto.setCompleted(true);
                dto.setDaysUntilJourney("Completed");
            } else if (daysDiff == 0) {
                dto.setCompleted(false);
                dto.setDaysUntilJourney("Today");
            } else if (daysDiff == 1) {
                dto.setCompleted(false);
                dto.setDaysUntilJourney("1 day");
            } else {
                dto.setCompleted(false);
                dto.setDaysUntilJourney(daysDiff + " days");
            }
            return dto;
        });
    }
}
