package com.deloitte.model;

public class Flight {
    private long flightId;
    private String flightNumber;
    private String source;
    private String destination;
    private String departureTime;
    private String arrivalTime;
    private int capacity;
    private double pricePerSeat;

    public Flight() {
        this.capacity = 20; // Default capacity as per requirement
    }

    public Flight(long flightId, String flightNumber, String source, String destination, 
                  String departureTime, String arrivalTime, int capacity, double pricePerSeat) {
        this.flightId = flightId;
        this.flightNumber = flightNumber;
        this.source = source;
        this.destination = destination;
        this.departureTime = departureTime;
        this.arrivalTime = arrivalTime;
        this.capacity = capacity;
        this.pricePerSeat = pricePerSeat;
    }

    public Flight(String flightNumber, String source, String destination, 
                  String departureTime, String arrivalTime, int capacity, double pricePerSeat) {
        this.flightNumber = flightNumber;
        this.source = source;
        this.destination = destination;
        this.departureTime = departureTime;
        this.arrivalTime = arrivalTime;
        this.capacity = capacity;
        this.pricePerSeat = pricePerSeat;
    }

    public long getFlightId() {
        return flightId;
    }

    public void setFlightId(long flightId) {
        this.flightId = flightId;
    }

    public String getFlightNumber() {
        return flightNumber;
    }

    public void setFlightNumber(String flightNumber) {
        this.flightNumber = flightNumber;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    public String getDepartureTime() {
        return departureTime;
    }

    public void setDepartureTime(String departureTime) {
        this.departureTime = departureTime;
    }

    public String getArrivalTime() {
        return arrivalTime;
    }

    public void setArrivalTime(String arrivalTime) {
        this.arrivalTime = arrivalTime;
    }

    public int getCapacity() {
        return capacity;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    public double getPricePerSeat() {
        return pricePerSeat;
    }

    public void setPricePerSeat(double pricePerSeat) {
        this.pricePerSeat = pricePerSeat;
    }

    @Override
    public String toString() {
        return "Flight [flightId=" + flightId + ", flightNumber=" + flightNumber + ", source=" + source
                + ", destination=" + destination + ", departureTime=" + departureTime + ", arrivalTime=" + arrivalTime
                + ", capacity=" + capacity + ", pricePerSeat=" + pricePerSeat + "]";
    }
}
