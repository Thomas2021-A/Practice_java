package com.deloitte.model;

import java.sql.Date;

public class Booking {
    private long bookingId;
    private Date bookingDate;
    private Date journeyDate;
    private int seats;
    private double totalPrice;
    private String status; // "BOOKED", "CANCELLED"
    private long flightId;
    private long userId;

    // Additional display fields for convenience in views
    private String flightNumber;
    private String source;
    private String destination;

    public Booking() {
        this.status = "BOOKED";
    }

    public Booking(long bookingId, Date bookingDate, Date journeyDate, int seats, double totalPrice, 
                   String status, long flightId, long userId) {
        this.bookingId = bookingId;
        this.bookingDate = bookingDate;
        this.journeyDate = journeyDate;
        this.seats = seats;
        this.totalPrice = totalPrice;
        this.status = status;
        this.flightId = flightId;
        this.userId = userId;
    }

    public long getBookingId() {
        return bookingId;
    }

    public void setBookingId(long bookingId) {
        this.bookingId = bookingId;
    }

    public Date getBookingDate() {
        return bookingDate;
    }

    public void setBookingDate(Date bookingDate) {
        this.bookingDate = bookingDate;
    }

    public Date getJourneyDate() {
        return journeyDate;
    }

    public void setJourneyDate(Date journeyDate) {
        this.journeyDate = journeyDate;
    }

    public int getSeats() {
        return seats;
    }

    public void setSeats(int seats) {
        this.seats = seats;
    }

    public double getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(double totalPrice) {
        this.totalPrice = totalPrice;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public long getFlightId() {
        return flightId;
    }

    public void setFlightId(long flightId) {
        this.flightId = flightId;
    }

    public long getUserId() {
        return userId;
    }

    public void setUserId(long userId) {
        this.userId = userId;
    }

    public String getFlightNumber() {
        return flightNumber;
    }

    public void setFlightNumber(String flightNumber) {
        this.flightNumber = flightNumber;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    @Override
    public String toString() {
        return "Booking [bookingId=" + bookingId + ", journeyDate=" + journeyDate + ", seats=" + seats
                + ", totalPrice=" + totalPrice + ", status=" + status + ", flightId=" + flightId + ", userId=" + userId
                + "]";
    }
}
