package com.deloitte.model;

import java.sql.Date;

public class Ticket {
    private long pnrNo;
    private String passengerName;
    private String gender;
    private int age;
    private Date journeyDate;
    private String seatNo;
    private long bookingId;
    private String status; // "BOOKED", "CANCELLED"

    // Additional flight information for boarding pass display
    private String flightNumber;
    private String source;
    private String destination;
    private String departureTime;

    public Ticket() {
        this.status = "BOOKED";
    }

    public Ticket(long pnrNo, String passengerName, String gender, int age, 
                  Date journeyDate, String seatNo, long bookingId, String status) {
        this.pnrNo = pnrNo;
        this.passengerName = passengerName;
        this.gender = gender;
        this.age = age;
        this.journeyDate = journeyDate;
        this.seatNo = seatNo;
        this.bookingId = bookingId;
        this.status = status;
    }

    public long getPnrNo() {
        return pnrNo;
    }

    public void setPnrNo(long pnrNo) {
        this.pnrNo = pnrNo;
    }

    public String getPassengerName() {
        return passengerName;
    }

    public void setPassengerName(String passengerName) {
        this.passengerName = passengerName;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public Date getJourneyDate() {
        return journeyDate;
    }

    public void setJourneyDate(Date journeyDate) {
        this.journeyDate = journeyDate;
    }

    public String getSeatNo() {
        return seatNo;
    }

    public void setSeatNo(String seatNo) {
        this.seatNo = seatNo;
    }

    public long getBookingId() {
        return bookingId;
    }

    public void setBookingId(long bookingId) {
        this.bookingId = bookingId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getFlightNumber() {
        return flightNumber;
    }

    public void setFlightNumber(String flightNumber) {
        this.flightNumber = flightNumber;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    public String getDepartureTime() {
        return departureTime;
    }

    public void setDepartureTime(String departureTime) {
        this.departureTime = departureTime;
    }

    @Override
    public String toString() {
        return "Ticket [pnrNo=" + pnrNo + ", passengerName=" + passengerName + ", seatNo=" + seatNo
                + ", bookingId=" + bookingId + ", status=" + status + "]";
    }
}
