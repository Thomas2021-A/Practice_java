package com.deloitte.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.deloitte.dao.FlightDao;
import com.deloitte.model.Flight;

@Service
public class FlightServiceImpl implements FlightService {

    @Autowired
    private FlightDao flightDao;

    public FlightServiceImpl() {
    }

    public FlightServiceImpl(FlightDao flightDao) {
        this.flightDao = flightDao;
    }

    @Override
    public int addFlight(Flight flight) {
        if (!isFlightNumberUnique(flight.getFlightNumber())) {
            return 0; // Flight number already exists
        }
        if (flight.getCapacity() <= 0) {
            flight.setCapacity(20); // Default capacity
        }
        return flightDao.insertFlight(flight);
    }

    @Override
    public Flight getFlightById(long flightId) {
        return flightDao.getFlightById(flightId);
    }

    @Override
    public Flight getFlightByNumber(String flightNumber) {
        if (flightNumber == null) return null;
        return flightDao.getFlightByNumber(flightNumber.trim());
    }

    @Override
    public List<Flight> searchFlights(String source, String destination) {
        if (source == null || destination == null) {
            return flightDao.getAllFlights();
        }
        return flightDao.searchFlights(source.trim(), destination.trim());
    }

    @Override
    public List<Flight> getAllFlights() {
        return flightDao.getAllFlights();
    }

    @Override
    public boolean isFlightNumberUnique(String flightNumber) {
        if (flightNumber == null || flightNumber.trim().isEmpty()) {
            return false;
        }
        return flightDao.getFlightByNumber(flightNumber.trim()) == null;
    }
}
