package com.deloitte.service;

import java.sql.Date;
import java.util.List;

import com.deloitte.dto.FlightSummaryDto;
import com.deloitte.dto.PassengerDto;
import com.deloitte.model.Booking;
import com.deloitte.model.Ticket;

public interface BookingService {
    int getAvailableSeats(long flightId, Date journeyDate);
    long completeBooking(long flightId, long userId, Date journeyDate, List<PassengerDto> passengers);
    List<Booking> getUserBookings(long userId);
    Booking getBookingDetails(long bookingId);
    boolean cancelBooking(long bookingId);
    List<Ticket> getTicketsForBooking(long bookingId);
    List<FlightSummaryDto> getFlightJourneySummaries();
}
