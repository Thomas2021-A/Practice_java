package com.deloitte.service;

import com.deloitte.dto.LoginDto;
import com.deloitte.dto.SignUpDto;
import com.deloitte.model.User;

public interface UserService {
    int registerUser(SignUpDto signUpDto);
    User authenticate(LoginDto loginDto);
    boolean isEmailAvailable(String email);
    User findByEmail(String email);
    User findById(long userId);
}
