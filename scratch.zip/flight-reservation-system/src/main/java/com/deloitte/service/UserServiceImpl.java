package com.deloitte.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.deloitte.dao.UserDao;
import com.deloitte.dto.LoginDto;
import com.deloitte.dto.SignUpDto;
import com.deloitte.model.User;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserDao userDao;

    public UserServiceImpl() {
    }

    public UserServiceImpl(UserDao userDao) {
        this.userDao = userDao;
    }

    @Override
    public int registerUser(SignUpDto signUpDto) {
        if (!isEmailAvailable(signUpDto.getEmail())) {
            return 0; // Email already in use
        }
        User user = new User(signUpDto.getEmail().trim(), signUpDto.getPassword(), signUpDto.getRole());
        return userDao.insertUser(user);
    }

    @Override
    public User authenticate(LoginDto loginDto) {
        if (loginDto == null || loginDto.getEmail() == null || loginDto.getPassword() == null) {
            return null;
        }
        return userDao.getUserByEmailAndPassword(loginDto.getEmail().trim(), loginDto.getPassword());
    }

    @Override
    public boolean isEmailAvailable(String email) {
        if (email == null || email.trim().isEmpty()) {
            return false;
        }
        return userDao.getUserByEmail(email.trim()) == null;
    }

    @Override
    public User findByEmail(String email) {
        if (email == null) return null;
        return userDao.getUserByEmail(email.trim());
    }

    @Override
    public User findById(long userId) {
        return userDao.getUserById(userId);
    }
}
