package com.deloitte.dto;

public class PassengerDto {
    private String passengerName;
    private int age;
    private String gender; // "Male", "Female", "Other"

    public PassengerDto() {
    }

    public PassengerDto(String passengerName, int age, String gender) {
        this.passengerName = passengerName;
        this.age = age;
        this.gender = gender;
    }

    public String getPassengerName() {
        return passengerName;
    }

    public void setPassengerName(String passengerName) {
        this.passengerName = passengerName;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }
}
