package com.deloitte.dto;

public class BookingFormDto {
    private Long flightId;
    private String flightNumber;
    private String journeyDate; // formatted yyyy-MM-dd
    private int numberOfPassengers;

    public BookingFormDto() {
        this.numberOfPassengers = 1;
    }

    public BookingFormDto(Long flightId, String flightNumber, String journeyDate, int numberOfPassengers) {
        this.flightId = flightId;
        this.flightNumber = flightNumber;
        this.journeyDate = journeyDate;
        this.numberOfPassengers = numberOfPassengers;
    }

    public Long getFlightId() {
        return flightId;
    }

    public void setFlightId(Long flightId) {
        this.flightId = flightId;
    }

    public String getFlightNumber() {
        return flightNumber;
    }

    public void setFlightNumber(String flightNumber) {
        this.flightNumber = flightNumber;
    }

    public String getJourneyDate() {
        return journeyDate;
    }

    public void setJourneyDate(String journeyDate) {
        this.journeyDate = journeyDate;
    }

    public int getNumberOfPassengers() {
        return numberOfPassengers;
    }

    public void setNumberOfPassengers(int numberOfPassengers) {
        this.numberOfPassengers = numberOfPassengers;
    }
}
