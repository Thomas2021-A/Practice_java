package com.deloitte.dto;

import java.sql.Date;

public class FlightSummaryDto {
    private String flightNumber;
    private Date journeyDate;
    private int totalPassengers;
    private int totalBookings;
    private double totalRevenue;
    private String daysUntilJourney;
    private boolean completed;

    public FlightSummaryDto() {
    }

    public FlightSummaryDto(String flightNumber, Date journeyDate, int totalPassengers, 
                            int totalBookings, double totalRevenue, String daysUntilJourney, boolean completed) {
        this.flightNumber = flightNumber;
        this.journeyDate = journeyDate;
        this.totalPassengers = totalPassengers;
        this.totalBookings = totalBookings;
        this.totalRevenue = totalRevenue;
        this.daysUntilJourney = daysUntilJourney;
        this.completed = completed;
    }

    public String getFlightNumber() {
        return flightNumber;
    }

    public void setFlightNumber(String flightNumber) {
        this.flightNumber = flightNumber;
    }

    public Date getJourneyDate() {
        return journeyDate;
    }

    public void setJourneyDate(Date journeyDate) {
        this.journeyDate = journeyDate;
    }

    public int getTotalPassengers() {
        return totalPassengers;
    }

    public void setTotalPassengers(int totalPassengers) {
        this.totalPassengers = totalPassengers;
    }

    public int getTotalBookings() {
        return totalBookings;
    }

    public void setTotalBookings(int totalBookings) {
        this.totalBookings = totalBookings;
    }

    public double getTotalRevenue() {
        return totalRevenue;
    }

    public void setTotalRevenue(double totalRevenue) {
        this.totalRevenue = totalRevenue;
    }

    public String getDaysUntilJourney() {
        return daysUntilJourney;
    }

    public void setDaysUntilJourney(String daysUntilJourney) {
        this.daysUntilJourney = daysUntilJourney;
    }

    public boolean isCompleted() {
        return completed;
    }

    public void setCompleted(boolean completed) {
        this.completed = completed;
    }
}
