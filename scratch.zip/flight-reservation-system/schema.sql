-- ==============================================================
-- Flight Reservation System Database Schema & Initial Seed Data
-- ==============================================================

CREATE DATABASE IF NOT EXISTS flightdb;
USE flightdb;

-- 1. Users Table
DROP TABLE IF EXISTS ticket;
DROP TABLE IF EXISTS booking;
DROP TABLE IF EXISTS flight;
DROP TABLE IF EXISTS user;

CREATE TABLE user (
    user_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    role VARCHAR(50) NOT NULL
) AUTO_INCREMENT = 101;

-- 2. Flights Table
CREATE TABLE flight (
    flight_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    flight_number VARCHAR(50) UNIQUE NOT NULL,
    source VARCHAR(50) NOT NULL,
    destination VARCHAR(50) NOT NULL,
    departure_time VARCHAR(50) NOT NULL,
    arrival_time VARCHAR(50) NOT NULL,
    capacity INT NOT NULL DEFAULT 20,
    price_per_seat DOUBLE NOT NULL
) AUTO_INCREMENT = 1;

-- 3. Bookings Table
CREATE TABLE booking (
    booking_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    booking_date DATE NOT NULL,
    journey_date DATE NOT NULL,
    seats INT NOT NULL,
    total_price DOUBLE NOT NULL,
    status VARCHAR(50) NOT NULL DEFAULT 'BOOKED',
    flight_id BIGINT NOT NULL,
    user_id BIGINT NOT NULL,
    CONSTRAINT fk_booking_flight FOREIGN KEY (flight_id) REFERENCES flight(flight_id) ON DELETE CASCADE,
    CONSTRAINT fk_booking_user FOREIGN KEY (user_id) REFERENCES user(user_id) ON DELETE CASCADE
) AUTO_INCREMENT = 20001;

-- 4. Tickets Table
CREATE TABLE ticket (
    pnr_no BIGINT PRIMARY KEY AUTO_INCREMENT,
    passenger_name VARCHAR(50) NOT NULL,
    gender VARCHAR(50) NOT NULL,
    age INT NOT NULL,
    journey_date DATE NOT NULL,
    seat_no VARCHAR(20) NOT NULL,
    booking_id BIGINT NOT NULL,
    status VARCHAR(50) NOT NULL DEFAULT 'BOOKED',
    CONSTRAINT fk_ticket_booking FOREIGN KEY (booking_id) REFERENCES booking(booking_id) ON DELETE CASCADE
) AUTO_INCREMENT = 30001;

-- ==============================================================
-- Sample Seed Data (For Testing & Assessment Demo)
-- ==============================================================

-- Seed Users (Admin and standard users)
INSERT INTO user (email, password, role) VALUES 
('admin@email.com', 'admin123', 'Admin'),
('alice@email.com', 'alice123', 'User'),
('john@email.com', 'john123', 'User');

-- Seed Flights (matching wireframes)
INSERT INTO flight (flight_number, source, destination, departure_time, arrival_time, capacity, price_per_seat) VALUES
('AI101', 'Bangalore', 'Hyderabad', '19:49', '20:49', 20, 5000.0),
('AI103', 'Bangalore', 'Hyderabad', '18:41', '20:41', 20, 5000.0),
('AI304', 'Bangalore', 'Hyderabad', '11:25', '11:27', 20, 5600.0),
('IN201', 'Delhi', 'Mumbai', '06:30', '08:45', 20, 6200.0),
('IN302', 'Mumbai', 'Bangalore', '09:15', '11:00', 20, 4800.0),
('AI205', 'Hyderabad', 'Bangalore', '14:00', '15:15', 20, 5200.0);

-- Seed Bookings
-- Upcoming journeys
INSERT INTO booking (booking_id, booking_date, journey_date, seats, total_price, status, flight_id, user_id) VALUES
(20001, CURDATE(), DATE_ADD(CURDATE(), INTERVAL 2 DAY), 2, 10000.0, 'BOOKED', 1, 102),
(20002, CURDATE(), DATE_ADD(CURDATE(), INTERVAL 3 DAY), 1, 5000.0, 'BOOKED', 2, 102),
(20003, CURDATE(), DATE_ADD(CURDATE(), INTERVAL 5 DAY), 3, 18600.0, 'BOOKED', 4, 103),
-- Past completed journeys
(20004, DATE_SUB(CURDATE(), INTERVAL 10 DAY), DATE_SUB(CURDATE(), INTERVAL 5 DAY), 1, 5000.0, 'BOOKED', 1, 102);

-- Seed Tickets for above bookings
INSERT INTO ticket (pnr_no, passenger_name, gender, age, journey_date, seat_no, booking_id, status) VALUES
(30001, 'Alice Smith', 'Female', 28, DATE_ADD(CURDATE(), INTERVAL 2 DAY), 'A1', 20001, 'BOOKED'),
(30002, 'Bob Smith', 'Male', 30, DATE_ADD(CURDATE(), INTERVAL 2 DAY), 'A2', 20001, 'BOOKED'),
(30003, 'Alice Smith', 'Female', 28, DATE_ADD(CURDATE(), INTERVAL 3 DAY), 'A1', 20002, 'BOOKED'),
(30004, 'John Doe', 'Male', 35, DATE_ADD(CURDATE(), INTERVAL 5 DAY), 'B1', 20003, 'BOOKED'),
(30005, 'Jane Doe', 'Female', 32, DATE_ADD(CURDATE(), INTERVAL 5 DAY), 'B2', 20003, 'BOOKED'),
(30006, 'Tommy Doe', 'Male', 8, DATE_ADD(CURDATE(), INTERVAL 5 DAY), 'B3', 20003, 'BOOKED'),
(30007, 'Alice Smith', 'Female', 28, DATE_SUB(CURDATE(), INTERVAL 5 DAY), 'A3', 20004, 'BOOKED');
