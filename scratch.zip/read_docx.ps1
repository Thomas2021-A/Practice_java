Add-Type -AssemblyName System.IO.Compression.FileSystem
$docxPath = 'C:\Users\12a13\.gemini\antigravity\brain\78c0146a-18bf-4eab-976a-affbf8c7337e\.user_uploaded\media_1793295735767_159e2238.docx'
$zip = [System.IO.Compression.ZipFile]::OpenRead($docxPath)
$entry = $zip.GetEntry('word/document.xml')
$stream = $entry.Open()
$reader = New-Object System.IO.StreamReader($stream)
$xmlText = $reader.ReadToEnd()
$reader.Close()
$stream.Close()
$zip.Dispose()

[xml]$xml = $xmlText
$ns = New-Object System.Xml.XmlNamespaceManager($xml.NameTable)
$ns.AddNamespace('w', 'http://schemas.openxmlformats.org/wordprocessingml/2006/main')
$nodes = $xml.SelectNodes('//w:p', $ns)
foreach ($n in $nodes) {
    if (-not [string]::IsNullOrWhiteSpace($n.InnerText)) {
        Write-Output $n.InnerText
    }
}
