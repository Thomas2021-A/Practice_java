package com.deloitte.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import com.deloitte.dao.UserDao;
import com.deloitte.dto.LoginDto;
import com.deloitte.dto.SignUpDto;
import com.deloitte.model.User;
import com.deloitte.service.UserServiceImpl;

@RunWith(MockitoJUnitRunner.class)
public class UserServiceTest {

    @Mock
    private UserDao userDao;

    @InjectMocks
    private UserServiceImpl userService;

    private User sampleUser;
    private SignUpDto validSignUpDto;
    private LoginDto validLoginDto;

    @Before
    public void setUp() {
        sampleUser = new User(1001L, "ravi.kumar@example.com", "Ravi@2026", "user");
        validSignUpDto = new SignUpDto("newuser@example.com", "SecurePass123", "user");
        validLoginDto = new LoginDto("ravi.kumar@example.com", "Ravi@2026");
    }

    // Milestone 7 - Test 1: Successful Sign-Up
    @Test
    public void testSignUpSuccess() {
        when(userDao.findByEmail("newuser@example.com")).thenReturn(null);
        when(userDao.insertUser(any(SignUpDto.class))).thenReturn(1);

        int result = userService.register(validSignUpDto);
        assertEquals(1, result);
        verify(userDao).insertUser(any(SignUpDto.class));
    }

    // Milestone 7 - Test 2: Sign-Up with Duplicate Email
    @Test
    public void testSignUpDuplicateEmail() {
        when(userDao.findByEmail("newuser@example.com")).thenReturn(sampleUser);

        int result = userService.register(validSignUpDto);
        assertEquals(-3, result); // Code -3 indicates duplicate email
        verify(userDao, never()).insertUser(any(SignUpDto.class));
    }

    // Milestone 7 - Test 3: Sign-Up with Short Password (length <= 8)
    @Test
    public void testSignUpShortPassword() {
        SignUpDto shortPassDto = new SignUpDto("test@example.com", "short", "user");

        int result = userService.register(shortPassDto);
        assertEquals(-1, result); // Code -1 indicates password length requirement not met
        verify(userDao, never()).insertUser(any(SignUpDto.class));
    }

    // Milestone 7 - Test 4: Sign-Up with Invalid Role
    @Test
    public void testSignUpInvalidRole() {
        SignUpDto invalidRoleDto = new SignUpDto("test@example.com", "ValidPass2026", "guest");

        int result = userService.register(invalidRoleDto);
        assertEquals(-2, result); // Code -2 indicates invalid role
        verify(userDao, never()).insertUser(any(SignUpDto.class));
    }

    // Milestone 7 - Test 5: Successful Login
    @Test
    public void testLoginSuccess() {
        when(userDao.findByEmailAndPassword("ravi.kumar@example.com", "Ravi@2026")).thenReturn(sampleUser);

        User loggedIn = userService.login(validLoginDto);
        assertNotNull(loggedIn);
        assertEquals("ravi.kumar@example.com", loggedIn.getEmail());
        assertEquals("user", loggedIn.getRole());
    }

    // Milestone 7 - Test 6: Login with Incorrect Password
    @Test
    public void testLoginInvalidCredentials() {
        LoginDto wrongPassDto = new LoginDto("ravi.kumar@example.com", "WrongPassword");
        when(userDao.findByEmailAndPassword("ravi.kumar@example.com", "WrongPassword")).thenReturn(null);

        User loggedIn = userService.login(wrongPassDto);
        assertNull(loggedIn);
    }

    // Milestone 7 - Test 7: Login with Non-Existent User
    @Test
    public void testLoginUserNotFound() {
        LoginDto nonExistentDto = new LoginDto("notfound@example.com", "SomePass123");
        when(userDao.findByEmailAndPassword("notfound@example.com", "SomePass123")).thenReturn(null);

        User loggedIn = userService.login(nonExistentDto);
        assertNull(loggedIn);
    }
}
