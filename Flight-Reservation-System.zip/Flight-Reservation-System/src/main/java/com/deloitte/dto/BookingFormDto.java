package com.deloitte.dto;

public class BookingFormDto {
    private Long flightId;
    private String journeyDate;
    private Integer seats;

    public BookingFormDto() {
    }

    public BookingFormDto(Long flightId, String journeyDate, Integer seats) {
        this.flightId = flightId;
        this.journeyDate = journeyDate;
        this.seats = seats;
    }

    public Long getFlightId() {
        return flightId;
    }

    public void setFlightId(Long flightId) {
        this.flightId = flightId;
    }

    public String getJourneyDate() {
        return journeyDate;
    }

    public void setJourneyDate(String journeyDate) {
        this.journeyDate = journeyDate;
    }

    public Integer getSeats() {
        return seats;
    }

    public void setSeats(Integer seats) {
        this.seats = seats;
    }
}
