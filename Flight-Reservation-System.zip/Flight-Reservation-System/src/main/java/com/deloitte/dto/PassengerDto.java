package com.deloitte.dto;

public class PassengerDto {
    private String passengerName;
    private String gender; // 'male', 'female', 'other'
    private Integer age;
    private String seatNo;

    public PassengerDto() {
    }

    public PassengerDto(String passengerName, String gender, Integer age, String seatNo) {
        this.passengerName = passengerName;
        this.gender = gender;
        this.age = age;
        this.seatNo = seatNo;
    }

    public String getPassengerName() {
        return passengerName;
    }

    public void setPassengerName(String passengerName) {
        this.passengerName = passengerName;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }

    public String getSeatNo() {
        return seatNo;
    }

    public void setSeatNo(String seatNo) {
        this.seatNo = seatNo;
    }
}
