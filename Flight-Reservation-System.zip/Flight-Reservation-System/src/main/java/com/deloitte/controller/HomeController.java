package com.deloitte.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.deloitte.dto.SearchFlightDto;
import com.deloitte.model.Flight;
import com.deloitte.service.FlightService;

@Controller
@RequestMapping("")
public class HomeController {

    private final FlightService flightService;

    @Autowired
    public HomeController(FlightService flightService) {
        this.flightService = flightService;
    }

    @GetMapping({"/", "/home"})
    public String home(@RequestParam(value = "fromDashboard", required = false) String fromDashboard,
                       Model model, HttpSession session) {
        if (!model.containsAttribute("searchFlightDto")) {
            model.addAttribute("searchFlightDto", new SearchFlightDto());
        }
        if ("true".equalsIgnoreCase(fromDashboard)) {
            model.addAttribute("hideUserActions", true);
        }
        return "home";
    }

    @PostMapping("/search")
    public String searchFlights(@ModelAttribute("searchFlightDto") SearchFlightDto searchDto,
                                Model model, HttpSession session) {
        if (searchDto.getSource() == null || searchDto.getSource().trim().isEmpty() ||
            searchDto.getDestination() == null || searchDto.getDestination().trim().isEmpty()) {
            model.addAttribute("searchError", "Please enter both departure (From) and destination (To) cities.");
            return "home";
        }

        List<Flight> flights = flightService.searchFlights(searchDto.getSource(), searchDto.getDestination());
        model.addAttribute("flights", flights);
        model.addAttribute("searched", true);
        model.addAttribute("searchSource", searchDto.getSource());
        model.addAttribute("searchDestination", searchDto.getDestination());

        if (flights.isEmpty()) {
            model.addAttribute("searchInfo", "No direct flights found between " + searchDto.getSource() + " and " + searchDto.getDestination() + ".");
        }

        return "home";
    }
}
