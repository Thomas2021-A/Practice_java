package com.deloitte.exception;

import java.util.logging.Level;
import java.util.logging.Logger;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class GlobalExceptionHandler {

    private static final Logger LOGGER = Logger.getLogger(GlobalExceptionHandler.class.getName());

    @ExceptionHandler(FlightAppException.class)
    public String handleFlightAppException(FlightAppException ex, Model model) {
        LOGGER.log(Level.WARNING, "Handled FlightAppException: " + ex.getMessage(), ex);
        model.addAttribute("errorMessage", ex.getMessage());
        return "error";
    }

    @ExceptionHandler(Exception.class)
    public String handleGeneralException(Exception ex, Model model) {
        LOGGER.log(Level.SEVERE, "Unexpected error occurred: " + ex.getMessage(), ex);
        model.addAttribute("errorMessage", "An unexpected error occurred. Please try again or contact support.");
        model.addAttribute("errorDetails", ex.getMessage());
        return "error";
    }
}
