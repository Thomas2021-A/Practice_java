package com.deloitte.exception;

public class FlightAppException extends RuntimeException {
    private static final long serialVersionUID = 1L;

    public FlightAppException(String message) {
        super(message);
    }

    public FlightAppException(String message, Throwable cause) {
        super(message, cause);
    }
}
