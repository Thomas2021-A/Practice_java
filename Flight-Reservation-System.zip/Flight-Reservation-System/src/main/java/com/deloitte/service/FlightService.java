package com.deloitte.service;

import java.util.List;

import com.deloitte.dto.AddFlightDto;
import com.deloitte.model.Flight;

public interface FlightService {
    int addFlight(AddFlightDto addFlightDto);
    Flight getFlightById(Long flightId);
    Flight getFlightByNumber(String flightNumber);
    List<Flight> searchFlights(String source, String destination);
    List<Flight> getAllFlights();
    int getAvailableSeats(Long flightId, String journeyDate);
}
