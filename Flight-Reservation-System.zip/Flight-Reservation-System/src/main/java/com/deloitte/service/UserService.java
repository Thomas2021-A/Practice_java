package com.deloitte.service;

import com.deloitte.dto.LoginDto;
import com.deloitte.dto.SignUpDto;
import com.deloitte.model.User;

public interface UserService {
    int register(SignUpDto signUpDto);
    User login(LoginDto loginDto);
    User findByEmail(String email);
    User findById(Long userId);
}
