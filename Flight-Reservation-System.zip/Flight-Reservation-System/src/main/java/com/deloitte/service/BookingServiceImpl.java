package com.deloitte.service;

import java.time.LocalDate;
import java.util.List;
import java.util.logging.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.deloitte.dao.BookingDao;
import com.deloitte.dao.FlightDao;
import com.deloitte.dao.TicketDao;
import com.deloitte.dto.PassengerDto;
import com.deloitte.exception.FlightAppException;
import com.deloitte.model.Booking;
import com.deloitte.model.Flight;
import com.deloitte.model.FlightSummary;
import com.deloitte.model.Ticket;

@Service
public class BookingServiceImpl implements BookingService {

    private static final Logger LOGGER = Logger.getLogger(BookingServiceImpl.class.getName());

    private final BookingDao bookingDao;
    private final FlightDao flightDao;
    private final TicketDao ticketDao;

    @Autowired
    public BookingServiceImpl(BookingDao bookingDao, FlightDao flightDao, TicketDao ticketDao) {
        this.bookingDao = bookingDao;
        this.flightDao = flightDao;
        this.ticketDao = ticketDao;
    }

    @Override
    @Transactional
    public Booking createBooking(Long userId, Long flightId, String journeyDate, List<PassengerDto> passengers) {
        if (userId == null || flightId == null || journeyDate == null || passengers == null || passengers.isEmpty()) {
            throw new FlightAppException("Invalid booking parameters provided.");
        }

        Flight flight = flightDao.findById(flightId);
        if (flight == null) {
            throw new FlightAppException("Flight not found with ID: " + flightId);
        }

        int requestedSeats = passengers.size();
        int bookedSeats = bookingDao.getConfirmedSeatsCount(flightId, journeyDate);
        int availableSeats = flight.getCapacity() - bookedSeats;

        if (availableSeats < requestedSeats) {
            throw new FlightAppException("Only " + Math.max(availableSeats, 0) + " seats available. Cannot book " + requestedSeats + " seats.");
        }

        double totalPrice = requestedSeats * flight.getPricePerSeat();

        Booking booking = new Booking();
        booking.setBookingDate(LocalDate.now().toString());
        booking.setJourneyDate(journeyDate);
        booking.setSeats(requestedSeats);
        booking.setTotalPrice(totalPrice);
        booking.setStatus("confirmed");
        booking.setFlightId(flightId);
        booking.setUserId(userId);

        Long bookingId = bookingDao.createBooking(booking);
        if (bookingId == null) {
            throw new FlightAppException("Failed to generate booking transaction.");
        }

        // Generate tickets for each passenger
        int seatCounter = bookedSeats + 1;
        for (PassengerDto p : passengers) {
            String seatLetter = "A";
            int seatRow = (seatCounter % 30) + 1;
            char col = (char) ('A' + ((seatCounter - 1) % 6));
            String generatedSeat = (p.getSeatNo() != null && !p.getSeatNo().trim().isEmpty())
                    ? p.getSeatNo().trim().toUpperCase()
                    : (seatRow + "" + col);

            Ticket ticket = new Ticket();
            ticket.setPassengerName(p.getPassengerName().trim());
            ticket.setGender(p.getGender().trim());
            ticket.setAge(p.getAge());
            ticket.setJourneyDate(journeyDate);
            ticket.setSeatNo(generatedSeat);
            ticket.setBookingId(bookingId);
            ticket.setStatus("confirmed");

            ticketDao.insertTicket(ticket);
            seatCounter++;
        }

        LOGGER.info("Booking #" + bookingId + " created successfully for user #" + userId + " with " + requestedSeats + " passenger(s)");
        return bookingDao.findById(bookingId);
    }

    @Override
    public Booking getBookingById(Long bookingId) {
        if (bookingId == null) {
            return null;
        }
        return bookingDao.findById(bookingId);
    }

    @Override
    public List<Booking> getBookingsByUserId(Long userId) {
        if (userId == null) {
            return List.of();
        }
        return bookingDao.findByUserId(userId);
    }

    @Override
    @Transactional
    public boolean cancelBooking(Long bookingId, Long userId) {
        if (bookingId == null || userId == null) {
            return false;
        }
        int rows = bookingDao.cancelBooking(bookingId, userId);
        if (rows > 0) {
            ticketDao.cancelTicketsByBookingId(bookingId);
            LOGGER.info("Booking #" + bookingId + " cancelled and seats released.");
            return true;
        }
        return false;
    }

    @Override
    public List<Ticket> getTicketsByBookingId(Long bookingId) {
        if (bookingId == null) {
            return List.of();
        }
        return ticketDao.findByBookingId(bookingId);
    }

    @Override
    public List<FlightSummary> getUpcomingFlights() {
        return bookingDao.getFlightSummaries(true);
    }

    @Override
    public List<FlightSummary> getCompletedFlights() {
        return bookingDao.getFlightSummaries(false);
    }
}
