package com.deloitte.dao;

import java.util.List;

import com.deloitte.dto.AddFlightDto;
import com.deloitte.model.Flight;

public interface FlightDao {
    int insertFlight(AddFlightDto addFlightDto);
    Flight findById(Long flightId);
    Flight findByFlightNumber(String flightNumber);
    List<Flight> searchFlights(String source, String destination);
    List<Flight> getAllFlights();
}
