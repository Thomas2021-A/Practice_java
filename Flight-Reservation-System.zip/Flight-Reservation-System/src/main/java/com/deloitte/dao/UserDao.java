package com.deloitte.dao;

import com.deloitte.dto.SignUpDto;
import com.deloitte.model.User;

public interface UserDao {
    int insertUser(SignUpDto signUpDto);
    User findByEmailAndPassword(String email, String password);
    User findByEmail(String email);
    User findById(Long userId);
}
