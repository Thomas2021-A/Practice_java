package com.deloitte.dao;

import java.util.List;

import com.deloitte.model.Ticket;

public interface TicketDao {
    int insertTicket(Ticket ticket);
    List<Ticket> findByBookingId(Long bookingId);
    int cancelTicketsByBookingId(Long bookingId);
}
