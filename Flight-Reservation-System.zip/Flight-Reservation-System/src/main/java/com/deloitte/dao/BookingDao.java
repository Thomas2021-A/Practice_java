package com.deloitte.dao;

import java.util.List;

import com.deloitte.model.Booking;
import com.deloitte.model.FlightSummary;

public interface BookingDao {
    Long createBooking(Booking booking);
    Booking findById(Long bookingId);
    List<Booking> findByUserId(Long userId);
    int cancelBooking(Long bookingId, Long userId);
    int getConfirmedSeatsCount(Long flightId, String journeyDate);
    List<FlightSummary> getFlightSummaries(boolean upcoming);
}
