package com.deloitte.dao;

import java.sql.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.deloitte.model.Ticket;

@Repository
public class TicketDaoImpl implements TicketDao {

    private final JdbcTemplate jdbcTemplate;

    @Autowired
    public TicketDaoImpl(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    private final RowMapper<Ticket> ticketRowMapper = (rs, rowNum) -> {
        Ticket ticket = new Ticket();
        ticket.setPnrNo(rs.getLong("pnr_no"));
        ticket.setPassengerName(rs.getString("passenger_name"));
        ticket.setGender(rs.getString("gender"));
        ticket.setAge(rs.getInt("age"));
        ticket.setJourneyDate(rs.getString("journey_date"));
        ticket.setSeatNo(rs.getString("seat_no"));
        ticket.setBookingId(rs.getLong("booking_id"));
        ticket.setStatus(rs.getString("status"));

        try {
            ticket.setFlightNumber(rs.getString("flight_number"));
            ticket.setSource(rs.getString("source"));
            ticket.setDestination(rs.getString("destination"));
            ticket.setDepartureTime(rs.getString("departure_time"));
            ticket.setArrivalTime(rs.getString("arrival_time"));
        } catch (Exception ignored) {
        }

        return ticket;
    };

    @Override
    public int insertTicket(Ticket ticket) {
        String sql = "INSERT INTO tbl_tickets (passenger_name, gender, age, journey_date, seat_no, booking_id, status) "
                   + "VALUES (?, ?, ?, ?, ?, ?, ?)";
        return jdbcTemplate.update(sql,
                ticket.getPassengerName(),
                ticket.getGender().toLowerCase(),
                ticket.getAge(),
                Date.valueOf(ticket.getJourneyDate()),
                ticket.getSeatNo(),
                ticket.getBookingId(),
                ticket.getStatus());
    }

    @Override
    public List<Ticket> findByBookingId(Long bookingId) {
        String sql = "SELECT t.*, f.flight_number, f.source, f.destination, f.departure_time, f.arrival_time "
                   + "FROM tbl_tickets t "
                   + "JOIN tbl_bookings b ON t.booking_id = b.booking_id "
                   + "JOIN tbl_flights f ON b.flight_id = f.flight_id "
                   + "WHERE t.booking_id = ? "
                   + "ORDER BY t.pnr_no ASC";
        return jdbcTemplate.query(sql, ticketRowMapper, bookingId);
    }

    @Override
    public int cancelTicketsByBookingId(Long bookingId) {
        String sql = "UPDATE tbl_tickets SET status = 'cancelled' WHERE booking_id = ?";
        return jdbcTemplate.update(sql, bookingId);
    }
}
