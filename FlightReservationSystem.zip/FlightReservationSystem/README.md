# ✈ Flight Reservation System (Spring MVC + Spring JDBC + MySQL)

A complete, beginner-friendly Full-Stack Web Application built for company training evaluation. This application enables customers to browse flights, check seat availability in real time, make reservations with multi-step passenger details, view tickets with unique PNRs, and cancel bookings. It also provides an Admin portal to add daily scheduled flights and monitor upcoming and completed flight journeys.

---

## 🛠 Tech Stack & Environment Compatibility

| Component | Technology / Specification |
| :--- | :--- |
| **Backend Framework** | Spring Framework 5.3.39 (Spring MVC, Spring JDBC, Spring Context) |
| **Java Version** | Java 17 / 21 (Compatible with Java SE 17+) |
| **Web Server** | Apache Tomcat 9.0 (Servlet Spec 4.0, `javax.servlet` API) |
| **View Layer** | Spring Forms + JSP + JSTL 1.2 |
| **Database** | MySQL 8.0 (`flightdb`) |
| **Build & Dependency Tool** | Apache Maven |
| **IDE** | Eclipse IDE for Enterprise Java and Web Developers |
| **Testing** | JUnit 4.13.2 & Mockito 4.11.0 |

---

## 📁 Project Directory Structure

```text
FlightReservationSystem/
├── .classpath                                  <-- Eclipse Classpath configuration
├── .gitignore                                  <-- Git Ignore rules
├── .project                                    <-- Eclipse Project metadata
├── .settings/                                  <-- Eclipse WTP, JDT & Facet settings
│   ├── org.eclipse.jdt.core.prefs
│   ├── org.eclipse.m2e.core.prefs
│   ├── org.eclipse.wst.common.component
│   └── org.eclipse.wst.common.project.facet.core.xml
├── flightdb.sql                                <-- Database creation and seed data script
├── pom.xml                                     <-- Maven Dependencies and build plugins
├── README.md                                   <-- Project documentation & Viva prep
├── src/
│   ├── main/
│   │   ├── java/
│   │   │   └── com/deloitte/flight/
│   │   │       ├── config/
│   │   │       │   ├── AppConfig.java          <-- Spring Java Config (DataSource, ViewResolver, Tx)
│   │   │       │   └── WebAppInitializer.java   <-- DispatcherServlet initializer (No web.xml needed)
│   │   │       ├── controller/
│   │   │       │   ├── AdminController.java    <-- Admin Dashboard, Add Flight, View Journeys
│   │   │       │   ├── BookingController.java  <-- Booking Flow, Add Passengers, Cancel, Tickets
│   │   │       │   ├── HomeController.java     <-- Home landing page, Search Flights
│   │   │       │   └── UserController.java     <-- Signup, Login, Logout, User Dashboard
│   │   │       ├── dao/
│   │   │       │   ├── BookingDao.java & BookingDaoImpl.java
│   │   │       │   ├── FlightDao.java & FlightDaoImpl.java
│   │   │       │   ├── TicketDao.java & TicketDaoImpl.java
│   │   │       │   └── UserDao.java & UserDaoImpl.java
│   │   │       ├── dto/
│   │   │       │   ├── AddFlightDto.java
│   │   │       │   ├── BookingFormDto.java
│   │   │       │   ├── FlightSummaryDto.java
│   │   │       │   ├── LoginDto.java
│   │   │       │   ├── PassengerDto.java
│   │   │       │   ├── SearchFlightDto.java
│   │   │       │   └── SignUpDto.java
│   │   │       ├── exception/
│   │   │       │   ├── FlightAppException.java
│   │   │       │   └── GlobalExceptionHandler.java <-- @ControllerAdvice centralized exception handler
│   │   │       ├── model/
│   │   │       │   ├── Booking.java
│   │   │       │   ├── Flight.java
│   │   │       │   ├── FlightSummary.java
│   │   │       │   ├── Ticket.java
│   │   │       │   └── User.java
│   │   │       └── service/
│   │   │           ├── BookingService.java & BookingServiceImpl.java
│   │   │           ├── FlightService.java & FlightServiceImpl.java
│   │   │           └── UserService.java & UserServiceImpl.java
│   │   ├── resources/
│   │   └── webapp/
│   │       └── WEB-INF/
│   │           └── views/
│   │               ├── add-flight.jsp          <-- Admin Add Flight Form
│   │               ├── add-passenger.jsp       <-- Dynamic Multi-step Passenger Entry Screen
│   │               ├── admin-dashboard.jsp     <-- Admin Dashboard
│   │               ├── booking-confirmation.jsp<-- Booking Success & PNR display
│   │               ├── booking-form.jsp        <-- Journey Date & Passenger Count Selection
│   │               ├── error.jsp               <-- Global Exception Error View
│   │               ├── home.jsp                <-- Landing page with Flight Search
│   │               ├── login.jsp               <-- User/Admin Login Form
│   │               ├── my-bookings.jsp         <-- User Bookings list with Cancel action
│   │               ├── signup.jsp              <-- Registration Form with Role Selection
│   │               ├── user-dashboard.jsp      <-- Customer Dashboard
│   │               ├── view-flights.jsp        <-- Admin Upcoming & Completed Journeys Tabs
│   │               └── view-tickets.jsp        <-- Boarding Pass Cards with PNR
│   └── test/
│       └── java/
│           └── com/deloitte/flight/test/
│               └── UserServiceTest.java        <-- JUnit tests for Sign Up & Login
```

---

## 🗄 1. Database Setup (MySQL)

1. Open **MySQL Workbench** or your command-line MySQL client:
   ```bash
   mysql -u root -p
   ```
2. Execute the included `flightdb.sql` script located in the project root:
   ```sql
   SOURCE C:/Users/12a13/.gemini/antigravity/scratch/FlightReservationSystem/flightdb.sql;
   ```
   *Or copy and paste the contents of `flightdb.sql` into MySQL Workbench and run all statements.*
3. Verify the database tables:
   ```sql
   USE flightdb;
   SHOW TABLES;
   SELECT * FROM tbl_users;
   SELECT * FROM tbl_flights;
   ```

> [!NOTE]
> In `AppConfig.java`, the default MySQL credentials are configured as:
> - **URL:** `jdbc:mysql://localhost:3306/flightdb`
> - **Username:** `root`
> - **Password:** `Thomas@sql`
> If your MySQL root password is different, simply update line 31 of `src/main/java/com/deloitte/flight/config/AppConfig.java`.

---

## 💻 2. Importing into Eclipse & Running on Tomcat 9.0

### Step A: Import into Eclipse
1. Launch **Eclipse IDE for Enterprise Java and Web Developers**.
2. Select your workspace directory.
3. Click **File** &rarr; **Import...**
4. Select **Maven** &rarr; **Existing Maven Projects** and click **Next**.
5. Click **Browse...** and select the folder:
   `C:\Users\12a13\.gemini\antigravity\scratch\FlightReservationSystem`
6. Ensure `pom.xml` is checked and click **Finish**.
7. Wait a few moments for Eclipse and Maven to resolve dependencies.

### Step B: Configure Apache Tomcat 9.0 in Eclipse
1. In Eclipse, open the **Servers** tab (at the bottom window).
   *(If not visible, go to **Window** &rarr; **Show View** &rarr; **Servers**).*
2. Right-click in the Servers view &rarr; **New** &rarr; **Server**.
3. Expand **Apache** and select **Tomcat v9.0 Server**. Click **Next**.
4. Browse to your installed Apache Tomcat 9.0 directory if prompted, then click **Next**.
5. Under **Available projects**, select `FlightReservationSystem`, click **Add >** to move it to **Configured**, and click **Finish**.

### Step C: Run the Application
1. Right-click on the `FlightReservationSystem` project in Project Explorer.
2. Select **Run As** &rarr; **Run on Server**.
3. Select **Tomcat v9.0 Server** and click **Finish**.
4. Open your browser and navigate to:
   ```
   http://localhost:8080/FlightReservationSystem/
   ```

---

## 🧪 3. Running Unit Tests

To run the JUnit unit tests in Eclipse:
1. Right-click on `src/test/java/com/deloitte/flight/test/UserServiceTest.java`.
2. Select **Run As** &rarr; **JUnit Test**.
3. All 7 test cases will pass with a green bar:
   - `testSignUpSuccess`
   - `testSignUpDuplicateEmail`
   - `testSignUpShortPassword`
   - `testSignUpInvalidRole`
   - `testLoginSuccess`
   - `testLoginInvalidCredentials`
   - `testLoginUserNotFound`

---

## 🔑 Default Seed Accounts & Credentials

| Role | Email | Password | Allowed Access |
| :--- | :--- | :--- | :--- |
| **Admin** | `admin@flightapp.com` | `Admin@2026` | Admin Dashboard, Add Flight, View Journeys Report |
| **User** | `ravi.kumar@example.com` | `Ravi@2026` | Book Flights, My Bookings, View Tickets, Cancel Booking |
| **User** | `meera.nair@example.com` | `Meera@2026` | Book Flights, My Bookings, View Tickets, Cancel Booking |
| **User** | `arjun.rao@example.com` | `Arjun@2026` | Book Flights, My Bookings, View Tickets, Cancel Booking |

---

## 🎯 Verification Checklist Against Company Requirements

| Milestone | Requirement | Status | Implementation Details |
| :--- | :--- | :---: | :--- |
| **Milestone 1** | Home Page & Flight Search | ✅ Complete | `HomeController.java`, `home.jsp` with Search Flights card and User Actions |
| **Milestone 1** | Available Flights Table | ✅ Complete | Lists flights with Flight #, Route, Schedule, Price, and "Book" button |
| **Milestone 2** | User Sign Up | ✅ Complete | `UserController.java`, `signup.jsp` (Email, Password >8 chars, Role dropdown) |
| **Milestone 2** | User & Admin Login | ✅ Complete | Role-based redirection: Admin &rarr; `/admin/dashboard`, User &rarr; `/user/dashboard` |
| **Milestone 3** | Booking Form | ✅ Complete | `booking-form.jsp`: Journey date, passenger count (max 10), seat check |
| **Milestone 3** | Add Passenger Loop | ✅ Complete | `add-passenger.jsp`: Multi-step sequential entry screen with progress bar |
| **Milestone 3** | Booking Confirmation | ✅ Complete | `booking-confirmation.jsp`: Shows generated Booking ID, badges, and print |
| **Milestone 4** | Admin Dashboard | ✅ Complete | `admin-dashboard.jsp`: "Add New Flight" & "View Flights" cards |
| **Milestone 4** | Admin Add Flight | ✅ Complete | `add-flight.jsp`: Default capacity 20, unique flight number validation |
| **Milestone 4** | Admin View Running Flights | ✅ Complete | `view-flights.jsp`: "Upcoming Journeys" & "Completed Journey" tabs with totals |
| **Milestone 5** | User Dashboard | ✅ Complete | `user-dashboard.jsp`: Links to "My Bookings" and "Search Flights" |
| **Milestone 5** | My Bookings & Cancellation | ✅ Complete | `my-bookings.jsp`: Lists user's bookings; Cancel releases seats in real-time |
| **Milestone 5** | View Tickets & Boarding Passes | ✅ Complete | `view-tickets.jsp`: Ticket cards for each passenger with unique PNR & seat # |
| **Milestone 6** | Global Exception Handling | ✅ Complete | `GlobalExceptionHandler.java` using `@ControllerAdvice` and `error.jsp` |
| **Milestone 7** | Unit Testing | ✅ Complete | `UserServiceTest.java` covering Sign-Up & Login validation with Mockito & JUnit |
| **Milestone 8** | Git Repository Ready | ✅ Complete | `.gitignore`, clean Maven structure, documented source code |

---

## 🎤 Technical Interview / Viva Q&A Guide

### Q1: What architecture pattern does this application follow?
**Answer:** It follows the **Model-View-Controller (MVC)** architectural design with a 3-tier layered structure:
1. **Presentation Layer:** JSP pages rendered via Spring MVC `InternalResourceViewResolver`.
2. **Business Service Layer:** Service classes (`UserServiceImpl`, `FlightServiceImpl`, `BookingServiceImpl`) containing business logic, validations, and transactional boundaries.
3. **Data Access Layer:** DAO classes (`UserDaoImpl`, `FlightDaoImpl`, `BookingDaoImpl`, `TicketDaoImpl`) using Spring's `JdbcTemplate` to execute prepared SQL queries on MySQL.

### Q2: How does the seat availability check work during flight booking?
**Answer:**
1. Each flight has a maximum seat capacity stored in `tbl_flights.capacity`.
2. When a user requests $N$ seats on a specific `journey_date`, the system queries `tbl_bookings`:
   ```sql
   SELECT COALESCE(SUM(seats), 0) FROM tbl_bookings 
   WHERE flight_id = ? AND journey_date = ? AND status = 'confirmed';
   ```
3. The available seats count is computed as `capacity - bookedSeats`.
4. If $N > \text{availableSeats}$, the booking is denied with a user-friendly error message. When a booking is cancelled, its status changes to `'cancelled'`, which automatically excludes those seats from the query and releases them for other passengers.

### Q3: Why is `AbstractAnnotationConfigDispatcherServletInitializer` used instead of `web.xml`?
**Answer:** In modern Spring MVC (Servlet 3.0+ specification), `WebApplicationInitializer` provides a clean, pure-Java way to configure the `DispatcherServlet` and root Application Context without maintaining an XML configuration file. Tomcat 9.0 automatically detects this class at server startup.

### Q4: How is Global Exception Handling implemented?
**Answer:** Using Spring's `@ControllerAdvice` annotation on `GlobalExceptionHandler.java`. Any uncaught exception thrown from controllers or services (e.g. `FlightAppException` or database failures) is intercepted by methods annotated with `@ExceptionHandler` and routed to `error.jsp`, preventing raw server stack traces from being exposed to the end user.
