<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Flight Reservation - My Bookings</title>
    <style>
        :root {
            --primary: #4f46e5;
            --primary-hover: #4338ca;
            --bg: #f8fafc;
            --card-bg: #ffffff;
            --text-dark: #1e293b;
            --text-muted: #64748b;
            --border: #e2e8f0;
            --success: #10b981;
            --danger: #ef4444;
        }
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; }
        body { background: var(--bg); color: var(--text-dark); min-height: 100vh; display: flex; flex-direction: column; }
        
        .navbar { background: #111827; color: white; padding: 0.9rem 2rem; display: flex; justify-content: space-between; align-items: center; }
        .navbar-brand { font-size: 1.25rem; font-weight: 700; color: #ffffff; text-decoration: none; }
        .navbar-links { display: flex; align-items: center; gap: 1.25rem; }
        .navbar-links a { color: #d1d5db; text-decoration: none; font-size: 0.95rem; font-weight: 500; }
        .navbar-links a:hover, .navbar-links a.active { color: #ffffff; }
        .user-badge { background: #374151; padding: 0.25rem 0.75rem; border-radius: 9999px; font-size: 0.85rem; color: #60a5fa; }
        
        .container { max-width: 1050px; margin: 2.5rem auto; padding: 0 1rem; flex: 1; width: 100%; }
        
        .header-section { margin-bottom: 1.5rem; display: flex; justify-content: space-between; align-items: center; }
        .header-section h1 { font-size: 1.6rem; color: #0f172a; display: flex; align-items: center; gap: 0.5rem; }
        
        .alert { padding: 0.75rem 1rem; border-radius: 0.5rem; margin-bottom: 1.5rem; font-size: 0.9rem; }
        .alert-success { background: #f0fdf4; border: 1px solid #bbf7d0; color: #15803d; }
        
        .card { background: var(--card-bg); border: 1px solid var(--border); border-radius: 0.75rem; overflow: hidden; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05); }
        table { width: 100%; border-collapse: collapse; text-align: left; }
        th { background: #f8fafc; padding: 0.85rem 1rem; font-size: 0.85rem; font-weight: 600; color: #475569; border-bottom: 1px solid var(--border); }
        td { padding: 1rem; border-bottom: 1px solid #f1f5f9; font-size: 0.95rem; vertical-align: middle; }
        tr:hover { background: #f8fafc; }
        
        .status-badge { display: inline-block; padding: 0.25rem 0.6rem; border-radius: 9999px; font-size: 0.8rem; font-weight: 700; text-transform: uppercase; }
        .status-confirmed { background: #dcfce7; color: #166534; }
        .status-cancelled { background: #fee2e2; color: #991b1b; }
        
        .btn-action { display: inline-flex; align-items: center; justify-content: center; padding: 0.45rem 0.85rem; font-size: 0.85rem; font-weight: 600; border-radius: 0.375rem; text-decoration: none; border: none; cursor: pointer; transition: all 0.2s; }
        .btn-view { background: #0284c7; color: white; }
        .btn-view:hover { background: #0369a1; }
        .btn-cancel { background: #ef4444; color: white; }
        .btn-cancel:hover { background: #dc2626; }
        .btn-disabled { background: #e2e8f0; color: #94a3b8; cursor: not-allowed; }
        
        .empty-state { padding: 3rem; text-align: center; color: var(--text-muted); font-size: 1rem; }
        .empty-state a { color: var(--primary); text-decoration: none; font-weight: 600; }
        
        footer { background: #111827; color: #9ca3af; text-align: center; padding: 1.25rem; font-size: 0.875rem; margin-top: auto; }
    </style>
</head>
<body>
    <header class="navbar">
        <a href="${pageContext.request.contextPath}/" class="navbar-brand">✈ Flight Reservation</a>
        <nav class="navbar-links">
            <a href="${pageContext.request.contextPath}/">Home</a>
            <a href="${pageContext.request.contextPath}/user/dashboard">Dashboard</a>
            <a href="${pageContext.request.contextPath}/booking/my-bookings" class="active">My Bookings</a>
            <span class="user-badge">${sessionScope.user.email}</span>
            <a href="${pageContext.request.contextPath}/logout">Logout</a>
        </nav>
    </header>

    <main class="container">
        <div class="header-section">
            <h1>📋 My Bookings</h1>
            <a href="${pageContext.request.contextPath}/" class="btn-action" style="background:#4f46e5; color:white;">🔍 Book More Flights</a>
        </div>

        <c:if test="${not empty infoMsg}">
            <div class="alert alert-success">${infoMsg}</div>
        </c:if>

        <div class="card">
            <c:choose>
                <c:when test="${not empty bookings}">
                    <table>
                        <thead>
                            <tr>
                                <th>Booking ID</th>
                                <th>Flight Number</th>
                                <th>Journey Date</th>
                                <th>Status</th>
                                <th>Action</th>
                                <th>Cancel</th>
                            </tr>
                        </thead>
                        <tbody>
                            <c:forEach var="b" items="${bookings}">
                                <tr>
                                    <td><strong>#${b.bookingId}</strong></td>
                                    <td>${b.flightNumber}</td>
                                    <td>${b.journeyDate}</td>
                                    <td>
                                        <c:choose>
                                            <c:when test="${b.status eq 'confirmed'}">
                                                <span class="status-badge status-confirmed">BOOKED</span>
                                            </c:when>
                                            <c:otherwise>
                                                <span class="status-badge status-cancelled">CANCELLED</span>
                                            </c:otherwise>
                                        </c:choose>
                                    </td>
                                    <td>
                                        <a href="${pageContext.request.contextPath}/booking/tickets?bookingId=${b.bookingId}" class="btn-action btn-view">👁 View Tickets</a>
                                    </td>
                                    <td>
                                        <c:choose>
                                            <c:when test="${b.status eq 'confirmed'}">
                                                <form action="${pageContext.request.contextPath}/booking/cancel" method="post" style="display:inline;" onsubmit="return confirm('Are you sure you want to cancel booking #${b.bookingId}? This will release your seats.');">
                                                    <input type="hidden" name="bookingId" value="${b.bookingId}" />
                                                    <button type="submit" class="btn-action btn-cancel">Cancel</button>
                                                </form>
                                            </c:when>
                                            <c:otherwise>
                                                <button class="btn-action btn-disabled" disabled="disabled">Cancelled</button>
                                            </c:otherwise>
                                        </c:choose>
                                    </td>
                                </tr>
                            </c:forEach>
                        </tbody>
                    </table>
                </c:when>
                <c:otherwise>
                    <div class="empty-state">
                        You have no flight bookings yet. <a href="${pageContext.request.contextPath}/">Search flights</a> to make your first reservation!
                    </div>
                </c:otherwise>
            </c:choose>
        </div>
    </main>

    <footer>
        &copy; 2026 Flight Reservation System. All rights reserved.
    </footer>
</body>
</html>
