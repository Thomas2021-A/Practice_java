<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Flight Reservation - Add Flight</title>
    <style>
        :root {
            --primary: #10b981;
            --primary-hover: #059669;
            --bg: #f8fafc;
            --card-bg: #ffffff;
            --text-dark: #1e293b;
            --text-muted: #64748b;
            --border: #e2e8f0;
            --danger: #ef4444;
        }
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; }
        body { background: var(--bg); color: var(--text-dark); min-height: 100vh; display: flex; flex-direction: column; }
        
        .navbar { background: #111827; color: white; padding: 0.9rem 2rem; display: flex; justify-content: space-between; align-items: center; }
        .navbar-brand { font-size: 1.25rem; font-weight: 700; color: #ffffff; text-decoration: none; }
        .navbar-links { display: flex; align-items: center; gap: 1.25rem; }
        .navbar-links a { color: #d1d5db; text-decoration: none; font-size: 0.95rem; font-weight: 500; }
        .navbar-links a:hover, .navbar-links a.active { color: #ffffff; }
        .admin-badge { background: #374151; padding: 0.25rem 0.75rem; border-radius: 9999px; font-size: 0.85rem; color: #fbbf24; }
        
        .container { max-width: 650px; margin: 2rem auto; padding: 0 1rem; flex: 1; width: 100%; }
        .card { background: var(--card-bg); border: 1px solid var(--border); border-radius: 0.75rem; padding: 2rem; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05); }
        .card h2 { font-size: 1.4rem; color: #0f172a; margin-bottom: 1.5rem; display: flex; align-items: center; gap: 0.5rem; }
        
        .form-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; }
        @media (max-width: 600px) { .form-grid { grid-template-columns: 1fr; } }
        
        .form-group { margin-bottom: 1.25rem; }
        label { display: block; font-size: 0.875rem; font-weight: 600; margin-bottom: 0.4rem; color: #334155; }
        input[type="text"], input[type="number"], input[type="time"] { width: 100%; padding: 0.7rem 0.85rem; border: 1px solid #cbd5e1; border-radius: 0.5rem; font-size: 0.95rem; outline: none; }
        input:focus { border-color: var(--primary); box-shadow: 0 0 0 3px rgba(16, 185, 129, 0.15); }
        
        .btn { display: inline-flex; align-items: center; justify-content: center; padding: 0.75rem 1.25rem; font-size: 1rem; font-weight: 600; border-radius: 0.5rem; border: none; cursor: pointer; text-decoration: none; width: 100%; transition: background 0.2s; }
        .btn-green { background: var(--primary); color: white; margin-top: 0.5rem; }
        .btn-green:hover { background: var(--primary-hover); }
        .btn-back { background: #f1f5f9; color: #475569; margin-top: 0.75rem; }
        .btn-back:hover { background: #e2e8f0; }
        
        .alert { padding: 0.75rem 1rem; border-radius: 0.5rem; margin-bottom: 1.25rem; font-size: 0.9rem; }
        .alert-danger { background: #fef2f2; border: 1px solid #fecaca; color: #b91c1c; }
        .alert-success { background: #f0fdf4; border: 1px solid #bbf7d0; color: #15803d; }
        
        footer { background: #111827; color: #9ca3af; text-align: center; padding: 1.25rem; font-size: 0.875rem; margin-top: auto; }
    </style>
</head>
<body>
    <header class="navbar">
        <a href="${pageContext.request.contextPath}/" class="navbar-brand">✈ Flight Reservation</a>
        <nav class="navbar-links">
            <a href="${pageContext.request.contextPath}/">Home</a>
            <a href="${pageContext.request.contextPath}/admin/dashboard">Dashboard</a>
            <a href="${pageContext.request.contextPath}/admin/flight/add" class="active">Add Flight</a>
            <span class="admin-badge">@ admin (Admin)</span>
            <a href="${pageContext.request.contextPath}/logout">Logout</a>
        </nav>
    </header>

    <main class="container">
        <div class="card">
            <h2>➕ Add Flight</h2>

            <c:if test="${not empty error}">
                <div class="alert alert-danger">${error}</div>
            </c:if>
            <c:if test="${not empty successMsg}">
                <div class="alert alert-success">${successMsg}</div>
            </c:if>

            <form:form action="${pageContext.request.contextPath}/admin/flight/add" method="post" modelAttribute="addFlightDto">
                <div class="form-grid">
                    <div class="form-group">
                        <label for="flightNumber">Flight Number</label>
                        <form:input path="flightNumber" id="flightNumber" placeholder="Enter flight number (e.g. AI202)" required="required" />
                    </div>
                    <div class="form-group">
                        <label for="capacity">Capacity</label>
                        <form:input path="capacity" id="capacity" type="number" min="1" required="required" />
                    </div>
                </div>

                <div class="form-grid">
                    <div class="form-group">
                        <label for="source">Source</label>
                        <form:input path="source" id="source" placeholder="Enter source city" required="required" />
                    </div>
                    <div class="form-group">
                        <label for="destination">Destination</label>
                        <form:input path="destination" id="destination" placeholder="Enter destination city" required="required" />
                    </div>
                </div>

                <div class="form-grid">
                    <div class="form-group">
                        <label for="departureTime">Departure Time</label>
                        <form:input path="departureTime" id="departureTime" placeholder="e.g. 09:30 or 09:30 AM" required="required" />
                    </div>
                    <div class="form-group">
                        <label for="arrivalTime">Arrival Time</label>
                        <form:input path="arrivalTime" id="arrivalTime" placeholder="e.g. 11:15 or 11:15 AM" required="required" />
                    </div>
                </div>

                <div class="form-group">
                    <label for="pricePerSeat">Price per Seat (&#8377;)</label>
                    <form:input path="pricePerSeat" id="pricePerSeat" type="number" step="0.5" min="1" placeholder="e.g. 4500.0" required="required" />
                </div>

                <button type="submit" class="btn btn-green">➕ Add Flight</button>
                <a href="${pageContext.request.contextPath}/admin/dashboard" class="btn btn-back">&larr; Back to Dashboard</a>
            </form:form>
        </div>
    </main>

    <footer>
        &copy; 2026 Flight Reservation System. All rights reserved.
    </footer>
</body>
</html>
