<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Flight Reservation - User Dashboard</title>
    <style>
        :root {
            --primary: #4f46e5;
            --primary-hover: #4338ca;
            --bg: #f8fafc;
            --card-bg: #ffffff;
            --text-dark: #1e293b;
            --text-muted: #64748b;
            --border: #e2e8f0;
        }
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; }
        body { background: var(--bg); color: var(--text-dark); min-height: 100vh; display: flex; flex-direction: column; }
        
        .navbar { background: #111827; color: white; padding: 0.9rem 2rem; display: flex; justify-content: space-between; align-items: center; }
        .navbar-brand { font-size: 1.25rem; font-weight: 700; color: #ffffff; text-decoration: none; }
        .navbar-links { display: flex; align-items: center; gap: 1.25rem; }
        .navbar-links a { color: #d1d5db; text-decoration: none; font-size: 0.95rem; font-weight: 500; }
        .navbar-links a:hover, .navbar-links a.active { color: #ffffff; }
        .user-badge { background: #374151; padding: 0.25rem 0.75rem; border-radius: 9999px; font-size: 0.85rem; color: #60a5fa; }
        
        .container { max-width: 900px; margin: 3rem auto; padding: 0 1rem; flex: 1; width: 100%; }
        .header-section { margin-bottom: 2rem; }
        .header-section h1 { font-size: 1.75rem; color: #0f172a; margin-bottom: 0.25rem; display: flex; align-items: center; gap: 0.5rem; }
        .header-section p { color: var(--text-muted); font-size: 1rem; }
        
        .dashboard-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 1.5rem; }
        .dash-card { background: var(--card-bg); border: 1px solid var(--border); border-radius: 0.75rem; padding: 2rem; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05); display: flex; flex-direction: column; justify-content: space-between; }
        .dash-card h3 { font-size: 1.25rem; color: #0f172a; margin-bottom: 0.5rem; display: flex; align-items: center; gap: 0.5rem; }
        .dash-card p { color: var(--text-muted); font-size: 0.95rem; margin-bottom: 1.5rem; }
        
        .btn { display: inline-flex; align-items: center; justify-content: center; padding: 0.75rem 1.25rem; font-size: 0.95rem; font-weight: 600; border-radius: 0.5rem; border: none; cursor: pointer; text-decoration: none; transition: all 0.2s; width: fit-content; }
        .btn-purple { background: #6366f1; color: white; }
        .btn-purple:hover { background: #4f46e5; }
        .btn-green { background: #10b981; color: white; }
        .btn-green:hover { background: #059669; }
        
        footer { background: #111827; color: #9ca3af; text-align: center; padding: 1.25rem; font-size: 0.875rem; margin-top: auto; }
    </style>
</head>
<body>
    <header class="navbar">
        <a href="${pageContext.request.contextPath}/" class="navbar-brand">✈ Flight Reservation</a>
        <nav class="navbar-links">
            <a href="${pageContext.request.contextPath}/">Home</a>
            <a href="${pageContext.request.contextPath}/user/dashboard" class="active">Dashboard</a>
            <a href="${pageContext.request.contextPath}/booking/my-bookings">My Bookings</a>
            <span class="user-badge">👤 ${user.email}</span>
            <a href="${pageContext.request.contextPath}/logout">Logout</a>
        </nav>
    </header>

    <main class="container">
        <div class="header-section">
            <h1>👤 My Dashboard</h1>
            <p>Welcome, <strong>${user.email}</strong>!</p>
        </div>

        <div class="dashboard-grid">
            <!-- Card 1: My Bookings -->
            <div class="dash-card">
                <div>
                    <h3>📋 My Bookings</h3>
                    <p>View your booked flights, ticket details, and manage cancellations.</p>
                </div>
                <a href="${pageContext.request.contextPath}/booking/my-bookings" class="btn btn-purple">View My Bookings</a>
            </div>

            <!-- Card 2: Search Flights -->
            <div class="dash-card">
                <div>
                    <h3>🔍 Search Flights</h3>
                    <p>Find available flights across cities, check schedules and book tickets.</p>
                </div>
                <a href="${pageContext.request.contextPath}/?fromDashboard=true" class="btn btn-green">Find Flights</a>
            </div>
        </div>
    </main>

    <footer>
        &copy; 2026 Flight Reservation System. All rights reserved.
    </footer>
</body>
</html>
