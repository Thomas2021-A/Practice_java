<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Flight Reservation - Home</title>
    <style>
        :root {
            --primary: #4f46e5;
            --primary-hover: #4338ca;
            --bg: #f8fafc;
            --card-bg: #ffffff;
            --text-dark: #1e293b;
            --text-muted: #64748b;
            --border: #e2e8f0;
            --success: #10b981;
            --danger: #ef4444;
        }
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; }
        body { background: var(--bg); color: var(--text-dark); min-height: 100vh; display: flex; flex-direction: column; }
        
        /* Navbar */
        .navbar { background: #111827; color: white; padding: 0.9rem 2rem; display: flex; justify-content: space-between; align-items: center; }
        .navbar-brand { font-size: 1.25rem; font-weight: 700; color: #ffffff; text-decoration: none; display: flex; align-items: center; gap: 0.5rem; }
        .navbar-links { display: flex; align-items: center; gap: 1.25rem; }
        .navbar-links a { color: #d1d5db; text-decoration: none; font-size: 0.95rem; font-weight: 500; transition: color 0.2s; }
        .navbar-links a:hover, .navbar-links a.active { color: #ffffff; }
        .user-badge { background: #374151; padding: 0.25rem 0.75rem; border-radius: 9999px; font-size: 0.85rem; color: #fbbf24; }
        
        /* Main Container */
        .container { max-width: 1100px; margin: 2rem auto; padding: 0 1rem; flex: 1; width: 100%; }
        
        /* Two Column Layout */
        .grid-cards { display: grid; grid-template-columns: 1.2fr 0.8fr; gap: 1.5rem; margin-bottom: 2rem; }
        @media (max-width: 768px) { .grid-cards { grid-template-columns: 1fr; } }
        
        .card { background: var(--card-bg); border: 1px solid var(--border); border-radius: 0.75rem; padding: 1.75rem; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05); }
        .card h2 { font-size: 1.25rem; margin-bottom: 1rem; display: flex; align-items: center; gap: 0.5rem; color: #0f172a; }
        .card p.desc { color: var(--text-muted); font-size: 0.95rem; margin-bottom: 1.5rem; }
        
        /* Forms */
        .form-group { margin-bottom: 1.25rem; }
        label { display: block; font-size: 0.875rem; font-weight: 600; margin-bottom: 0.4rem; color: #334155; }
        input[type="text"], input[type="password"], select { width: 100%; padding: 0.75rem 0.9rem; border: 1px solid #cbd5e1; border-radius: 0.5rem; font-size: 0.95rem; outline: none; transition: border-color 0.2s; }
        input:focus, select:focus { border-color: var(--primary); box-shadow: 0 0 0 3px rgba(79, 70, 229, 0.15); }
        
        /* Buttons */
        .btn { display: inline-flex; align-items: center; justify-content: center; gap: 0.5rem; padding: 0.75rem 1.25rem; font-size: 0.95rem; font-weight: 600; border-radius: 0.5rem; border: none; cursor: pointer; text-decoration: none; transition: all 0.2s; width: 100%; }
        .btn-primary { background: var(--primary); color: white; }
        .btn-primary:hover { background: var(--primary-hover); }
        .btn-secondary { background: #f1f5f9; color: #334155; border: 1px solid var(--border); margin-top: 0.75rem; }
        .btn-secondary:hover { background: #e2e8f0; }
        .btn-book { background: #4f46e5; color: white; padding: 0.5rem 1rem; border-radius: 0.375rem; font-size: 0.875rem; text-decoration: none; font-weight: 600; width: auto; }
        .btn-book:hover { background: #4338ca; }
        
        /* Alerts */
        .alert { padding: 0.75rem 1rem; border-radius: 0.5rem; margin-bottom: 1.25rem; font-size: 0.9rem; }
        .alert-danger { background: #fef2f2; border: 1px solid #fecaca; color: #b91c1c; }
        .alert-info { background: #eff6ff; border: 1px solid #bfdbfe; color: #1d4ed8; }
        
        /* Flights Table */
        .flights-section { background: white; border: 1px solid var(--border); border-radius: 0.75rem; padding: 1.5rem; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05); }
        .flights-section h3 { font-size: 1.2rem; margin-bottom: 1rem; display: flex; align-items: center; gap: 0.5rem; color: #0f172a; }
        table { width: 100%; border-collapse: collapse; text-align: left; }
        th { background: #f8fafc; padding: 0.75rem 1rem; font-size: 0.85rem; font-weight: 600; color: #475569; border-bottom: 1px solid var(--border); }
        td { padding: 1rem; border-bottom: 1px solid #f1f5f9; font-size: 0.95rem; vertical-align: middle; }
        tr:hover { background: #f8fafc; }
        .flight-badge { background: #e0e7ff; color: #3730a3; padding: 0.25rem 0.6rem; border-radius: 0.375rem; font-weight: 700; font-size: 0.85rem; }
        .price-text { font-weight: 700; color: #0f172a; }
        
        /* Footer */
        footer { background: #111827; color: #9ca3af; text-align: center; padding: 1.25rem; font-size: 0.875rem; margin-top: auto; }
    </style>
</head>
<body>

    <!-- Navigation Bar -->
    <header class="navbar">
        <a href="${pageContext.request.contextPath}/" class="navbar-brand">✈ Flight Reservation</a>
        <nav class="navbar-links">
            <a href="${pageContext.request.contextPath}/" class="active">Home</a>
            <c:choose>
                <c:when test="${not empty sessionScope.user}">
                    <c:choose>
                        <c:when test="${sessionScope.user.role eq 'admin'}">
                            <a href="${pageContext.request.contextPath}/admin/dashboard">Dashboard</a>
                            <a href="${pageContext.request.contextPath}/admin/flight/add">Add Flight</a>
                            <span class="user-badge">@ admin (Admin)</span>
                        </c:when>
                        <c:otherwise>
                            <a href="${pageContext.request.contextPath}/user/dashboard">Dashboard</a>
                            <a href="${pageContext.request.contextPath}/booking/my-bookings">My Bookings</a>
                            <span class="user-badge">${sessionScope.user.email}</span>
                        </c:otherwise>
                    </c:choose>
                    <a href="${pageContext.request.contextPath}/logout">Logout</a>
                </c:when>
                <c:otherwise>
                    <a href="${pageContext.request.contextPath}/login">Login</a>
                    <a href="${pageContext.request.contextPath}/signup">Sign Up</a>
                </c:otherwise>
            </c:choose>
        </nav>
    </header>

    <!-- Main Content -->
    <main class="container">
        <c:if test="${not empty searchError}">
            <div class="alert alert-danger">${searchError}</div>
        </c:if>

        <div class="grid-cards">
            <!-- Search Flights Card -->
            <div class="card">
                <h2>🔍 Search Flights</h2>
                <form:form action="${pageContext.request.contextPath}/search" method="post" modelAttribute="searchFlightDto">
                    <div class="form-group">
                        <label for="source">From</label>
                        <form:input path="source" id="source" placeholder="Enter departure city (e.g. Delhi)" required="required" />
                    </div>
                    <div class="form-group">
                        <label for="destination">To</label>
                        <form:input path="destination" id="destination" placeholder="Enter destination city (e.g. Mumbai)" required="required" />
                    </div>
                    <button type="submit" class="btn btn-primary">🔍 Search Flights</button>
                </form:form>
            </div>

            <!-- User Actions Card (shown if not logged in and not hidden) -->
            <c:if test="${empty sessionScope.user and not hideUserActions}">
                <div class="card" style="display: flex; flex-direction: column; justify-content: center;">
                    <h2>👤 User Actions</h2>
                    <p class="desc">Please login to book flights and access your account.</p>
                    <a href="${pageContext.request.contextPath}/login" class="btn btn-primary">🔑 Login</a>
                    <a href="${pageContext.request.contextPath}/signup" class="btn btn-secondary">📝 Sign Up</a>
                </div>
            </c:if>
            <c:if test="${not empty sessionScope.user and not hideUserActions}">
                <div class="card" style="display: flex; flex-direction: column; justify-content: center;">
                    <h2>👋 Welcome Back</h2>
                    <p class="desc">Logged in as <strong>${sessionScope.user.email}</strong></p>
                    <c:choose>
                        <c:when test="${sessionScope.user.role eq 'admin'}">
                            <a href="${pageContext.request.contextPath}/admin/dashboard" class="btn btn-primary">Go to Admin Dashboard</a>
                        </c:when>
                        <c:otherwise>
                            <a href="${pageContext.request.contextPath}/booking/my-bookings" class="btn btn-primary">View My Bookings</a>
                        </c:otherwise>
                    </c:choose>
                </div>
            </c:if>
        </div>

        <!-- Available Flights Result Table -->
        <c:if test="${searched}">
            <div class="flights-section">
                <h3>✈ Available Flights (${searchSource} &rarr; ${searchDestination})</h3>
                <c:choose>
                    <c:when test="${not empty flights}">
                        <table>
                            <thead>
                                <tr>
                                    <th>Flight</th>
                                    <th>Route</th>
                                    <th>Schedule</th>
                                    <th>Price</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <c:forEach var="f" items="${flights}">
                                    <tr>
                                        <td><span class="flight-badge">${f.flightNumber}</span></td>
                                        <td><strong>${f.source}</strong> &rarr; <strong>${f.destination}</strong></td>
                                        <td>
                                            <div>Dep: ${f.departureTime}</div>
                                            <div style="color: var(--text-muted); font-size: 0.85rem;">Arr: ${f.arrivalTime}</div>
                                        </td>
                                        <td class="price-text">&#8377; ${f.pricePerSeat}</td>
                                        <td>
                                            <a href="${pageContext.request.contextPath}/booking/form?flightId=${f.flightId}" class="btn-book">Book</a>
                                        </td>
                                    </tr>
                                </c:forEach>
                            </tbody>
                        </table>
                    </c:when>
                    <c:otherwise>
                        <div class="alert alert-info">
                            ${searchInfo != null ? searchInfo : 'No flights available for this route.'}
                        </div>
                    </c:otherwise>
                </c:choose>
            </div>
        </c:if>
    </main>

    <!-- Footer -->
    <footer>
        &copy; 2026 Flight Reservation System. All rights reserved.
    </footer>
</body>
</html>
