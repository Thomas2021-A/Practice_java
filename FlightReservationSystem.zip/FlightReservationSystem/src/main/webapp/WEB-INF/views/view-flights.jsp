<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Flight Reservation - View Flights</title>
    <style>
        :root {
            --primary: #4f46e5;
            --primary-hover: #4338ca;
            --bg: #f8fafc;
            --card-bg: #ffffff;
            --text-dark: #1e293b;
            --text-muted: #64748b;
            --border: #e2e8f0;
            --info: #0284c7;
        }
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; }
        body { background: var(--bg); color: var(--text-dark); min-height: 100vh; display: flex; flex-direction: column; }
        
        .navbar { background: #111827; color: white; padding: 0.9rem 2rem; display: flex; justify-content: space-between; align-items: center; }
        .navbar-brand { font-size: 1.25rem; font-weight: 700; color: #ffffff; text-decoration: none; }
        .navbar-links { display: flex; align-items: center; gap: 1.25rem; }
        .navbar-links a { color: #d1d5db; text-decoration: none; font-size: 0.95rem; font-weight: 500; }
        .navbar-links a:hover { color: #ffffff; }
        .admin-badge { background: #374151; padding: 0.25rem 0.75rem; border-radius: 9999px; font-size: 0.85rem; color: #fbbf24; }
        
        .container { max-width: 1050px; margin: 2rem auto; padding: 0 1rem; flex: 1; width: 100%; }
        
        .header-bar { display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem; }
        .header-bar h1 { font-size: 1.5rem; color: #0f172a; display: flex; align-items: center; gap: 0.5rem; }
        .btn-dash { background: #f1f5f9; color: #334155; padding: 0.5rem 1rem; border-radius: 0.375rem; text-decoration: none; font-size: 0.9rem; font-weight: 600; border: 1px solid var(--border); }
        .btn-dash:hover { background: #e2e8f0; }
        
        .date-banner { background: #e0f2fe; border: 1px solid #bae6fd; color: #0369a1; padding: 0.75rem 1.25rem; border-radius: 0.5rem; font-weight: 600; font-size: 0.95rem; margin-bottom: 1.5rem; display: flex; align-items: center; gap: 0.5rem; }
        
        /* Tabs */
        .tabs { display: flex; gap: 0.5rem; margin-bottom: 1.25rem; border-bottom: 2px solid var(--border); }
        .tab-btn { background: none; border: none; padding: 0.75rem 1.25rem; font-size: 0.95rem; font-weight: 600; color: var(--text-muted); cursor: pointer; border-bottom: 2px solid transparent; margin-bottom: -2px; }
        .tab-btn.active { color: var(--primary); border-bottom-color: var(--primary); }
        
        .card { background: var(--card-bg); border: 1px solid var(--border); border-radius: 0.75rem; overflow: hidden; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05); }
        table { width: 100%; border-collapse: collapse; text-align: left; }
        th { background: #f8fafc; padding: 0.85rem 1rem; font-size: 0.85rem; font-weight: 600; color: #475569; border-bottom: 1px solid var(--border); }
        td { padding: 1rem; border-bottom: 1px solid #f1f5f9; font-size: 0.95rem; vertical-align: middle; }
        tr:hover { background: #f8fafc; }
        
        .badge-flight { background: #38bdf8; color: #0369a1; padding: 0.25rem 0.6rem; border-radius: 0.375rem; font-weight: 700; font-size: 0.85rem; }
        .badge-passengers { background: #dbeafe; color: #1e40af; padding: 0.2rem 0.5rem; border-radius: 9999px; font-weight: 600; font-size: 0.85rem; }
        .badge-bookings { background: #f3f4f6; color: #374151; padding: 0.2rem 0.5rem; border-radius: 9999px; font-weight: 600; font-size: 0.85rem; }
        .days-badge { background: #fef3c7; color: #92400e; padding: 0.25rem 0.6rem; border-radius: 0.375rem; font-weight: 600; font-size: 0.85rem; }
        
        .empty-state { padding: 3rem; text-align: center; color: var(--text-muted); font-size: 0.95rem; }
        
        footer { background: #111827; color: #9ca3af; text-align: center; padding: 1.25rem; font-size: 0.875rem; margin-top: auto; }
    </style>
</head>
<body>
    <header class="navbar">
        <a href="${pageContext.request.contextPath}/" class="navbar-brand">✈ Flight Reservation</a>
        <nav class="navbar-links">
            <a href="${pageContext.request.contextPath}/">Home</a>
            <a href="${pageContext.request.contextPath}/admin/dashboard">Dashboard</a>
            <a href="${pageContext.request.contextPath}/admin/flight/add">Add Flight</a>
            <span class="admin-badge">@ admin (Admin)</span>
            <a href="${pageContext.request.contextPath}/logout">Logout</a>
        </nav>
    </header>

    <main class="container">
        <div class="header-bar">
            <h1>✈ Flight Journey Status</h1>
            <a href="${pageContext.request.contextPath}/admin/dashboard" class="btn-dash">&larr; Back to Dashboard</a>
        </div>

        <div class="date-banner">
            📅 Current Date: <strong>${currentDate}</strong>
        </div>

        <!-- Navigation Tabs -->
        <div class="tabs">
            <button class="tab-btn active" id="tabUpcomingBtn" onclick="switchTab('upcoming')">Upcoming Journeys</button>
            <button class="tab-btn" id="tabCompletedBtn" onclick="switchTab('completed')">Completed Journey</button>
        </div>

        <!-- Upcoming Journeys Tab Content -->
        <div id="tabUpcoming" class="card">
            <c:choose>
                <c:when test="${not empty upcomingFlights}">
                    <table>
                        <thead>
                            <tr>
                                <th>Flight Number</th>
                                <th>Journey Date</th>
                                <th>Total Passengers</th>
                                <th>Total Bookings</th>
                                <th>Total Revenue</th>
                                <th>Days Until Journey</th>
                            </tr>
                        </thead>
                        <tbody>
                            <c:forEach var="item" items="${upcomingFlights}">
                                <tr>
                                    <td><span class="badge-flight">${item.flightNumber}</span></td>
                                    <td><strong>${item.journeyDate}</strong></td>
                                    <td><span class="badge-passengers">👥 ${item.totalPassengers}</span></td>
                                    <td><span class="badge-bookings">📑 ${item.totalBookings}</span></td>
                                    <td><strong>&#8377; ${item.totalRevenue}</strong></td>
                                    <td><span class="days-badge">${item.daysUntilJourney}</span></td>
                                </tr>
                            </c:forEach>
                        </tbody>
                    </table>
                </c:when>
                <c:otherwise>
                    <div class="empty-state">No upcoming booked flights scheduled at this time.</div>
                </c:otherwise>
            </c:choose>
        </div>

        <!-- Completed Journeys Tab Content -->
        <div id="tabCompleted" class="card" style="display: none;">
            <c:choose>
                <c:when test="${not empty completedFlights}">
                    <table>
                        <thead>
                            <tr>
                                <th>Flight Number</th>
                                <th>Journey Date</th>
                                <th>Total Passengers</th>
                                <th>Total Bookings</th>
                                <th>Total Revenue</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <c:forEach var="item" items="${completedFlights}">
                                <tr>
                                    <td><span class="badge-flight">${item.flightNumber}</span></td>
                                    <td><strong>${item.journeyDate}</strong></td>
                                    <td><span class="badge-passengers">👥 ${item.totalPassengers}</span></td>
                                    <td><span class="badge-bookings">📑 ${item.totalBookings}</span></td>
                                    <td><strong>&#8377; ${item.totalRevenue}</strong></td>
                                    <td><span class="days-badge" style="background:#e2e8f0; color:#475569;">Completed</span></td>
                                </tr>
                            </c:forEach>
                        </tbody>
                    </table>
                </c:when>
                <c:otherwise>
                    <div class="empty-state">No past completed flight journeys recorded.</div>
                </c:otherwise>
            </c:choose>
        </div>
    </main>

    <script>
        function switchTab(tab) {
            var upcoming = document.getElementById('tabUpcoming');
            var completed = document.getElementById('tabCompleted');
            var btnUpcoming = document.getElementById('tabUpcomingBtn');
            var btnCompleted = document.getElementById('tabCompletedBtn');

            if (tab === 'upcoming') {
                upcoming.style.display = 'block';
                completed.style.display = 'none';
                btnUpcoming.classList.add('active');
                btnCompleted.classList.remove('active');
            } else {
                upcoming.style.display = 'none';
                completed.style.display = 'block';
                btnUpcoming.classList.remove('active');
                btnCompleted.classList.add('active');
            }
        }
    </script>

    <footer>
        &copy; 2026 Flight Reservation System. All rights reserved.
    </footer>
</body>
</html>
