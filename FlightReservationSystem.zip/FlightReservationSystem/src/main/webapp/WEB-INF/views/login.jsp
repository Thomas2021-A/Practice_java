<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Flight Reservation - Login</title>
    <style>
        :root {
            --primary: #4f46e5;
            --primary-hover: #4338ca;
            --bg: #f8fafc;
            --card-bg: #ffffff;
            --text-dark: #1e293b;
            --text-muted: #64748b;
            --border: #e2e8f0;
            --danger: #ef4444;
            --success: #10b981;
        }
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; }
        body { background: var(--bg); color: var(--text-dark); min-height: 100vh; display: flex; flex-direction: column; }
        
        .navbar { background: #111827; color: white; padding: 0.9rem 2rem; display: flex; justify-content: space-between; align-items: center; }
        .navbar-brand { font-size: 1.25rem; font-weight: 700; color: #ffffff; text-decoration: none; }
        .navbar-links a { color: #d1d5db; text-decoration: none; font-size: 0.95rem; font-weight: 500; margin-left: 1.25rem; }
        .navbar-links a:hover, .navbar-links a.active { color: #ffffff; }
        
        .auth-container { flex: 1; display: flex; justify-content: center; align-items: center; padding: 2.5rem 1rem; }
        .auth-card { background: var(--card-bg); border: 1px solid var(--border); border-radius: 0.75rem; width: 100%; max-width: 400px; padding: 2.25rem; box-shadow: 0 10px 25px -5px rgba(0,0,0,0.08); }
        .auth-card h2 { font-size: 1.5rem; margin-bottom: 0.5rem; color: #0f172a; display: flex; align-items: center; gap: 0.5rem; }
        .auth-card p.sub { color: var(--text-muted); font-size: 0.9rem; margin-bottom: 1.5rem; }
        
        .form-group { margin-bottom: 1.25rem; }
        label { display: block; font-size: 0.875rem; font-weight: 600; margin-bottom: 0.4rem; color: #334155; }
        input[type="text"], input[type="email"], input[type="password"] { width: 100%; padding: 0.75rem 0.9rem; border: 1px solid #cbd5e1; border-radius: 0.5rem; font-size: 0.95rem; outline: none; transition: border-color 0.2s; }
        input:focus { border-color: var(--primary); box-shadow: 0 0 0 3px rgba(79, 70, 229, 0.15); }
        
        .btn { display: inline-flex; align-items: center; justify-content: center; width: 100%; padding: 0.75rem 1rem; font-size: 1rem; font-weight: 600; border-radius: 0.5rem; border: none; cursor: pointer; text-decoration: none; background: var(--primary); color: white; transition: background 0.2s; margin-top: 0.5rem; }
        .btn:hover { background: var(--primary-hover); }
        
        .auth-footer { margin-top: 1.5rem; text-align: center; font-size: 0.9rem; color: var(--text-muted); }
        .auth-footer a { color: var(--primary); text-decoration: none; font-weight: 600; }
        .auth-footer a:hover { text-decoration: underline; }
        
        .alert { padding: 0.75rem 1rem; border-radius: 0.5rem; margin-bottom: 1.25rem; font-size: 0.9rem; }
        .alert-danger { background: #fef2f2; border: 1px solid #fecaca; color: #b91c1c; }
        .alert-success { background: #f0fdf4; border: 1px solid #bbf7d0; color: #15803d; }
        .alert-info { background: #eff6ff; border: 1px solid #bfdbfe; color: #1d4ed8; }
        
        footer { background: #111827; color: #9ca3af; text-align: center; padding: 1.25rem; font-size: 0.875rem; margin-top: auto; }
    </style>
</head>
<body>
    <header class="navbar">
        <a href="${pageContext.request.contextPath}/" class="navbar-brand">✈ Flight Reservation</a>
        <nav class="navbar-links">
            <a href="${pageContext.request.contextPath}/">Home</a>
            <a href="${pageContext.request.contextPath}/login" class="active">Login</a>
            <a href="${pageContext.request.contextPath}/signup">Sign Up</a>
        </nav>
    </header>

    <div class="auth-container">
        <div class="auth-card">
            <h2>🔑 Login</h2>
            <p class="sub">Sign in to book flights and manage reservations</p>

            <c:if test="${not empty error}">
                <div class="alert alert-danger">${error}</div>
            </c:if>
            <c:if test="${not empty successMsg}">
                <div class="alert alert-success">${successMsg}</div>
            </c:if>
            <c:if test="${not empty infoMsg}">
                <div class="alert alert-info">${infoMsg}</div>
            </c:if>

            <form:form action="${pageContext.request.contextPath}/login" method="post" modelAttribute="loginDto">
                <div class="form-group">
                    <label for="email">Email</label>
                    <form:input path="email" id="email" type="email" placeholder="Enter your email" required="required" autocomplete="email" />
                </div>

                <div class="form-group">
                    <label for="password">Password</label>
                    <form:input path="password" id="password" type="password" placeholder="Enter your password" required="required" autocomplete="current-password" />
                </div>

                <button type="submit" class="btn">🔑 Login</button>
            </form:form>

            <div class="auth-footer">
                Don't have an account? <a href="${pageContext.request.contextPath}/signup">Sign up here</a>
            </div>
        </div>
    </div>

    <footer>
        &copy; 2026 Flight Reservation System. All rights reserved.
    </footer>
</body>
</html>
