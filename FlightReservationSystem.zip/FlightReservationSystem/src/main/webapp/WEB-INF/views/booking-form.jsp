<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Flight Reservation - Book Flight</title>
    <style>
        :root {
            --primary: #2563eb;
            --primary-hover: #1d4ed8;
            --bg: #f8fafc;
            --card-bg: #ffffff;
            --text-dark: #1e293b;
            --text-muted: #64748b;
            --border: #e2e8f0;
            --danger: #ef4444;
        }
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; }
        body { background: var(--bg); color: var(--text-dark); min-height: 100vh; display: flex; flex-direction: column; }
        
        .navbar { background: #111827; color: white; padding: 0.9rem 2rem; display: flex; justify-content: space-between; align-items: center; }
        .navbar-brand { font-size: 1.25rem; font-weight: 700; color: #ffffff; text-decoration: none; }
        .navbar-links { display: flex; align-items: center; gap: 1.25rem; }
        .navbar-links a { color: #d1d5db; text-decoration: none; font-size: 0.95rem; font-weight: 500; }
        .navbar-links a:hover { color: #ffffff; }
        .user-badge { background: #374151; padding: 0.25rem 0.75rem; border-radius: 9999px; font-size: 0.85rem; color: #60a5fa; }
        
        .container { max-width: 550px; margin: 2.5rem auto; padding: 0 1rem; flex: 1; width: 100%; }
        .card { background: var(--card-bg); border: 1px solid var(--border); border-radius: 0.75rem; padding: 2rem; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05); }
        .card h2 { font-size: 1.5rem; color: #0f172a; margin-bottom: 1.25rem; }
        
        .flight-banner { background: #cffafe; border: 1px solid #a5f3fc; color: #0e7490; padding: 0.85rem 1rem; border-radius: 0.5rem; font-weight: 700; font-size: 1.05rem; margin-bottom: 1.5rem; }
        .route-info { font-size: 0.9rem; color: #155e75; font-weight: normal; margin-top: 0.25rem; }
        
        .form-group { margin-bottom: 1.25rem; }
        label { display: block; font-size: 0.875rem; font-weight: 600; margin-bottom: 0.4rem; color: #334155; }
        input[type="date"], input[type="number"] { width: 100%; padding: 0.75rem 0.9rem; border: 1px solid #cbd5e1; border-radius: 0.5rem; font-size: 0.95rem; outline: none; }
        input:focus { border-color: var(--primary); box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.15); }
        .hint { font-size: 0.8rem; color: var(--text-muted); margin-top: 0.35rem; }
        
        .btn { display: inline-flex; align-items: center; justify-content: center; width: 100%; padding: 0.75rem 1rem; font-size: 1rem; font-weight: 600; border-radius: 0.5rem; border: none; cursor: pointer; text-decoration: none; transition: all 0.2s; }
        .btn-blue { background: #2563eb; color: white; margin-top: 0.5rem; }
        .btn-blue:hover { background: #1d4ed8; }
        .btn-secondary { background: #64748b; color: white; margin-top: 0.75rem; }
        .btn-secondary:hover { background: #475569; }
        
        .alert { padding: 0.75rem 1rem; border-radius: 0.5rem; margin-bottom: 1.25rem; font-size: 0.9rem; }
        .alert-danger { background: #fef2f2; border: 1px solid #fecaca; color: #b91c1c; }
        
        footer { background: #111827; color: #9ca3af; text-align: center; padding: 1.25rem; font-size: 0.875rem; margin-top: auto; }
    </style>
</head>
<body>
    <header class="navbar">
        <a href="${pageContext.request.contextPath}/" class="navbar-brand">✈ Flight Reservation</a>
        <nav class="navbar-links">
            <a href="${pageContext.request.contextPath}/">Home</a>
            <a href="${pageContext.request.contextPath}/user/dashboard">Dashboard</a>
            <a href="${pageContext.request.contextPath}/booking/my-bookings">My Bookings</a>
            <span class="user-badge">${sessionScope.user.email}</span>
            <a href="${pageContext.request.contextPath}/logout">Logout</a>
        </nav>
    </header>

    <main class="container">
        <div class="card">
            <h2>Book Flight</h2>

            <div class="flight-banner">
                Flight Number: ${flight.flightNumber}
                <div class="route-info">
                    ${flight.source} &rarr; ${flight.destination} &bull; Dep: ${flight.departureTime} | Arr: ${flight.arrivalTime} &bull; Price: &#8377; ${flight.pricePerSeat} / seat
                </div>
            </div>

            <c:if test="${not empty error}">
                <div class="alert alert-danger">${error}</div>
            </c:if>

            <form:form action="${pageContext.request.contextPath}/booking/check-availability" method="post" modelAttribute="bookingFormDto">
                <form:hidden path="flightId" />

                <div class="form-group">
                    <label for="journeyDate">Journey Date *</label>
                    <form:input path="journeyDate" id="journeyDate" type="date" required="required" />
                </div>

                <div class="form-group">
                    <label for="seats">Number of Passengers *</label>
                    <form:input path="seats" id="seats" type="number" min="1" max="10" required="required" />
                    <div class="hint">Maximum 10 passengers allowed</div>
                </div>

                <button type="submit" class="btn btn-blue">Book Now</button>
                <a href="${pageContext.request.contextPath}/user/dashboard" class="btn btn-secondary">Back to Dashboard</a>
            </form:form>
        </div>
    </main>

    <footer>
        &copy; 2026 Flight Reservation System. All rights reserved.
    </footer>
</body>
</html>
