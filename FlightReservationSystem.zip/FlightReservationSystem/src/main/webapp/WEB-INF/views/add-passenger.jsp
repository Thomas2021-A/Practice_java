<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Flight Reservation - Add Passenger ${currentIndex}</title>
    <style>
        :root {
            --primary: #2563eb;
            --primary-hover: #1d4ed8;
            --bg: #f8fafc;
            --card-bg: #ffffff;
            --text-dark: #1e293b;
            --text-muted: #64748b;
            --border: #e2e8f0;
            --danger: #ef4444;
        }
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; }
        body { background: var(--bg); color: var(--text-dark); min-height: 100vh; display: flex; flex-direction: column; }
        
        .navbar { background: #111827; color: white; padding: 0.9rem 2rem; display: flex; justify-content: space-between; align-items: center; }
        .navbar-brand { font-size: 1.25rem; font-weight: 700; color: #ffffff; text-decoration: none; }
        .navbar-links { display: flex; align-items: center; gap: 1.25rem; }
        .navbar-links a { color: #d1d5db; text-decoration: none; font-size: 0.95rem; font-weight: 500; }
        .user-badge { background: #374151; padding: 0.25rem 0.75rem; border-radius: 9999px; font-size: 0.85rem; color: #60a5fa; }
        
        .container { max-width: 520px; margin: 2.5rem auto; padding: 0 1rem; flex: 1; width: 100%; }
        .card { background: var(--card-bg); border: 1px solid var(--border); border-radius: 0.75rem; padding: 2rem; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05); }
        
        .passenger-header { margin-bottom: 1.25rem; }
        .passenger-header h2 { font-size: 1.4rem; color: #0f172a; margin-bottom: 0.25rem; }
        .passenger-header .remaining { color: var(--text-muted); font-size: 0.9rem; }
        
        /* Progress Bar */
        .progress-container { margin-bottom: 1.5rem; }
        .progress-bar-bg { width: 100%; height: 8px; background: #e2e8f0; border-radius: 9999px; overflow: hidden; }
        .progress-bar-fill { height: 100%; background: var(--primary); border-radius: 9999px; transition: width 0.3s ease; }
        .progress-text { display: flex; justify-content: space-between; font-size: 0.8rem; color: var(--text-muted); margin-top: 0.4rem; }
        
        .form-group { margin-bottom: 1.25rem; }
        label { display: block; font-size: 0.875rem; font-weight: 600; margin-bottom: 0.4rem; color: #334155; }
        input[type="text"], input[type="number"], select { width: 100%; padding: 0.75rem 0.9rem; border: 1px solid #cbd5e1; border-radius: 0.5rem; font-size: 0.95rem; outline: none; }
        input:focus, select:focus { border-color: var(--primary); box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.15); }
        
        .btn { display: inline-flex; align-items: center; justify-content: center; width: 100%; padding: 0.8rem 1rem; font-size: 1rem; font-weight: 600; border-radius: 0.5rem; border: none; cursor: pointer; text-decoration: none; transition: all 0.2s; margin-top: 0.5rem; }
        .btn-blue { background: #2563eb; color: white; }
        .btn-blue:hover { background: #1d4ed8; }
        
        .alert { padding: 0.75rem 1rem; border-radius: 0.5rem; margin-bottom: 1.25rem; font-size: 0.9rem; }
        .alert-danger { background: #fef2f2; border: 1px solid #fecaca; color: #b91c1c; }
        
        footer { background: #111827; color: #9ca3af; text-align: center; padding: 1.25rem; font-size: 0.875rem; margin-top: auto; }
    </style>
</head>
<body>
    <header class="navbar">
        <a href="${pageContext.request.contextPath}/" class="navbar-brand">✈ Flight Reservation</a>
        <nav class="navbar-links">
            <a href="${pageContext.request.contextPath}/">Home</a>
            <a href="${pageContext.request.contextPath}/user/dashboard">Dashboard</a>
            <span class="user-badge">${sessionScope.user.email}</span>
        </nav>
    </header>

    <main class="container">
        <div class="card">
            <div class="passenger-header">
                <h2>Add Passenger ${currentIndex}</h2>
                <div class="remaining">Remaining passengers: ${remainingPassengers}</div>
            </div>

            <!-- Visual Progress Bar -->
            <div class="progress-container">
                <div class="progress-bar-bg">
                    <div class="progress-bar-fill" style="width: ${(currentIndex / totalPassengers) * 100}%;"></div>
                </div>
                <div class="progress-text">
                    <span>Passenger ${currentIndex} of ${totalPassengers}</span>
                    <span>Flight: ${flight.flightNumber}</span>
                </div>
            </div>

            <c:if test="${not empty error}">
                <div class="alert alert-danger">${error}</div>
            </c:if>

            <form:form action="${pageContext.request.contextPath}/booking/passenger" method="post" modelAttribute="passengerDto">
                <div class="form-group">
                    <label for="passengerName">Passenger Name *</label>
                    <form:input path="passengerName" id="passengerName" placeholder="Enter full name" required="required" autocomplete="name" />
                </div>

                <div class="form-group">
                    <label for="age">Age *</label>
                    <form:input path="age" id="age" type="number" min="0" max="120" placeholder="0" required="required" />
                </div>

                <div class="form-group">
                    <label for="gender">Gender *</label>
                    <form:select path="gender" id="gender" required="required">
                        <form:option value="" label="Select Gender" />
                        <form:option value="male" label="Male" />
                        <form:option value="female" label="Female" />
                        <form:option value="other" label="Other" />
                    </form:select>
                </div>

                <c:choose>
                    <c:when test="${isLastPassenger}">
                        <button type="submit" class="btn btn-blue">Complete Booking</button>
                    </c:when>
                    <c:otherwise>
                        <button type="submit" class="btn btn-blue">Add Passenger &amp; Continue</button>
                    </c:otherwise>
                </c:choose>
            </form:form>
        </div>
    </main>

    <footer>
        &copy; 2026 Flight Reservation System. All rights reserved.
    </footer>
</body>
</html>
