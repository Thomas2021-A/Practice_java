<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Flight Reservation - My Tickets</title>
    <style>
        :root {
            --primary: #2563eb;
            --primary-hover: #1d4ed8;
            --bg: #f8fafc;
            --card-bg: #ffffff;
            --text-dark: #1e293b;
            --text-muted: #64748b;
            --border: #e2e8f0;
        }
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; }
        body { background: var(--bg); color: var(--text-dark); min-height: 100vh; display: flex; flex-direction: column; }
        
        .navbar { background: #111827; color: white; padding: 0.9rem 2rem; display: flex; justify-content: space-between; align-items: center; }
        .navbar-brand { font-size: 1.25rem; font-weight: 700; color: #ffffff; text-decoration: none; }
        .navbar-links { display: flex; align-items: center; gap: 1.25rem; }
        .navbar-links a { color: #d1d5db; text-decoration: none; font-size: 0.95rem; font-weight: 500; }
        .user-badge { background: #374151; padding: 0.25rem 0.75rem; border-radius: 9999px; font-size: 0.85rem; color: #60a5fa; }
        
        .container { max-width: 1000px; margin: 2rem auto; padding: 0 1rem; flex: 1; width: 100%; }
        
        .top-bar { display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem; }
        .top-bar h1 { font-size: 1.5rem; color: #0f172a; display: flex; align-items: center; gap: 0.5rem; }
        .top-bar p { color: var(--text-muted); font-size: 0.9rem; }
        .btn-group { display: flex; gap: 0.75rem; }
        .btn { display: inline-flex; align-items: center; justify-content: center; padding: 0.5rem 1rem; font-size: 0.875rem; font-weight: 600; border-radius: 0.375rem; text-decoration: none; border: none; cursor: pointer; }
        .btn-print { background: #2563eb; color: white; }
        .btn-print:hover { background: #1d4ed8; }
        .btn-back { background: #f1f5f9; color: #334155; border: 1px solid var(--border); }
        .btn-back:hover { background: #e2e8f0; }
        
        /* Grid of Tickets */
        .tickets-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(340px, 1fr)); gap: 1.5rem; }
        
        /* Ticket Card */
        .ticket-card { background: var(--card-bg); border: 1px solid #cbd5e1; border-radius: 0.75rem; overflow: hidden; box-shadow: 0 6px 15px -3px rgba(0,0,0,0.06); }
        .ticket-header { background: #2563eb; color: white; padding: 0.85rem 1.25rem; display: flex; justify-content: space-between; align-items: center; font-weight: 700; font-size: 1rem; }
        .ticket-pnr { background: rgba(255,255,255,0.2); padding: 0.2rem 0.6rem; border-radius: 0.25rem; font-size: 0.85rem; font-family: monospace; letter-spacing: 0.5px; }
        
        .ticket-body { padding: 1.25rem; }
        
        .section-heading { font-size: 0.8rem; font-weight: 700; text-transform: uppercase; color: #2563eb; letter-spacing: 0.5px; margin-bottom: 0.5rem; display: flex; align-items: center; gap: 0.4rem; }
        .info-row { display: flex; justify-content: space-between; margin-bottom: 0.6rem; font-size: 0.9rem; }
        .info-label { color: var(--text-muted); }
        .info-value { font-weight: 600; color: #1e293b; }
        
        .divider { border-top: 1px dashed #cbd5e1; margin: 1rem 0; }
        
        .seat-badge { background: #0284c7; color: white; padding: 0.2rem 0.6rem; border-radius: 0.25rem; font-weight: 700; font-size: 0.85rem; }
        .status-pill { display: inline-block; padding: 0.2rem 0.5rem; border-radius: 9999px; font-size: 0.75rem; font-weight: 700; }
        .status-pill.confirmed { background: #dcfce7; color: #166534; }
        .status-pill.cancelled { background: #fee2e2; color: #991b1b; }
        
        footer { background: #111827; color: #9ca3af; text-align: center; padding: 1.25rem; font-size: 0.875rem; margin-top: auto; }
        
        @media print {
            .navbar, footer, .btn-group { display: none; }
            body { background: white; }
            .container { max-width: 100%; margin: 0; padding: 0; }
            .ticket-card { break-inside: avoid; margin-bottom: 1.5rem; }
        }
    </style>
</head>
<body>
    <header class="navbar">
        <a href="${pageContext.request.contextPath}/" class="navbar-brand">✈ Flight Reservation</a>
        <nav class="navbar-links">
            <a href="${pageContext.request.contextPath}/">Home</a>
            <a href="${pageContext.request.contextPath}/user/dashboard">Dashboard</a>
            <a href="${pageContext.request.contextPath}/booking/my-bookings">My Bookings</a>
            <span class="user-badge">${sessionScope.user.email}</span>
            <a href="${pageContext.request.contextPath}/logout">Logout</a>
        </nav>
    </header>

    <main class="container">
        <div class="top-bar">
            <div>
                <h1>🎫 My Tickets</h1>
                <p>View and download your flight boarding passes</p>
            </div>
            <div class="btn-group">
                <button onclick="window.print()" class="btn btn-print">🖨 Print Tickets</button>
                <a href="${pageContext.request.contextPath}/booking/my-bookings" class="btn btn-back">&larr; Back to Bookings</a>
            </div>
        </div>

        <div class="tickets-grid">
            <c:forEach var="t" items="${tickets}">
                <div class="ticket-card">
                    <div class="ticket-header">
                        <span>✈ Flight Ticket</span>
                        <span class="ticket-pnr">PNR: ${t.pnrNo}</span>
                    </div>
                    <div class="ticket-body">
                        <!-- Passenger Information -->
                        <div class="section-heading">👤 Passenger Information</div>
                        <div class="info-row">
                            <span class="info-label">Name</span>
                            <span class="info-value">${t.passengerName}</span>
                        </div>
                        <div class="info-row">
                            <span class="info-label">Gender</span>
                            <span class="info-value" style="text-transform: capitalize;">${t.gender}</span>
                        </div>
                        <div class="info-row">
                            <span class="info-label">Age</span>
                            <span class="info-value">${t.age} years</span>
                        </div>

                        <div class="divider"></div>

                        <!-- Travel Information -->
                        <div class="section-heading">🛫 Travel Information</div>
                        <div class="info-row">
                            <span class="info-label">Flight</span>
                            <span class="info-value">${t.flightNumber} (${t.source} &rarr; ${t.destination})</span>
                        </div>
                        <div class="info-row">
                            <span class="info-label">Schedule</span>
                            <span class="info-value">Dep: ${t.departureTime} | Arr: ${t.arrivalTime}</span>
                        </div>
                        <div class="info-row">
                            <span class="info-label">Journey Date</span>
                            <span class="info-value">${t.journeyDate}</span>
                        </div>
                        <div class="info-row">
                            <span class="info-label">Seat Number</span>
                            <span class="seat-badge">${t.seatNo}</span>
                        </div>

                        <div class="divider"></div>

                        <!-- Booking Details -->
                        <div class="section-heading">📑 Booking Details</div>
                        <div class="info-row">
                            <span class="info-label">Booking ID</span>
                            <span class="info-value">#${t.bookingId}</span>
                        </div>
                        <div class="info-row">
                            <span class="info-label">Status</span>
                            <c:choose>
                                <c:when test="${t.status eq 'confirmed'}">
                                    <span class="status-pill confirmed">BOOKED</span>
                                </c:when>
                                <c:otherwise>
                                    <span class="status-pill cancelled">CANCELLED</span>
                                </c:otherwise>
                            </c:choose>
                        </div>
                    </div>
                </div>
            </c:forEach>
        </div>
    </main>

    <footer>
        &copy; 2026 Flight Reservation System. All rights reserved.
    </footer>
</body>
</html>
