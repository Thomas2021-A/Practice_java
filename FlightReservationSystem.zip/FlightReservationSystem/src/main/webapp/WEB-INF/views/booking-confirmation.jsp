<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Flight Reservation - Booking Confirmed</title>
    <style>
        :root {
            --primary: #10b981;
            --primary-hover: #059669;
            --bg: #f8fafc;
            --card-bg: #ffffff;
            --text-dark: #1e293b;
            --text-muted: #64748b;
            --border: #e2e8f0;
        }
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; }
        body { background: var(--bg); color: var(--text-dark); min-height: 100vh; display: flex; flex-direction: column; }
        
        .navbar { background: #111827; color: white; padding: 0.9rem 2rem; display: flex; justify-content: space-between; align-items: center; }
        .navbar-brand { font-size: 1.25rem; font-weight: 700; color: #ffffff; text-decoration: none; }
        .navbar-links { display: flex; align-items: center; gap: 1.25rem; }
        .navbar-links a { color: #d1d5db; text-decoration: none; font-size: 0.95rem; font-weight: 500; }
        .user-badge { background: #374151; padding: 0.25rem 0.75rem; border-radius: 9999px; font-size: 0.85rem; color: #60a5fa; }
        
        .container { max-width: 600px; margin: 2.5rem auto; padding: 0 1rem; flex: 1; width: 100%; }
        .card { background: var(--card-bg); border: 1px solid var(--border); border-radius: 0.75rem; overflow: hidden; box-shadow: 0 10px 25px -5px rgba(0,0,0,0.08); }
        
        .confirmation-banner { background: #10b981; color: white; text-align: center; padding: 1.25rem; font-size: 1.25rem; font-weight: 700; display: flex; align-items: center; justify-content: center; gap: 0.5rem; }
        
        .card-body { padding: 2rem; text-align: center; }
        .plane-icon { font-size: 3rem; color: #10b981; margin-bottom: 0.75rem; }
        .congrats { font-size: 1.35rem; font-weight: 700; color: #0f172a; margin-bottom: 1.25rem; }
        
        .booking-id-box { background: #f0fdf4; border: 2px dashed #86efac; color: #166534; padding: 0.85rem 1.5rem; border-radius: 0.5rem; font-size: 1.2rem; font-weight: 700; display: inline-block; margin-bottom: 1.75rem; }
        
        /* 3 Feature Badges */
        .features-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 1rem; margin-bottom: 2rem; }
        .feature-item { background: #f8fafc; border: 1px solid var(--border); border-radius: 0.5rem; padding: 1rem 0.5rem; text-align: center; }
        .feature-icon { font-size: 1.25rem; margin-bottom: 0.25rem; color: #059669; }
        .feature-title { font-size: 0.85rem; font-weight: 700; color: #1e293b; }
        .feature-desc { font-size: 0.75rem; color: var(--text-muted); margin-top: 0.15rem; }
        
        /* Next Steps */
        .next-steps-card { background: #f8fafc; border: 1px solid var(--border); border-radius: 0.5rem; padding: 1.25rem; text-align: left; margin-bottom: 2rem; font-size: 0.9rem; }
        .next-steps-card h4 { font-size: 0.95rem; color: #334155; margin-bottom: 0.75rem; display: flex; align-items: center; gap: 0.4rem; }
        .next-steps-card ul { list-style: none; padding-left: 0; }
        .next-steps-card li { margin-bottom: 0.4rem; color: #475569; display: flex; align-items: center; gap: 0.5rem; }
        .next-steps-card li::before { content: "✓"; color: #10b981; font-weight: bold; }
        
        /* Action Buttons */
        .btn-group { display: flex; gap: 1rem; }
        .btn { flex: 1; display: inline-flex; align-items: center; justify-content: center; padding: 0.75rem 1rem; font-size: 0.95rem; font-weight: 600; border-radius: 0.5rem; border: none; cursor: pointer; text-decoration: none; transition: all 0.2s; }
        .btn-dash { background: #059669; color: white; }
        .btn-dash:hover { background: #047857; }
        .btn-print { background: #ffffff; color: #2563eb; border: 1px solid #bfdbfe; }
        .btn-print:hover { background: #eff6ff; }
        
        footer { background: #111827; color: #9ca3af; text-align: center; padding: 1.25rem; font-size: 0.875rem; margin-top: auto; }
        
        @media print {
            .navbar, footer, .btn-group { display: none; }
            body { background: white; }
            .card { box-shadow: none; border: 1px solid #ccc; }
        }
    </style>
</head>
<body>
    <header class="navbar">
        <a href="${pageContext.request.contextPath}/" class="navbar-brand">✈ Flight Reservation</a>
        <nav class="navbar-links">
            <a href="${pageContext.request.contextPath}/">Home</a>
            <a href="${pageContext.request.contextPath}/user/dashboard">Dashboard</a>
            <a href="${pageContext.request.contextPath}/booking/my-bookings">My Bookings</a>
            <span class="user-badge">${sessionScope.user.email}</span>
            <a href="${pageContext.request.contextPath}/logout">Logout</a>
        </nav>
    </header>

    <main class="container">
        <div class="card">
            <div class="confirmation-banner">
                ✓ Booking Confirmed!
            </div>
            <div class="card-body">
                <div class="plane-icon">✈</div>
                <div class="congrats">Congratulations! Your flight is booked!</div>

                <div class="booking-id-box">
                    🎫 Booking ID: #${booking.bookingId}
                </div>

                <div class="features-grid">
                    <div class="feature-item">
                        <div class="feature-icon">🛡</div>
                        <div class="feature-title">Secured</div>
                        <div class="feature-desc">Your booking is protected</div>
                    </div>
                    <div class="feature-item">
                        <div class="feature-icon">✉</div>
                        <div class="feature-title">Email Sent</div>
                        <div class="feature-desc">Confirmation details sent</div>
                    </div>
                    <div class="feature-item">
                        <div class="feature-icon">⏱</div>
                        <div class="feature-title">Ready</div>
                        <div class="feature-desc">Check-in 24hrs before</div>
                    </div>
                </div>

                <div class="next-steps-card">
                    <h4>ℹ Next Steps:</h4>
                    <ul>
                        <li>Save your booking ID for future reference</li>
                        <li>Check your email for detailed itinerary</li>
                        <li>Arrive at airport 2 hours before departure</li>
                        <li>Complete online check-in 24 hours before flight</li>
                    </ul>
                </div>

                <div class="btn-group">
                    <a href="${pageContext.request.contextPath}/user/dashboard" class="btn btn-dash">🏠 Go to Dashboard</a>
                    <button onclick="window.print()" class="btn btn-print">🖨 Print Confirmation</button>
                </div>
            </div>
        </div>
    </main>

    <footer>
        &copy; 2026 Flight Reservation System. All rights reserved.
    </footer>
</body>
</html>
