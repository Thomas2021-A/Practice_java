<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Flight Reservation - Error</title>
    <style>
        :root {
            --primary: #4f46e5;
            --bg: #f8fafc;
            --card-bg: #ffffff;
            --text-dark: #1e293b;
            --text-muted: #64748b;
            --border: #e2e8f0;
            --danger: #ef4444;
        }
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; }
        body { background: var(--bg); color: var(--text-dark); min-height: 100vh; display: flex; flex-direction: column; }
        
        .navbar { background: #111827; color: white; padding: 0.9rem 2rem; display: flex; justify-content: space-between; align-items: center; }
        .navbar-brand { font-size: 1.25rem; font-weight: 700; color: #ffffff; text-decoration: none; }
        .navbar-links a { color: #d1d5db; text-decoration: none; font-size: 0.95rem; font-weight: 500; margin-left: 1rem; }
        
        .container { flex: 1; display: flex; align-items: center; justify-content: center; padding: 2rem 1rem; }
        .error-card { background: var(--card-bg); border: 1px solid var(--border); border-radius: 0.75rem; max-width: 500px; width: 100%; padding: 2.5rem; text-align: center; box-shadow: 0 10px 25px -5px rgba(0,0,0,0.08); }
        .error-icon { font-size: 3.5rem; color: var(--danger); margin-bottom: 1rem; }
        .error-title { font-size: 1.5rem; color: #0f172a; margin-bottom: 0.75rem; }
        .error-msg { color: #475569; font-size: 1rem; line-height: 1.5; margin-bottom: 1.5rem; }
        .error-details { background: #f1f5f9; border-radius: 0.375rem; padding: 0.75rem; font-size: 0.85rem; color: #64748b; font-family: monospace; word-break: break-all; margin-bottom: 1.5rem; text-align: left; }
        
        .btn { display: inline-flex; align-items: center; justify-content: center; padding: 0.75rem 1.5rem; font-size: 0.95rem; font-weight: 600; border-radius: 0.5rem; text-decoration: none; background: var(--primary); color: white; transition: background 0.2s; }
        .btn:hover { background: #4338ca; }
        
        footer { background: #111827; color: #9ca3af; text-align: center; padding: 1.25rem; font-size: 0.875rem; margin-top: auto; }
    </style>
</head>
<body>
    <header class="navbar">
        <a href="${pageContext.request.contextPath}/" class="navbar-brand">✈ Flight Reservation</a>
        <nav class="navbar-links">
            <a href="${pageContext.request.contextPath}/">Home</a>
        </nav>
    </header>

    <main class="container">
        <div class="error-card">
            <div class="error-icon">⚠️</div>
            <h2 class="error-title">Oops! Something went wrong</h2>
            <p class="error-msg">${errorMessage != null ? errorMessage : 'An unexpected error occurred while processing your request.'}</p>
            
            <c:if test="${not empty errorDetails}">
                <div class="error-details">
                    ${errorDetails}
                </div>
            </c:if>

            <a href="${pageContext.request.contextPath}/" class="btn">🏠 Return to Home</a>
        </div>
    </main>

    <footer>
        &copy; 2026 Flight Reservation System. All rights reserved.
    </footer>
</body>
</html>
