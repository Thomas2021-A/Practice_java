package com.deloitte.flight.controller;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.deloitte.flight.dto.BookingFormDto;
import com.deloitte.flight.dto.PassengerDto;
import com.deloitte.flight.model.Booking;
import com.deloitte.flight.model.Flight;
import com.deloitte.flight.model.Ticket;
import com.deloitte.flight.model.User;
import com.deloitte.flight.service.BookingService;
import com.deloitte.flight.service.FlightService;

@Controller
@RequestMapping("/booking")
public class BookingController {

    private final FlightService flightService;
    private final BookingService bookingService;

    @Autowired
    public BookingController(FlightService flightService, BookingService bookingService) {
        this.flightService = flightService;
        this.bookingService = bookingService;
    }

    private User getLoggedInUser(HttpSession session) {
        return (User) session.getAttribute("user");
    }

    // Step 1: Show Booking Form
    @GetMapping("/form")
    public String showBookingForm(@RequestParam("flightId") Long flightId,
                                 HttpSession session, Model model) {
        User user = getLoggedInUser(session);
        if (user == null) {
            session.setAttribute("redirectFlightId", flightId);
            return "redirect:/login?msg=Please login to book flights and access your account.";
        }

        Flight flight = flightService.getFlightById(flightId);
        if (flight == null) {
            model.addAttribute("errorMessage", "Selected flight does not exist.");
            return "error";
        }

        BookingFormDto dto = new BookingFormDto();
        dto.setFlightId(flightId);
        dto.setJourneyDate(LocalDate.now().plusDays(1).toString());
        dto.setSeats(1);

        model.addAttribute("flight", flight);
        model.addAttribute("bookingFormDto", dto);
        return "booking-form";
    }

    // Step 2: Validate Booking Form & Check Seat Availability
    @PostMapping("/check-availability")
    public String checkAvailability(@ModelAttribute("bookingFormDto") BookingFormDto formDto,
                                    HttpSession session, Model model) {
        User user = getLoggedInUser(session);
        if (user == null) {
            return "redirect:/login";
        }

        Flight flight = flightService.getFlightById(formDto.getFlightId());
        model.addAttribute("flight", flight);

        if (formDto.getJourneyDate() == null || formDto.getJourneyDate().trim().isEmpty()) {
            model.addAttribute("error", "Journey Date is required.");
            return "booking-form";
        }

        // Check if journey date is not in the past
        LocalDate journeyDate = LocalDate.parse(formDto.getJourneyDate().trim());
        if (journeyDate.isBefore(LocalDate.now())) {
            model.addAttribute("error", "Journey date cannot be in the past.");
            return "booking-form";
        }

        if (formDto.getSeats() == null || formDto.getSeats() < 1 || formDto.getSeats() > 10) {
            model.addAttribute("error", "Number of passengers must be between 1 and 10.");
            return "booking-form";
        }

        int availableSeats = flightService.getAvailableSeats(formDto.getFlightId(), formDto.getJourneyDate().trim());
        if (availableSeats < formDto.getSeats()) {
            model.addAttribute("error", "Booking not allowed: Only " + availableSeats + " seat(s) available on "
                    + formDto.getJourneyDate() + ". You requested " + formDto.getSeats() + " seat(s).");
            return "booking-form";
        }

        // Initialize multi-step passenger session draft
        session.setAttribute("bookingFlightId", formDto.getFlightId());
        session.setAttribute("bookingJourneyDate", formDto.getJourneyDate().trim());
        session.setAttribute("bookingTotalPassengers", formDto.getSeats());
        session.setAttribute("bookingPassengersList", new ArrayList<PassengerDto>());
        session.setAttribute("currentPassengerIndex", 1);

        return "redirect:/booking/passenger";
    }

    // Step 3: Add Passenger Details Screen
    @GetMapping("/passenger")
    public String showAddPassengerPage(HttpSession session, Model model) {
        User user = getLoggedInUser(session);
        if (user == null) {
            return "redirect:/login";
        }

        Integer currentIdx = (Integer) session.getAttribute("currentPassengerIndex");
        Integer totalPassengers = (Integer) session.getAttribute("bookingTotalPassengers");
        Long flightId = (Long) session.getAttribute("bookingFlightId");

        if (currentIdx == null || totalPassengers == null || flightId == null) {
            return "redirect:/";
        }

        Flight flight = flightService.getFlightById(flightId);
        int remaining = totalPassengers - currentIdx;
        boolean isLast = (currentIdx.intValue() == totalPassengers.intValue());

        model.addAttribute("flight", flight);
        model.addAttribute("currentIndex", currentIdx);
        model.addAttribute("totalPassengers", totalPassengers);
        model.addAttribute("remainingPassengers", remaining);
        model.addAttribute("isLastPassenger", isLast);
        model.addAttribute("passengerDto", new PassengerDto());

        return "add-passenger";
    }

    // Step 4: Process Passenger Details & Continue or Complete
    @PostMapping("/passenger")
    public String processPassenger(@ModelAttribute("passengerDto") PassengerDto passengerDto,
                                   HttpSession session, Model model) {
        User user = getLoggedInUser(session);
        if (user == null) {
            return "redirect:/login";
        }

        Integer currentIdx = (Integer) session.getAttribute("currentPassengerIndex");
        Integer totalPassengers = (Integer) session.getAttribute("bookingTotalPassengers");
        Long flightId = (Long) session.getAttribute("bookingFlightId");
        String journeyDate = (String) session.getAttribute("bookingJourneyDate");

        @SuppressWarnings("unchecked")
        List<PassengerDto> passengersList = (List<PassengerDto>) session.getAttribute("bookingPassengersList");

        if (currentIdx == null || totalPassengers == null || passengersList == null || flightId == null) {
            return "redirect:/";
        }

        // Validate passenger inputs
        if (passengerDto.getPassengerName() == null || passengerDto.getPassengerName().trim().isEmpty()) {
            model.addAttribute("error", "Passenger name is required.");
            return preparePassengerModel(model, session, flightId, currentIdx, totalPassengers);
        }

        if (passengerDto.getAge() == null || passengerDto.getAge() < 0 || passengerDto.getAge() > 120) {
            model.addAttribute("error", "Please enter a valid age between 0 and 120.");
            return preparePassengerModel(model, session, flightId, currentIdx, totalPassengers);
        }

        if (passengerDto.getGender() == null || passengerDto.getGender().trim().isEmpty() ||
            (!passengerDto.getGender().equalsIgnoreCase("male") &&
             !passengerDto.getGender().equalsIgnoreCase("female") &&
             !passengerDto.getGender().equalsIgnoreCase("other"))) {
            model.addAttribute("error", "Please select a valid gender.");
            return preparePassengerModel(model, session, flightId, currentIdx, totalPassengers);
        }

        passengersList.add(passengerDto);

        if (currentIdx < totalPassengers) {
            session.setAttribute("currentPassengerIndex", currentIdx + 1);
            return "redirect:/booking/passenger";
        } else {
            // Last passenger reached: Complete Booking transaction!
            Booking booking = bookingService.createBooking(user.getUserId(), flightId, journeyDate, passengersList);

            // Clean up session draft
            session.removeAttribute("bookingFlightId");
            session.removeAttribute("bookingJourneyDate");
            session.removeAttribute("bookingTotalPassengers");
            session.removeAttribute("bookingPassengersList");
            session.removeAttribute("currentPassengerIndex");

            return "redirect:/booking/confirmation?bookingId=" + booking.getBookingId();
        }
    }

    private String preparePassengerModel(Model model, HttpSession session, Long flightId, int currentIdx, int totalPassengers) {
        Flight flight = flightService.getFlightById(flightId);
        int remaining = totalPassengers - currentIdx;
        boolean isLast = (currentIdx == totalPassengers);

        model.addAttribute("flight", flight);
        model.addAttribute("currentIndex", currentIdx);
        model.addAttribute("totalPassengers", totalPassengers);
        model.addAttribute("remainingPassengers", remaining);
        model.addAttribute("isLastPassenger", isLast);
        return "add-passenger";
    }

    // Step 5: Booking Confirmation Page
    @GetMapping("/confirmation")
    public String showConfirmation(@RequestParam("bookingId") Long bookingId,
                                   HttpSession session, Model model) {
        User user = getLoggedInUser(session);
        if (user == null) {
            return "redirect:/login";
        }

        Booking booking = bookingService.getBookingById(bookingId);
        if (booking == null) {
            model.addAttribute("errorMessage", "Booking #" + bookingId + " not found.");
            return "error";
        }

        List<Ticket> tickets = bookingService.getTicketsByBookingId(bookingId);
        model.addAttribute("booking", booking);
        model.addAttribute("tickets", tickets);

        return "booking-confirmation";
    }

    // User Bookings List
    @GetMapping("/my-bookings")
    public String myBookings(@RequestParam(value = "msg", required = false) String msg,
                             HttpSession session, Model model) {
        User user = getLoggedInUser(session);
        if (user == null) {
            return "redirect:/login?msg=Please log in to view your bookings.";
        }

        List<Booking> bookings = bookingService.getBookingsByUserId(user.getUserId());
        model.addAttribute("bookings", bookings);
        if (msg != null) {
            model.addAttribute("infoMsg", msg);
        }
        return "my-bookings";
    }

    // Cancel Booking
    @PostMapping("/cancel")
    public String cancelBooking(@RequestParam("bookingId") Long bookingId,
                                HttpSession session) {
        User user = getLoggedInUser(session);
        if (user == null) {
            return "redirect:/login";
        }

        boolean success = bookingService.cancelBooking(bookingId, user.getUserId());
        if (success) {
            return "redirect:/booking/my-bookings?msg=Booking #" + bookingId + " has been cancelled. Seats have been released successfully.";
        } else {
            return "redirect:/booking/my-bookings?msg=Unable to cancel booking #" + bookingId + ".";
        }
    }

    // View Tickets for a Booking
    @GetMapping("/tickets")
    public String viewTickets(@RequestParam("bookingId") Long bookingId,
                              HttpSession session, Model model) {
        User user = getLoggedInUser(session);
        if (user == null) {
            return "redirect:/login";
        }

        Booking booking = bookingService.getBookingById(bookingId);
        if (booking == null) {
            model.addAttribute("errorMessage", "Booking #" + bookingId + " not found.");
            return "error";
        }

        List<Ticket> tickets = bookingService.getTicketsByBookingId(bookingId);
        model.addAttribute("booking", booking);
        model.addAttribute("tickets", tickets);

        return "view-tickets";
    }
}
