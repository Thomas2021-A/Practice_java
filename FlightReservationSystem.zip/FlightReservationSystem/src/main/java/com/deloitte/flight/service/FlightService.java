package com.deloitte.flight.service;

import java.util.List;

import com.deloitte.flight.dto.AddFlightDto;
import com.deloitte.flight.model.Flight;

public interface FlightService {
    int addFlight(AddFlightDto addFlightDto);
    Flight getFlightById(Long flightId);
    Flight getFlightByNumber(String flightNumber);
    List<Flight> searchFlights(String source, String destination);
    List<Flight> getAllFlights();
    int getAvailableSeats(Long flightId, String journeyDate);
}
