package com.deloitte.flight.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.deloitte.flight.dto.AddFlightDto;
import com.deloitte.flight.model.Flight;

@Repository
public class FlightDaoImpl implements FlightDao {

    private final JdbcTemplate jdbcTemplate;

    @Autowired
    public FlightDaoImpl(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    private final RowMapper<Flight> flightRowMapper = (rs, rowNum) -> {
        Flight flight = new Flight();
        flight.setFlightId(rs.getLong("flight_id"));
        flight.setFlightNumber(rs.getString("flight_number"));
        flight.setSource(rs.getString("source"));
        flight.setDestination(rs.getString("destination"));
        flight.setDepartureTime(rs.getString("departure_time"));
        flight.setArrivalTime(rs.getString("arrival_time"));
        flight.setCapacity(rs.getInt("capacity"));
        flight.setPricePerSeat(rs.getDouble("price_per_seat"));
        return flight;
    };

    @Override
    public int insertFlight(AddFlightDto addFlightDto) {
        String sql = "INSERT INTO tbl_flights (flight_number, source, destination, departure_time, arrival_time, capacity, price_per_seat) "
                   + "VALUES (?, ?, ?, ?, ?, ?, ?)";
        return jdbcTemplate.update(sql,
                addFlightDto.getFlightNumber().trim().toUpperCase(),
                addFlightDto.getSource().trim(),
                addFlightDto.getDestination().trim(),
                addFlightDto.getDepartureTime().trim(),
                addFlightDto.getArrivalTime().trim(),
                addFlightDto.getCapacity(),
                addFlightDto.getPricePerSeat());
    }

    @Override
    public Flight findById(Long flightId) {
        String sql = "SELECT * FROM tbl_flights WHERE flight_id = ?";
        try {
            return jdbcTemplate.queryForObject(sql, flightRowMapper, flightId);
        } catch (EmptyResultDataAccessException e) {
            return null;
        }
    }

    @Override
    public Flight findByFlightNumber(String flightNumber) {
        String sql = "SELECT * FROM tbl_flights WHERE UPPER(flight_number) = UPPER(?)";
        try {
            return jdbcTemplate.queryForObject(sql, flightRowMapper, flightNumber);
        } catch (EmptyResultDataAccessException e) {
            return null;
        }
    }

    @Override
    public List<Flight> searchFlights(String source, String destination) {
        String sql = "SELECT * FROM tbl_flights WHERE LOWER(TRIM(source)) = LOWER(TRIM(?)) AND LOWER(TRIM(destination)) = LOWER(TRIM(?))";
        return jdbcTemplate.query(sql, flightRowMapper, source, destination);
    }

    @Override
    public List<Flight> getAllFlights() {
        String sql = "SELECT * FROM tbl_flights ORDER BY flight_id ASC";
        return jdbcTemplate.query(sql, flightRowMapper);
    }
}
