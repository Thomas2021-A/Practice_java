package com.deloitte.flight.dao;

import java.util.List;

import com.deloitte.flight.model.Booking;
import com.deloitte.flight.model.FlightSummary;

public interface BookingDao {
    Long createBooking(Booking booking);
    Booking findById(Long bookingId);
    List<Booking> findByUserId(Long userId);
    int cancelBooking(Long bookingId, Long userId);
    int getConfirmedSeatsCount(Long flightId, String journeyDate);
    List<FlightSummary> getFlightSummaries(boolean upcoming);
}
