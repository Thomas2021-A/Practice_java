package com.deloitte.flight.service;

import com.deloitte.flight.dto.LoginDto;
import com.deloitte.flight.dto.SignUpDto;
import com.deloitte.flight.model.User;

public interface UserService {
    int register(SignUpDto signUpDto);
    User login(LoginDto loginDto);
    User findByEmail(String email);
    User findById(Long userId);
}
