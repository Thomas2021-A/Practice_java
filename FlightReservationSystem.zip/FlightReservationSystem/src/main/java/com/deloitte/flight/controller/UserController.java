package com.deloitte.flight.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.deloitte.flight.dto.LoginDto;
import com.deloitte.flight.dto.SignUpDto;
import com.deloitte.flight.model.User;
import com.deloitte.flight.service.UserService;

@Controller
@RequestMapping("")
public class UserController {

    private final UserService userService;

    @Autowired
    public UserController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping("/signup")
    public String showSignupPage(Model model) {
        if (!model.containsAttribute("signUpDto")) {
            model.addAttribute("signUpDto", new SignUpDto());
        }
        return "signup";
    }

    @PostMapping("/signup")
    public String processSignup(@ModelAttribute("signUpDto") SignUpDto signUpDto, Model model) {
        // Validation checks
        if (signUpDto.getEmail() == null || signUpDto.getEmail().trim().isEmpty()) {
            model.addAttribute("error", "Email is required.");
            return "signup";
        }

        if (!signUpDto.getEmail().matches("^[A-Za-z0-9+_.-]+@(.+)$")) {
            model.addAttribute("error", "Please enter a valid email address.");
            return "signup";
        }

        if (signUpDto.getPassword() == null || signUpDto.getPassword().trim().length() <= 8) {
            model.addAttribute("error", "Password must be more than 8 characters in length.");
            return "signup";
        }

        if (signUpDto.getRole() == null || (!signUpDto.getRole().equalsIgnoreCase("user") && !signUpDto.getRole().equalsIgnoreCase("admin"))) {
            model.addAttribute("error", "Please select a valid role (User or Admin).");
            return "signup";
        }

        int result = userService.register(signUpDto);
        if (result == -3) {
            model.addAttribute("error", "Email already registered. Please log in.");
            return "signup";
        } else if (result <= 0) {
            model.addAttribute("error", "Registration failed. Please check your details.");
            return "signup";
        }

        model.addAttribute("successMsg", "Sign Up successful! Please log in with your credentials.");
        return "login";
    }

    @GetMapping("/login")
    public String showLoginPage(@RequestParam(value = "msg", required = false) String msg,
                                @RequestParam(value = "logout", required = false) String logout,
                                Model model) {
        if (!model.containsAttribute("loginDto")) {
            model.addAttribute("loginDto", new LoginDto());
        }
        if (msg != null) {
            model.addAttribute("infoMsg", msg);
        }
        if ("true".equalsIgnoreCase(logout)) {
            model.addAttribute("infoMsg", "You have been logged out successfully.");
        }
        return "login";
    }

    @PostMapping("/login")
    public String processLogin(@ModelAttribute("loginDto") LoginDto loginDto,
                               Model model, HttpSession session) {
        if (loginDto.getEmail() == null || loginDto.getEmail().trim().isEmpty() ||
            loginDto.getPassword() == null || loginDto.getPassword().trim().isEmpty()) {
            model.addAttribute("error", "Both email and password are required.");
            return "login";
        }

        User user = userService.login(loginDto);
        if (user == null) {
            model.addAttribute("error", "Invalid email or password.");
            return "login";
        }

        // Store user in session
        session.setAttribute("user", user);

        // Check if there was a pending flight booking redirection
        Long pendingFlightId = (Long) session.getAttribute("redirectFlightId");
        if (pendingFlightId != null) {
            session.removeAttribute("redirectFlightId");
            return "redirect:/booking/form?flightId=" + pendingFlightId;
        }

        // Redirect based on role
        if ("admin".equalsIgnoreCase(user.getRole())) {
            return "redirect:/admin/dashboard";
        } else {
            return "redirect:/user/dashboard";
        }
    }

    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/login?logout=true";
    }

    @GetMapping("/user/dashboard")
    public String userDashboard(HttpSession session, Model model) {
        User user = (User) session.getAttribute("user");
        if (user == null) {
            return "redirect:/login?msg=Please log in to access your dashboard.";
        }
        if ("admin".equalsIgnoreCase(user.getRole())) {
            return "redirect:/admin/dashboard";
        }
        model.addAttribute("user", user);
        return "user-dashboard";
    }
}
