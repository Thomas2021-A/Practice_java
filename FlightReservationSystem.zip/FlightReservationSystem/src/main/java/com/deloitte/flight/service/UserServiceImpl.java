package com.deloitte.flight.service;

import java.util.logging.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.deloitte.flight.dao.UserDao;
import com.deloitte.flight.dto.LoginDto;
import com.deloitte.flight.dto.SignUpDto;
import com.deloitte.flight.model.User;

@Service
public class UserServiceImpl implements UserService {

    private static final Logger LOGGER = Logger.getLogger(UserServiceImpl.class.getName());

    private final UserDao userDao;

    @Autowired
    public UserServiceImpl(UserDao userDao) {
        this.userDao = userDao;
    }

    @Override
    public int register(SignUpDto signUpDto) {
        if (signUpDto == null || signUpDto.getEmail() == null || signUpDto.getPassword() == null) {
            LOGGER.warning("Registration failed: Missing input data");
            return 0;
        }

        // Validate password length > 8
        if (signUpDto.getPassword().trim().length() <= 8) {
            LOGGER.warning("Registration failed: Password must be more than 8 characters");
            return -1; // Specific code for password violation
        }

        // Validate role ('user' or 'admin')
        String role = signUpDto.getRole() != null ? signUpDto.getRole().trim().toLowerCase() : "";
        if (!"user".equals(role) && !"admin".equals(role)) {
            LOGGER.warning("Registration failed: Invalid role " + role);
            return -2;
        }

        // Check if email is already registered
        User existingUser = userDao.findByEmail(signUpDto.getEmail().trim().toLowerCase());
        if (existingUser != null) {
            LOGGER.warning("Registration failed: Email already exists - " + signUpDto.getEmail());
            return -3; // Specific code for duplicate email
        }

        signUpDto.setEmail(signUpDto.getEmail().trim().toLowerCase());
        signUpDto.setRole(role);

        int result = userDao.insertUser(signUpDto);
        LOGGER.info("User registered successfully: " + signUpDto.getEmail());
        return result;
    }

    @Override
    public User login(LoginDto loginDto) {
        if (loginDto == null || loginDto.getEmail() == null || loginDto.getPassword() == null) {
            return null;
        }
        User user = userDao.findByEmailAndPassword(loginDto.getEmail().trim().toLowerCase(), loginDto.getPassword().trim());
        if (user != null) {
            LOGGER.info("User login successful: " + user.getEmail() + " (" + user.getRole() + ")");
        } else {
            LOGGER.warning("User login failed for: " + loginDto.getEmail());
        }
        return user;
    }

    @Override
    public User findByEmail(String email) {
        if (email == null) {
            return null;
        }
        return userDao.findByEmail(email.trim().toLowerCase());
    }

    @Override
    public User findById(Long userId) {
        if (userId == null) {
            return null;
        }
        return userDao.findById(userId);
    }
}
