package com.deloitte.flight.dao;

import com.deloitte.flight.dto.SignUpDto;
import com.deloitte.flight.model.User;

public interface UserDao {
    int insertUser(SignUpDto signUpDto);
    User findByEmailAndPassword(String email, String password);
    User findByEmail(String email);
    User findById(Long userId);
}
