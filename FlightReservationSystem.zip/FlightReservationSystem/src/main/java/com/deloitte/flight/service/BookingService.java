package com.deloitte.flight.service;

import java.util.List;

import com.deloitte.flight.dto.PassengerDto;
import com.deloitte.flight.model.Booking;
import com.deloitte.flight.model.FlightSummary;
import com.deloitte.flight.model.Ticket;

public interface BookingService {
    Booking createBooking(Long userId, Long flightId, String journeyDate, List<PassengerDto> passengers);
    Booking getBookingById(Long bookingId);
    List<Booking> getBookingsByUserId(Long userId);
    boolean cancelBooking(Long bookingId, Long userId);
    List<Ticket> getTicketsByBookingId(Long bookingId);
    List<FlightSummary> getUpcomingFlights();
    List<FlightSummary> getCompletedFlights();
}
