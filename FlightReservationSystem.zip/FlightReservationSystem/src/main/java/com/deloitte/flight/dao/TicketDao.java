package com.deloitte.flight.dao;

import java.util.List;

import com.deloitte.flight.model.Ticket;

public interface TicketDao {
    int insertTicket(Ticket ticket);
    List<Ticket> findByBookingId(Long bookingId);
    int cancelTicketsByBookingId(Long bookingId);
}
