package com.deloitte.flight.controller;

import java.time.LocalDate;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.deloitte.flight.dto.AddFlightDto;
import com.deloitte.flight.model.FlightSummary;
import com.deloitte.flight.model.User;
import com.deloitte.flight.service.BookingService;
import com.deloitte.flight.service.FlightService;

@Controller
@RequestMapping("/admin")
public class AdminController {

    private final FlightService flightService;
    private final BookingService bookingService;

    @Autowired
    public AdminController(FlightService flightService, BookingService bookingService) {
        this.flightService = flightService;
        this.bookingService = bookingService;
    }

    private boolean isAdmin(HttpSession session) {
        User user = (User) session.getAttribute("user");
        return user != null && "admin".equalsIgnoreCase(user.getRole());
    }

    @GetMapping("/dashboard")
    public String adminDashboard(HttpSession session, Model model) {
        if (!isAdmin(session)) {
            return "redirect:/login?msg=Admin access required. Please log in as admin.";
        }
        User user = (User) session.getAttribute("user");
        model.addAttribute("adminUser", user);
        return "admin-dashboard";
    }

    @GetMapping("/flight/add")
    public String showAddFlightPage(HttpSession session, Model model) {
        if (!isAdmin(session)) {
            return "redirect:/login?msg=Admin access required.";
        }
        if (!model.containsAttribute("addFlightDto")) {
            AddFlightDto dto = new AddFlightDto();
            dto.setCapacity(20); // Default capacity 20 as specified
            model.addAttribute("addFlightDto", dto);
        }
        return "add-flight";
    }

    @PostMapping("/flight/add")
    public String processAddFlight(@ModelAttribute("addFlightDto") AddFlightDto addFlightDto,
                                  HttpSession session, Model model) {
        if (!isAdmin(session)) {
            return "redirect:/login?msg=Admin access required.";
        }

        // Validate form inputs
        if (addFlightDto.getFlightNumber() == null || addFlightDto.getFlightNumber().trim().isEmpty() ||
            addFlightDto.getSource() == null || addFlightDto.getSource().trim().isEmpty() ||
            addFlightDto.getDestination() == null || addFlightDto.getDestination().trim().isEmpty() ||
            addFlightDto.getDepartureTime() == null || addFlightDto.getDepartureTime().trim().isEmpty() ||
            addFlightDto.getArrivalTime() == null || addFlightDto.getArrivalTime().trim().isEmpty() ||
            addFlightDto.getPricePerSeat() == null || addFlightDto.getPricePerSeat() <= 0) {
            model.addAttribute("error", "All fields are required and Price per Seat must be greater than 0.");
            return "add-flight";
        }

        if (addFlightDto.getCapacity() == null || addFlightDto.getCapacity() <= 0) {
            addFlightDto.setCapacity(20);
        }

        int result = flightService.addFlight(addFlightDto);
        if (result == -1) {
            model.addAttribute("error", "Flight Number '" + addFlightDto.getFlightNumber() + "' already exists. Please use a unique flight number.");
            return "add-flight";
        } else if (result <= 0) {
            model.addAttribute("error", "Failed to add flight. Please check your data.");
            return "add-flight";
        }

        model.addAttribute("successMsg", "Flight " + addFlightDto.getFlightNumber().toUpperCase() + " added successfully!");
        AddFlightDto newDto = new AddFlightDto();
        newDto.setCapacity(20);
        model.addAttribute("addFlightDto", newDto);
        return "add-flight";
    }

    @GetMapping("/flights")
    public String viewFlights(HttpSession session, Model model) {
        if (!isAdmin(session)) {
            return "redirect:/login?msg=Admin access required.";
        }

        List<FlightSummary> upcomingFlights = bookingService.getUpcomingFlights();
        List<FlightSummary> completedFlights = bookingService.getCompletedFlights();

        model.addAttribute("currentDate", LocalDate.now().toString());
        model.addAttribute("upcomingFlights", upcomingFlights);
        model.addAttribute("completedFlights", completedFlights);

        return "view-flights";
    }
}
