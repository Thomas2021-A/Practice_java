package com.deloitte.flight.model;

public class FlightSummary {
    private String flightNumber;
    private String journeyDate;
    private Integer totalPassengers;
    private Integer totalBookings;
    private Double totalRevenue;
    private String daysUntilJourney;
    private String status; // 'Upcoming' or 'Completed'

    public FlightSummary() {
    }

    public FlightSummary(String flightNumber, String journeyDate, Integer totalPassengers,
                         Integer totalBookings, Double totalRevenue, String daysUntilJourney, String status) {
        this.flightNumber = flightNumber;
        this.journeyDate = journeyDate;
        this.totalPassengers = totalPassengers;
        this.totalBookings = totalBookings;
        this.totalRevenue = totalRevenue;
        this.daysUntilJourney = daysUntilJourney;
        this.status = status;
    }

    public String getFlightNumber() {
        return flightNumber;
    }

    public void setFlightNumber(String flightNumber) {
        this.flightNumber = flightNumber;
    }

    public String getJourneyDate() {
        return journeyDate;
    }

    public void setJourneyDate(String journeyDate) {
        this.journeyDate = journeyDate;
    }

    public Integer getTotalPassengers() {
        return totalPassengers;
    }

    public void setTotalPassengers(Integer totalPassengers) {
        this.totalPassengers = totalPassengers;
    }

    public Integer getTotalBookings() {
        return totalBookings;
    }

    public void setTotalBookings(Integer totalBookings) {
        this.totalBookings = totalBookings;
    }

    public Double getTotalRevenue() {
        return totalRevenue;
    }

    public void setTotalRevenue(Double totalRevenue) {
        this.totalRevenue = totalRevenue;
    }

    public String getDaysUntilJourney() {
        return daysUntilJourney;
    }

    public void setDaysUntilJourney(String daysUntilJourney) {
        this.daysUntilJourney = daysUntilJourney;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
