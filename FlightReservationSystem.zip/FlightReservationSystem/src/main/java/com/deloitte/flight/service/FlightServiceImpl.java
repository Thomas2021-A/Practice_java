package com.deloitte.flight.service;

import java.util.List;
import java.util.logging.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.deloitte.flight.dao.BookingDao;
import com.deloitte.flight.dao.FlightDao;
import com.deloitte.flight.dto.AddFlightDto;
import com.deloitte.flight.model.Flight;

@Service
public class FlightServiceImpl implements FlightService {

    private static final Logger LOGGER = Logger.getLogger(FlightServiceImpl.class.getName());

    private final FlightDao flightDao;
    private final BookingDao bookingDao;

    @Autowired
    public FlightServiceImpl(FlightDao flightDao, BookingDao bookingDao) {
        this.flightDao = flightDao;
        this.bookingDao = bookingDao;
    }

    @Override
    public int addFlight(AddFlightDto addFlightDto) {
        if (addFlightDto == null || addFlightDto.getFlightNumber() == null) {
            return 0;
        }

        // Check if flight number already exists
        Flight existing = flightDao.findByFlightNumber(addFlightDto.getFlightNumber().trim());
        if (existing != null) {
            LOGGER.warning("Flight number already exists: " + addFlightDto.getFlightNumber());
            return -1; // Duplicate flight number code
        }

        if (addFlightDto.getCapacity() == null || addFlightDto.getCapacity() <= 0) {
            addFlightDto.setCapacity(20); // Default capacity 20
        }

        int result = flightDao.insertFlight(addFlightDto);
        LOGGER.info("Flight added successfully: " + addFlightDto.getFlightNumber());
        return result;
    }

    @Override
    public Flight getFlightById(Long flightId) {
        if (flightId == null) {
            return null;
        }
        return flightDao.findById(flightId);
    }

    @Override
    public Flight getFlightByNumber(String flightNumber) {
        if (flightNumber == null) {
            return null;
        }
        return flightDao.findByFlightNumber(flightNumber.trim());
    }

    @Override
    public List<Flight> searchFlights(String source, String destination) {
        if (source == null || destination == null) {
            return List.of();
        }
        return flightDao.searchFlights(source.trim(), destination.trim());
    }

    @Override
    public List<Flight> getAllFlights() {
        return flightDao.getAllFlights();
    }

    @Override
    public int getAvailableSeats(Long flightId, String journeyDate) {
        Flight flight = flightDao.findById(flightId);
        if (flight == null || flight.getCapacity() == null) {
            return 0;
        }
        int bookedSeats = bookingDao.getConfirmedSeatsCount(flightId, journeyDate);
        int available = flight.getCapacity() - bookedSeats;
        return Math.max(available, 0);
    }
}
