package com.deloitte.flight.dao;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import com.deloitte.flight.model.Booking;
import com.deloitte.flight.model.FlightSummary;

@Repository
public class BookingDaoImpl implements BookingDao {

    private final JdbcTemplate jdbcTemplate;

    @Autowired
    public BookingDaoImpl(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    private final RowMapper<Booking> bookingRowMapper = (rs, rowNum) -> {
        Booking booking = new Booking();
        booking.setBookingId(rs.getLong("booking_id"));
        booking.setBookingDate(rs.getString("booking_date"));
        booking.setJourneyDate(rs.getString("journey_date"));
        booking.setSeats(rs.getInt("seats"));
        booking.setTotalPrice(rs.getDouble("total_price"));
        booking.setStatus(rs.getString("status"));
        booking.setFlightId(rs.getLong("flight_id"));
        booking.setUserId(rs.getLong("user_id"));

        // Join columns if present
        try {
            booking.setFlightNumber(rs.getString("flight_number"));
            booking.setSource(rs.getString("source"));
            booking.setDestination(rs.getString("destination"));
            booking.setDepartureTime(rs.getString("departure_time"));
            booking.setArrivalTime(rs.getString("arrival_time"));
        } catch (Exception ignored) {
        }

        return booking;
    };

    @Override
    public Long createBooking(Booking booking) {
        String sql = "INSERT INTO tbl_bookings (booking_date, journey_date, seats, total_price, status, flight_id, user_id) "
                   + "VALUES (?, ?, ?, ?, ?, ?, ?)";
        KeyHolder keyHolder = new GeneratedKeyHolder();

        jdbcTemplate.update(connection -> {
            PreparedStatement ps = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            ps.setDate(1, Date.valueOf(booking.getBookingDate()));
            ps.setDate(2, Date.valueOf(booking.getJourneyDate()));
            ps.setInt(3, booking.getSeats());
            ps.setDouble(4, booking.getTotalPrice());
            ps.setString(5, booking.getStatus());
            ps.setLong(6, booking.getFlightId());
            ps.setLong(7, booking.getUserId());
            return ps;
        }, keyHolder);

        if (keyHolder.getKey() != null) {
            return keyHolder.getKey().longValue();
        }
        return null;
    }

    @Override
    public Booking findById(Long bookingId) {
        String sql = "SELECT b.*, f.flight_number, f.source, f.destination, f.departure_time, f.arrival_time "
                   + "FROM tbl_bookings b "
                   + "JOIN tbl_flights f ON b.flight_id = f.flight_id "
                   + "WHERE b.booking_id = ?";
        try {
            return jdbcTemplate.queryForObject(sql, bookingRowMapper, bookingId);
        } catch (EmptyResultDataAccessException e) {
            return null;
        }
    }

    @Override
    public List<Booking> findByUserId(Long userId) {
        String sql = "SELECT b.*, f.flight_number, f.source, f.destination, f.departure_time, f.arrival_time "
                   + "FROM tbl_bookings b "
                   + "JOIN tbl_flights f ON b.flight_id = f.flight_id "
                   + "WHERE b.user_id = ? "
                   + "ORDER BY b.booking_id DESC";
        return jdbcTemplate.query(sql, bookingRowMapper, userId);
    }

    @Override
    public int cancelBooking(Long bookingId, Long userId) {
        String sql = "UPDATE tbl_bookings SET status = 'cancelled' WHERE booking_id = ? AND user_id = ?";
        return jdbcTemplate.update(sql, bookingId, userId);
    }

    @Override
    public int getConfirmedSeatsCount(Long flightId, String journeyDate) {
        String sql = "SELECT COALESCE(SUM(seats), 0) FROM tbl_bookings "
                   + "WHERE flight_id = ? AND journey_date = ? AND status = 'confirmed'";
        Integer count = jdbcTemplate.queryForObject(sql, Integer.class, flightId, Date.valueOf(journeyDate));
        return count != null ? count : 0;
    }

    @Override
    public List<FlightSummary> getFlightSummaries(boolean upcoming) {
        String condition = upcoming ? "b.journey_date >= CURRENT_DATE()" : "b.journey_date < CURRENT_DATE()";
        String order = upcoming ? "b.journey_date ASC" : "b.journey_date DESC";

        String sql = "SELECT f.flight_number, b.journey_date, "
                   + "SUM(b.seats) AS total_passengers, "
                   + "COUNT(b.booking_id) AS total_bookings, "
                   + "SUM(b.total_price) AS total_revenue, "
                   + "DATEDIFF(b.journey_date, CURRENT_DATE()) AS days_diff "
                   + "FROM tbl_bookings b "
                   + "JOIN tbl_flights f ON b.flight_id = f.flight_id "
                   + "WHERE b.status = 'confirmed' AND " + condition + " "
                   + "GROUP BY f.flight_number, b.journey_date "
                   + "ORDER BY " + order;

        return jdbcTemplate.query(sql, (rs, rowNum) -> {
            FlightSummary summary = new FlightSummary();
            summary.setFlightNumber(rs.getString("flight_number"));
            summary.setJourneyDate(rs.getString("journey_date"));
            summary.setTotalPassengers(rs.getInt("total_passengers"));
            summary.setTotalBookings(rs.getInt("total_bookings"));
            summary.setTotalRevenue(rs.getDouble("total_revenue"));

            int daysDiff = rs.getInt("days_diff");
            if (daysDiff > 1) {
                summary.setDaysUntilJourney(daysDiff + " days");
            } else if (daysDiff == 1) {
                summary.setDaysUntilJourney("1 day");
            } else if (daysDiff == 0) {
                summary.setDaysUntilJourney("Today");
            } else {
                summary.setDaysUntilJourney("Completed");
            }

            summary.setStatus(upcoming ? "Upcoming" : "Completed");
            return summary;
        });
    }
}
